// flow test: runs the real message handlers against fake
// Discord and Fluxer connections, to prove the mirror path end to end.
// Run with:  node selftest/flow.js
import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { createRequire } from "node:module";

const require = createRequire(import.meta.url);
const appDir = path.resolve(path.dirname(new URL(import.meta.url).pathname), "..");
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), "bridge-flow-"));

const MAX = "111111111111111111";
const MIRROR_ID = "222222222222222222";
const MAIN_ID = "333333333333333333";
const OTHER = "121212121212121212";
const F_GUILD = "500000000000000001";
const F_CHANNEL = "500000000000000002";
const F_WEBHOOK = "500000000000000003";
const D_GUILD = "600000000000000001";
const D_CHANNEL = "600000000000000002";
const D_WEBHOOK = "600000000000000003";

fs.writeFileSync(
  path.join(tmp, "settings.txt"),
  [
    `fluxer token: ${MAIN_ID}.mainsecretmainsecretmainsecret12`,
    "discord token: AAAAAAAAAAAAAAAAAAAAAAAAAA.BBBBBB.CCCCCCCCCCCCCCCCCCCCCCCCCCCCCC",
    "emoji community id: 500000000000000009",
    `mirror: Max | ${MAX} | ${MIRROR_ID}.mirrorsecretmirrorsecretmirror1`,
  ].join("\n"),
);
fs.writeFileSync(
  path.join(tmp, "fluxcord.json"),
  JSON.stringify({
    fluxerReplyEmoji: { replyL: "reply_l:1", replyR: "reply_r:2" },
    discordReplyEmoji: { replyL: "3", replyR: "4" },
  }),
);
const env = { ...process.env, BRIDGE_SETTINGS_FILE: path.join(tmp, "settings.txt"), BRIDGE_DATA_DIR: tmp };
const mig = spawnSync(process.execPath, [require.resolve("tsx/cli"), "migrate.ts"], { cwd: appDir, env, encoding: "utf-8" });
assert.equal(mig.status, 0, mig.stderr);
Object.assign(process.env, env);
process.chdir(appDir);

const { ChannelMap, GuildMap, MessageMap } = await import("../db/index.js");
const M = await import("../utils/Mirrors.js");
const D = await import("../utils/DiscordHandler.js");
const F = await import("../utils/FluxerHandler.js");

const [fgm] = await GuildMap.findOrCreate({ where: { guildId: F_GUILD, guildType: "fluxer" } });
const [dgm] = await GuildMap.findOrCreate({ where: { guildId: D_GUILD, guildType: "discord" } });
await ChannelMap.create({
  fluxerChannelId: F_CHANNEL, discordChannelId: D_CHANNEL, fluxerGuildId: F_GUILD, discordGuildId: D_GUILD,
  fluxerWebhookId: F_WEBHOOK, fluxerWebhookToken: "fwtoken", discordWebhookId: D_WEBHOOK, discordWebhookToken: "dwtoken",
  fluxerGuildMapId: fgm.id, discordGuildMapId: dgm.id, bridgeType: "both",
});

// ---------- fakes ----------
let calls = [];
let nextId = 700000000000000000n;
const newId = () => String(nextId++);
const rec = (name, result) => async (...args) => {
  calls.push({ name, args });
  return typeof result === "function" ? result(...args) : { id: newId() };
};

class Coll extends Map {
  filter(fn) { return new Coll([...this].filter(([, v]) => fn(v))); }
  map(fn) { return [...this.values()].map(fn); }
  first() { return this.values().next().value; }
}

const fluxerGuild = { id: F_GUILD, fetchRoles: async () => [], members: { fetch: async () => null, me: {} } };
const fluxerChannel = { id: F_CHANNEL, fetchWebhooks: async () => [{ id: F_WEBHOOK }], send: rec("fluxerChannel.send") };
const fluxerClient = {
  user: { id: MAIN_ID },
  channels: { fetch: async () => fluxerChannel },
  guilds: { fetch: async () => fluxerGuild },
  rest: {
    post: rec("main.post"), patch: rec("main.patch"), delete: rec("main.delete"), put: rec("main.put"),
    get: async () => [],
  },
};
const discordMember = { id: MAX, displayName: "AlexMirror", permissions: { has: () => false } };
const discordChannel = {
  id: D_CHANNEL, isSendable: () => true, messages: { fetch: async (id) => ({ id }) },
  async fetch() { return this; },
};
const discordGuild = { id: D_GUILD, members: { fetch: async () => discordMember } };
const discordClient = {
  user: { id: "DBOT" },
  guilds: { fetch: async () => discordGuild },
  channels: { fetch: async () => discordChannel },
  fetchWebhook: rec("discord.fetchWebhook"),
};

function discordMessage(authorId, content, extra = {}) {
  return {
    id: newId(), channelId: D_CHANNEL, guildId: D_GUILD, type: 0, content,
    author: {
      id: authorId, username: authorId === MAX ? "alexmirror" : "sam", displayName: authorId === MAX ? "AlexMirror" : "Sam",
      globalName: null, tag: "x", bot: false, avatarURL: () => "https://cdn.example/a.png",
    },
    member: discordMember, guild: discordGuild, channel: discordChannel,
    reference: null, flags: { has: () => false }, messageSnapshots: new Coll(),
    stickers: new Coll(), attachments: new Coll(), embeds: [], interaction: null, webhookId: null, mentions: {},
    ...extra,
  };
}

const mirror = M.getMirrorByName("Max");
function mirrorOnline(failSend = false) {
  mirror.ready = true;
  mirror.client = {
    user: { setPresence: () => {} },
    rest: {
      post: failSend
        ? async (...args) => { calls.push({ name: "mirror.post", args }); throw Object.assign(new Error("Missing Permissions"), { status: 403 }); }
        : rec("mirror.post"),
      patch: rec("mirror.patch"), put: rec("mirror.put"), delete: rec("mirror.delete"),
    },
  };
}
const names = () => calls.map((c) => c.name);

let passed = 0;
async function test(name, fn) {
  calls = [];
  try { await fn(); passed++; console.log(`  ✓ ${name}`); }
  catch (e) { console.log(`  ✗ ${name}\n    ${e.stack ?? e}`); process.exitCode = 1; }
}

console.log("Max's messages");
let maxMsg;
await test("Alex's Discord message is posted by his mirror, not the webhook", async () => {
  mirrorOnline();
  maxMsg = discordMessage(MAX, "hello from discord");
  await D.DiscordCreateMessageHandler(maxMsg, discordClient, fluxerClient);
  assert.deepEqual(names(), ["mirror.post"], `calls were: ${names()}`);
  const [route, opts] = calls[0].args;
  assert.equal(route, `/channels/${F_CHANNEL}/messages`);
  assert.equal(opts.body.content, "hello from discord");
  assert.ok(!("username" in opts.body), "a mirror posts as itself");
  const row = await MessageMap.findOne({ where: { discordMessageId: maxMsg.id } });
  assert.ok(row, "the bridge remembers the pair");
});

await test("nothing gets deleted anywhere (the old bot's problem)", async () => {
  await new Promise((r) => setTimeout(r, 1200)); // let the source-check timer run
  assert.ok(!names().some((n) => n.includes("delete")), `calls were: ${names()}`);
});

await test("his edit on Discord is made by the mirror", async () => {
  const row = await MessageMap.findOne({ where: { discordMessageId: maxMsg.id } });
  const edited = { ...maxMsg, content: "hello from discord (edited)" };
  await D.DiscordUpdateMessageHandler(maxMsg, edited, fluxerClient);
  assert.deepEqual(names(), ["mirror.patch"], `calls were: ${names()}`);
  assert.equal(calls[0].args[0], `/channels/${F_CHANNEL}/messages/${row.fluxerMessageId}`);
  assert.equal(calls[0].args[1].body.content, "hello from discord (edited)");
});

await test("pinging Alex on Discord pings his mirror on Fluxer", async () => {
  const msg = discordMessage(OTHER, `hey <@${MAX}> look`);
  await D.DiscordCreateMessageHandler(msg, discordClient, fluxerClient);
  const post = calls.find((c) => c.name === "main.post");
  assert.ok(post, `calls were: ${names()}`);
  const body = post.args[1].body;
  assert.equal(body.content, `hey <@${MIRROR_ID}> look`);
  assert.equal(body.username, "AlexMirror", "other people still use the webhook");
});

await test("if the mirror can't post, the message still arrives via the webhook", async () => {
  mirrorOnline(true);
  const msg = discordMessage(MAX, "fallback please");
  await D.DiscordCreateMessageHandler(msg, discordClient, fluxerClient);
  assert.deepEqual(names(), ["mirror.post", "main.post"], `calls were: ${names()}`);
  assert.match(calls[1].args[0], new RegExp(`/webhooks/${F_WEBHOOK}/fwtoken`));
  assert.equal(calls[1].args[1].body.content, "fallback please");
});

await test("if the mirror is offline, the webhook is used", async () => {
  mirror.ready = false;
  const msg = discordMessage(MAX, "mirror is asleep");
  await D.DiscordCreateMessageHandler(msg, discordClient, fluxerClient);
  assert.deepEqual(names(), ["main.post"], `calls were: ${names()}`);
});

console.log("Echo protection");
await test("the mirror's own message on Fluxer is never sent back to Discord", async () => {
  mirrorOnline();
  const fluxerSide = {
    id: newId(), channelId: F_CHANNEL, guildId: F_GUILD, type: 0, content: "hello from discord",
    author: { id: MIRROR_ID, username: "AlexMirror", discriminator: "2645" },
  };
  await F.FluxerCreateMessageHandler(fluxerSide, fluxerClient, discordClient);
  assert.deepEqual(names(), [], `calls were: ${names()}`);
});

await test("deleting on Discord removes the mirror's copy (once, via the bridge bot)", async () => {
  const row = await MessageMap.findOne({ where: { discordMessageId: maxMsg.id } });
  await D.DiscordDeleteMessageHandler({ id: maxMsg.id, channelId: D_CHANNEL }, fluxerClient);
  assert.deepEqual(names(), ["main.delete"], `calls were: ${names()}`);
  assert.equal(calls[0].args[0], `/channels/${F_CHANNEL}/messages/${row.fluxerMessageId}`);
  assert.equal(await MessageMap.findOne({ where: { discordMessageId: maxMsg.id } }), null);
});

console.log(`\n${passed} flow checks passed${process.exitCode ? ", some failed" : ""}.`);
fs.rmSync(tmp, { recursive: true, force: true });
process.exit(process.exitCode ?? 0);
