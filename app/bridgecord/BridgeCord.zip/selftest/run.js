// offline tests: settings parsing, mirror lookups, ping and status mapping, posting as a mirror, catch-up.
// Run with:  npm run selftest
import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), "bridge-test-"));
const MAX_DISCORD = "111111111111111111";
const MIRROR_ID = "222222222222222222";
const MAIN_ID = "333333333333333333";
const SAM_MIRROR = "444444444444444444";
fs.writeFileSync(
  path.join(tmp, "settings.txt"),
  [
    "# test",
    `fluxer token: ${MAIN_ID}.mainsecretmainsecretmainsecret12`,
    "discord token: paste the Discord token here",
    "emoji community id: 555555555555555555",
    `mirror: Max | ${MAX_DISCORD} | ${MIRROR_ID}.mirrorsecretmirrorsecretmirror1`,
    `mirror: Sam | sam_user | ${SAM_MIRROR}.samsecretsamsecretsamsecret1234`,
    `mirror: Oops | 999999999999999999 | ${MAIN_ID}.mainsecretmainsecretmainsecret12`,
    "catch up days: 2",
    "mirror statuses: no",
  ].join("\n"),
);
process.env.BRIDGE_SETTINGS_FILE = path.join(tmp, "settings.txt");
process.env.BRIDGE_DATA_DIR = tmp;

let passed = 0;
async function test(name, fn) {
  try {
    await fn();
    passed++;
    console.log(`  ✓ ${name}`);
  } catch (e) {
    console.log(`  ✗ ${name}\n    ${e.stack ?? e}`);
    process.exitCode = 1;
  }
}

const { parseSettings, fluxerIdFromToken } = await import("../utils/Settings.js");
const Config = (await import("../utils/ConfigHandler.js")).default;
const M = await import("../utils/Mirrors.js");

console.log("Settings");
await test("reads tokens, IDs and options", () => {
  assert.equal(Config.FluxerBotToken, `${MAIN_ID}.mainsecretmainsecretmainsecret12`);
  assert.equal(Config.DiscordBotToken, "");
  assert.equal(Config.PracticeMode, true);
  assert.equal(Config.FluxerTempEmojiGuildId, "555555555555555555");
  assert.equal(Config.CatchUpDays, 2);
  assert.equal(Config.MirrorStatuses, false);
});
await test("bot ID comes from the token", () => {
  assert.equal(fluxerIdFromToken(`${MIRROR_ID}.abcdefghijklmnopqrstuvwxyz`), MIRROR_ID);
  assert.equal(fluxerIdFromToken("not a token"), null);
});
await test("mirror lines: ID, username, and the bridge's own token rejected", () => {
  assert.equal(Config.Mirrors.length, 2);
  const [max, sam] = Config.Mirrors;
  assert.deepEqual([max.name, max.discordId, max.fluxerId], ["Max", MAX_DISCORD, MIRROR_ID]);
  assert.deepEqual([sam.discordRef, sam.discordId], ["sam_user", null]);
  assert.ok(Config.SettingsProblems.some((p) => p.includes("Oops") && p.includes("own token")));
});
await test("the untouched template counts as blank, not as broken values", () => {
  const s = parseSettings(fs.readFileSync(new URL("../settings.txt", import.meta.url), "utf-8"));
  assert.equal(s.fluxerToken, "");
  assert.equal(s.discordToken, "");
  assert.equal(s.emojiCommunityId, "");
  assert.equal(s.mirrors.length, 0);
});
await test("Windows line endings and a BOM are fine", () => {
  const s = parseSettings(`\uFEFFfluxer token: ${MAIN_ID}.mainsecretmainsecretmainsecret12\r\ncatch up days: 0\r\n`);
  assert.equal(s.fluxerToken.startsWith(MAIN_ID), true);
  assert.equal(s.catchUpDays, 0);
});

console.log("Mirror lookups");
await test("mirror IDs are known before anything signs in", () => {
  assert.equal(M.isMirrorFluxerId(MIRROR_ID), true);
  assert.equal(M.isMirrorFluxerId(SAM_MIRROR), true);
  assert.equal(M.isMirrorFluxerId(MAIN_ID), false);
  assert.equal(M.getMirrorByDiscordId(MAX_DISCORD)?.name, "Max");
  assert.equal(M.getMirrorByName("max")?.name, "Max");
  assert.equal(M.getReadyMirrorForDiscordUser(MAX_DISCORD), null, "not ready until signed in");
});
await test("a username mirror links the first time that person posts", () => {
  M.noteDiscordAuthor({ id: "777777777777777777", username: "sam_user" }, null);
  assert.equal(M.getMirrorByName("Sam").discordId, "777777777777777777");
});

console.log("Pings");
await test("Discord ping of Max becomes a ping of his mirror", () => {
  assert.equal(M.discordMentionsToMirrors(`hi <@${MAX_DISCORD}>!`), `hi <@${MIRROR_ID}>!`);
  assert.equal(M.discordMentionsToMirrors(`<@!${MAX_DISCORD}>`), `<@${MIRROR_ID}>`);
  assert.equal(M.discordMentionsToMirrors("<@123456789012345678>"), "<@123456789012345678>");
});
await test("Fluxer ping of the mirror becomes a real Discord ping", () => {
  assert.equal(M.fluxerMentionsToDiscord(`<@${MIRROR_ID}> look`), `<@${MAX_DISCORD}> look`);
  assert.equal(M.fluxerMentionsToDiscord(null), null);
});

console.log("Status");
await test("Discord statuses map onto Fluxer", () => {
  assert.deepEqual(M.presenceFromDiscord(null), { status: "invisible", text: null, emoji: null });
  assert.equal(M.presenceFromDiscord({ status: "offline" }).status, "invisible");
  assert.equal(M.presenceFromDiscord({ status: "dnd", activities: [] }).status, "dnd");
});
await test("custom status wins, then Spotify, then games", () => {
  const custom = M.presenceFromDiscord({
    status: "online",
    activities: [
      { type: 2, name: "Spotify", details: "Song", state: "Artist" },
      { type: 4, state: "drawing", emoji: { id: null, name: "🎨" } },
    ],
  });
  assert.deepEqual(custom, { status: "online", text: "drawing", emoji: "🎨" });
  const spotify = M.presenceFromDiscord({
    status: "idle",
    activities: [
      { type: 0, name: "Minecraft" },
      { type: 2, name: "Spotify", details: "Song", state: "Artist" },
    ],
  });
  assert.deepEqual(spotify, { status: "idle", text: "Song · Artist", emoji: "🎧" });
  const game = M.presenceFromDiscord({ status: "online", activities: [{ type: 0, name: "Kingdom Hearts II" }] });
  assert.equal(game.text, "Playing Kingdom Hearts II");
});
await test("status text is capped at Fluxer's 128 characters", () => {
  const p = M.presenceFromDiscord({ status: "online", activities: [{ type: 4, state: "x".repeat(300) }] });
  assert.equal(Array.from(p.text).length, 128);
});
await test("status changes are spaced out to respect Fluxer's limit", async () => {
  const mirror = M.getMirrorByName("Max");
  const sent = [];
  mirror.ready = true;
  mirror.client = { user: { setPresence: (x) => sent.push(x) } };
  mirror.lastPresenceAt = 0;
  mirror.setPresence({ status: "online", text: "a", emoji: null });
  mirror.setPresence({ status: "dnd", text: "b", emoji: null }); // replaces the pending one
  await new Promise((r) => setTimeout(r, 1000));
  assert.equal(sent.length, 1, "coalesced into one update");
  assert.equal(sent[0].status, "dnd");
  assert.deepEqual(sent[0].customStatus, { text: "b", emojiName: null });
});

console.log("Posting as a mirror");
await test("sends to the channel route with files and reply", async () => {
  const mirror = M.getMirrorByName("Max");
  const calls = [];
  mirror.client = { rest: { post: async (route, opts) => (calls.push({ route, opts }), { id: "999" }) } };
  const res = await mirror.send("888888888888888888", {
    content: "hi",
    embeds: [],
    files: [{ name: "a.png", data: Buffer.from("x"), flags: 8 }, { name: "broken.png" }],
    message_reference: { message_id: "123" },
    allowed_mentions: { parse: ["users"] },
  });
  assert.equal(res.id, "999");
  assert.equal(calls[0].route, "/channels/888888888888888888/messages");
  assert.equal(calls[0].opts.auth, true);
  assert.equal(calls[0].opts.files.length, 1, "files without data are skipped");
  assert.deepEqual(calls[0].opts.body.attachments, [{ id: 0, filename: "a.png", flags: 8 }]);
  assert.deepEqual(calls[0].opts.body.message_reference, { message_id: "123" });
});
await test("no reply field is sent when it isn't a reply", async () => {
  const mirror = M.getMirrorByName("Max");
  let body;
  mirror.client = { rest: { post: async (_r, o) => ((body = o.body), { id: "1" }) } };
  await mirror.send("888888888888888888", { content: "plain", message_reference: undefined });
  assert.equal("message_reference" in body, false);
});
await test("invite link asks only for what a mirror needs", () => {
  const link = M.getMirrorByName("Max").inviteLink("https://web.fluxer.app");
  assert.match(link, new RegExp(`client_id=${MIRROR_ID}&scope=bot&permissions=\\d+$`));
  const perms = BigInt(link.split("permissions=")[1]);
  assert.equal(perms & (1n << 3n), 0n, "not administrator");
  assert.equal(perms & (1n << 13n), 0n, "can't manage messages");
});

console.log("Catch-up");
const C = await import("../utils/CatchUp.js");
await test("finds the newest message ID numerically, not alphabetically", () => {
  assert.equal(C.maxSnowflake(["99", "100", null, "abc"]), "100");
  assert.equal(C.maxSnowflake([]), null);
});
await test("only bridges messages it hasn't seen, from people, inside the window", () => {
  const now = Date.now();
  const msgs = [
    { id: "1", createdTimestamp: now, author: { id: "person" } },
    { id: "2", createdTimestamp: now, author: { id: "person" } }, // already bridged
    { id: "3", createdTimestamp: now, author: { id: "self" } }, // the bridge's own bot
    { id: "4", createdTimestamp: now, author: { id: "hook" }, webhookId: "W" }, // bridged copy
    { id: "5", createdTimestamp: now - 9 * 86400000, author: { id: "person" } }, // too old
    { id: "6", createdAt: new Date(now), author: { id: MIRROR_ID } }, // a mirror
    { id: "7", createdAt: new Date(now), author: { id: "person2" } }, // Fluxer-style time
  ];
  const picked = C.pickMissed(msgs, {
    known: new Set(["2"]),
    cutoff: now - 3 * 86400000,
    selfId: "self",
    webhookId: "W",
    skipAuthor: M.isMirrorFluxerId,
  });
  assert.deepEqual(picked.map((m) => m.id), ["1", "7"]);
});

console.log(`\n${passed} checks passed${process.exitCode ? ", some failed" : ""}.`);
fs.rmSync(tmp, { recursive: true, force: true });
process.exit(process.exitCode ?? 0);
