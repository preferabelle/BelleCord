// offline tests: settings parsing, mirror lookups, ping and status mapping, posting as a mirror, catch-up.
// Run with:  npm run selftest
import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), "bridge-test-"));
const MAX_DISCORD = "111111111111111111";
const MIRROR_ID = "222222222222222222";
const MAIN_ID = "333333333333333333";
const SAM_MIRROR = "444444444444444444";
fs.writeFileSync(
  path.join(tmp, "settings.txt"),
  [
    "# test",
    `fluxer token: ${MAIN_ID}.mainsecretmainsecretmainsecret12`,
    "discord token: paste the Discord token here",
    "emoji community id: 555555555555555555",
    `mirror: Max | ${MAX_DISCORD} | ${MIRROR_ID}.mirrorsecretmirrorsecretmirror1`,
    `mirror: Sam | sam_user | ${SAM_MIRROR}.samsecretsamsecretsamsecret1234`,
    `mirror: Oops | 999999999999999999 | ${MAIN_ID}.mainsecretmainsecretmainsecret12`,
    "catch up days: 2",
    "mirror statuses: no",
  ].join("\n"),
);
process.env.BRIDGE_SETTINGS_FILE = path.join(tmp, "settings.txt");
process.env.BRIDGE_DATA_DIR = tmp;

let passed = 0;
async function test(name, fn) {
  try {
    await fn();
    passed++;
    console.log(`  ✓ ${name}`);
  } catch (e) {
    console.log(`  ✗ ${name}\n    ${e.stack ?? e}`);
    process.exitCode = 1;
  }
}

const { parseSettings, fluxerIdFromToken } = await import("../utils/Settings.js");
const Config = (await import("../utils/ConfigHandler.js")).default;
const M = await import("../utils/Mirrors.js");

console.log("Settings");
await test("reads tokens, IDs and options", () => {
  assert.equal(Config.FluxerBotToken, `${MAIN_ID}.mainsecretmainsecretmainsecret12`);
  assert.equal(Config.DiscordBotToken, "");
  assert.equal(Config.PracticeMode, true);
  assert.equal(Config.FluxerTempEmojiGuildId, "555555555555555555");
  assert.equal(Config.CatchUpDays, 2);
  assert.equal(Config.MirrorStatuses, false);
});
await test("bot ID comes from the token", () => {
  assert.equal(fluxerIdFromToken(`${MIRROR_ID}.abcdefghijklmnopqrstuvwxyz`), MIRROR_ID);
  assert.equal(fluxerIdFromToken("not a token"), null);
});
await test("mirror lines: ID, username, and the bridge's own token rejected", () => {
  assert.equal(Config.Mirrors.length, 2);
  const [max, sam] = Config.Mirrors;
  assert.deepEqual([max.name, max.discordId, max.fluxerId], ["Max", MAX_DISCORD, MIRROR_ID]);
  assert.deepEqual([sam.discordRef, sam.discordId], ["sam_user", null]);
  assert.ok(Config.SettingsProblems.some((p) => p.includes("Oops") && p.includes("own token")));
});
await test("the untouched template counts as blank, not as broken values", () => {
  // (the download has settings.example.txt; settings.txt is the owner's own copy)
  const own = new URL("../settings.txt", import.meta.url), example = new URL("../settings.example.txt", import.meta.url);
  const s = parseSettings(fs.readFileSync(fs.existsSync(example) ? example : own, "utf-8"));
  assert.equal(s.fluxerToken, "");
  assert.equal(s.problems.length, 0, s.problems.join(" / "));
  assert.equal(s.streams, true);
  assert.equal(s.streamAddress, "");
  assert.equal(s.discordToken, "");
  assert.equal(s.emojiCommunityId, "");
  assert.equal(s.mirrors.length, 0);
});
await test("Windows line endings and a BOM are fine", () => {
  const s = parseSettings(`\uFEFFfluxer token: ${MAIN_ID}.mainsecretmainsecretmainsecret12\r\ncatch up days: 0\r\n`);
  assert.equal(s.fluxerToken.startsWith(MAIN_ID), true);
  assert.equal(s.catchUpDays, 0);
});

console.log("Mirror lookups");
await test("mirror IDs are known before anything signs in", () => {
  assert.equal(M.isMirrorFluxerId(MIRROR_ID), true);
  assert.equal(M.isMirrorFluxerId(SAM_MIRROR), true);
  assert.equal(M.isMirrorFluxerId(MAIN_ID), false);
  assert.equal(M.getMirrorByDiscordId(MAX_DISCORD)?.name, "Max");
  assert.equal(M.getMirrorByName("max")?.name, "Max");
  assert.equal(M.getReadyMirrorForDiscordUser(MAX_DISCORD), null, "not ready until signed in");
});
await test("a username mirror links the first time that person posts", () => {
  M.noteDiscordAuthor({ id: "777777777777777777", username: "sam_user" }, null);
  assert.equal(M.getMirrorByName("Sam").discordId, "777777777777777777");
});

console.log("Pings");
await test("Discord ping of Max becomes a ping of his mirror", () => {
  assert.equal(M.discordMentionsToMirrors(`hi <@${MAX_DISCORD}>!`), `hi <@${MIRROR_ID}>!`);
  assert.equal(M.discordMentionsToMirrors(`<@!${MAX_DISCORD}>`), `<@${MIRROR_ID}>`);
  assert.equal(M.discordMentionsToMirrors("<@123456789012345678>"), "<@123456789012345678>");
});
await test("Fluxer ping of the mirror becomes a real Discord ping", () => {
  assert.equal(M.fluxerMentionsToDiscord(`<@${MIRROR_ID}> look`), `<@${MAX_DISCORD}> look`);
  assert.equal(M.fluxerMentionsToDiscord(null), null);
});

console.log("Status");
await test("Discord statuses map onto Fluxer", () => {
  assert.deepEqual(M.presenceFromDiscord(null), { status: "invisible", text: null, emoji: null });
  assert.equal(M.presenceFromDiscord({ status: "offline" }).status, "invisible");
  assert.equal(M.presenceFromDiscord({ status: "dnd", activities: [] }).status, "dnd");
});
await test("custom status wins, then Spotify, then games", () => {
  const custom = M.presenceFromDiscord({
    status: "online",
    activities: [
      { type: 2, name: "Spotify", details: "Song", state: "Artist" },
      { type: 4, state: "drawing", emoji: { id: null, name: "🎨" } },
    ],
  });
  assert.deepEqual(custom, { status: "online", text: "drawing", emoji: "🎨" });
  const spotify = M.presenceFromDiscord({
    status: "idle",
    activities: [
      { type: 0, name: "Minecraft" },
      { type: 2, name: "Spotify", details: "Song", state: "Artist" },
    ],
  });
  assert.deepEqual(spotify, { status: "idle", text: "Song · Artist", emoji: "🎧" });
  const game = M.presenceFromDiscord({ status: "online", activities: [{ type: 0, name: "Kingdom Hearts II" }] });
  assert.equal(game.text, "Playing Kingdom Hearts II");
});
await test("status text is capped at Fluxer's 128 characters", () => {
  const p = M.presenceFromDiscord({ status: "online", activities: [{ type: 4, state: "x".repeat(300) }] });
  assert.equal(Array.from(p.text).length, 128);
});
await test("status changes are spaced out to respect Fluxer's limit", async () => {
  const mirror = M.getMirrorByName("Max");
  const sent = [];
  mirror.ready = true;
  mirror.client = { user: { setPresence: (x) => sent.push(x) } };
  mirror.lastPresenceAt = 0;
  mirror.setPresence({ status: "online", text: "a", emoji: null });
  mirror.setPresence({ status: "dnd", text: "b", emoji: null }); // replaces the pending one
  await new Promise((r) => setTimeout(r, 1000));
  assert.equal(sent.length, 1, "coalesced into one update");
  assert.equal(sent[0].status, "dnd");
  assert.deepEqual(sent[0].customStatus, { text: "b", emojiName: null });
});

console.log("Posting as a mirror");
await test("sends to the channel route with files and reply", async () => {
  const mirror = M.getMirrorByName("Max");
  const calls = [];
  mirror.client = { rest: { post: async (route, opts) => (calls.push({ route, opts }), { id: "999" }) } };
  const res = await mirror.send("888888888888888888", {
    content: "hi",
    embeds: [],
    files: [{ name: "a.png", data: Buffer.from("x"), flags: 8 }, { name: "broken.png" }],
    message_reference: { message_id: "123" },
    allowed_mentions: { parse: ["users"] },
  });
  assert.equal(res.id, "999");
  assert.equal(calls[0].route, "/channels/888888888888888888/messages");
  assert.equal(calls[0].opts.auth, true);
  assert.equal(calls[0].opts.files.length, 1, "files without data are skipped");
  assert.deepEqual(calls[0].opts.body.attachments, [{ id: 0, filename: "a.png", flags: 8 }]);
  assert.deepEqual(calls[0].opts.body.message_reference, { message_id: "123" });
});
await test("no reply field is sent when it isn't a reply", async () => {
  const mirror = M.getMirrorByName("Max");
  let body;
  mirror.client = { rest: { post: async (_r, o) => ((body = o.body), { id: "1" }) } };
  await mirror.send("888888888888888888", { content: "plain", message_reference: undefined });
  assert.equal("message_reference" in body, false);
});
await test("invite link asks only for what a mirror needs", () => {
  const link = M.getMirrorByName("Max").inviteLink("https://web.fluxer.app");
  assert.match(link, new RegExp(`client_id=${MIRROR_ID}&scope=bot&permissions=\\d+$`));
  const perms = BigInt(link.split("permissions=")[1]);
  assert.equal(perms & (1n << 3n), 0n, "not administrator");
  assert.equal(perms & (1n << 13n), 0n, "can't manage messages");
});

console.log("Catch-up");
const C = await import("../utils/CatchUp.js");
await test("finds the newest message ID numerically, not alphabetically", () => {
  assert.equal(C.maxSnowflake(["99", "100", null, "abc"]), "100");
  assert.equal(C.maxSnowflake([]), null);
});
await test("only bridges messages it hasn't seen, from people, inside the window", () => {
  const now = Date.now();
  const msgs = [
    { id: "1", createdTimestamp: now, author: { id: "person" } },
    { id: "2", createdTimestamp: now, author: { id: "person" } }, // already bridged
    { id: "3", createdTimestamp: now, author: { id: "self" } }, // the bridge's own bot
    { id: "4", createdTimestamp: now, author: { id: "hook" }, webhookId: "W" }, // bridged copy
    { id: "5", createdTimestamp: now - 9 * 86400000, author: { id: "person" } }, // too old
    { id: "6", createdAt: new Date(now), author: { id: MIRROR_ID } }, // a mirror
    { id: "7", createdAt: new Date(now), author: { id: "person2" } }, // Fluxer-style time
  ];
  const picked = C.pickMissed(msgs, {
    known: new Set(["2"]),
    cutoff: now - 3 * 86400000,
    selfId: "self",
    webhookId: "W",
    skipAuthor: M.isMirrorFluxerId,
  });
  assert.deepEqual(picked.map((m) => m.id), ["1", "7"]);
});

console.log("Streams with BelleCord");
await test("stream settings: an address with no path, and a port", () => {
  const s = parseSettings("stream address: https://my-name.ngrok-free.app/\nstream port: 9001\nstreams: yes");
  assert.equal(s.streamAddress, "https://my-name.ngrok-free.app");
  assert.equal(s.streamPort, 9001);
  const bad = parseSettings("stream address: my-name.ngrok-free.app/path\nstream port: lots");
  assert.equal(bad.streamAddress, "");
  assert.equal(bad.streamPort, 0);
  assert.equal(bad.problems.length, 2);
  assert.equal(parseSettings("streams: no").streams, false);
  assert.equal(Config.Streams, true);
  assert.equal(Config.StreamPort, 0, "no address: any free port, on this computer only");
});

const { EventEmitter } = await import("node:events");
const { Events: FluxerEvents } = await import("@fluxerjs/core");
const VP = await import("../utils/VoicePresence.js");
await test("a seated mirror gets a second connection for a stream, and the seat isn't touched", async () => {
  const client = new EventEmitter();
  const sent = [];
  client.sendToGateway = (shard, msg) => {
    sent.push(msg.d);
    if (msg.d.channel_id && !msg.d.connection_id) setTimeout(() => client.emit(FluxerEvents.VoiceServerUpdate, { guild_id: "g1", endpoint: "voice.example", token: "pass2", connection_id: "extra1" }), 5);
  };
  const mirror = { fluxerId: "m-stream", discordId: "d-stream", name: "Tess", client, ready: true };
  VP.seats.set("m-stream", { mirror, guildId: "g1", channelId: "vc1", room: { fake: true }, connectionId: "seat1", mute: false, deaf: false });
  assert.equal(VP.mirrorSeated(mirror), true);
  const got = await VP.askExtraConnection(mirror, "publish");
  assert.deepEqual(got, { url: "wss://voice.example", token: "pass2", connectionId: "extra1" });
  assert.equal(sent[0].self_stream, true, "says it's streaming, so Fluxer shows it as live");
  assert.equal(sent[0].connection_id, undefined, "a new connection, not the seat");
  client.emit(FluxerEvents.VoiceServerUpdate, { guild_id: "g1", endpoint: "voice.example", token: "pass3", connection_id: "extra1" });
  assert.equal(VP.seats.get("m-stream").connectionId, "seat1");
  assert.equal(VP.dropExtraConnection(mirror, "extra1"), true);
  assert.deepEqual(sent.at(-1), { guild_id: "g1", channel_id: null, connection_id: "extra1" });
  const w = VP.extraVoiceState("g1", "vc1", "watch", "g1:vc1:abc");
  assert.deepEqual(w.viewer_stream_keys, ["g1:vc1:abc"]);
  assert.equal(w.self_deaf, false);
  VP.seats.delete("m-stream");
});

// the bridge bot's own seat (sitting in a channel) and one more connection for a stream
fs.writeFileSync(path.join(tmp, "vc.json"), JSON.stringify({ guildId: "g9", channelId: "vc9", name: "Hangout", discord: null }));
const H = await import("../utils/Hangout.js");
await test("the bridge bot's stream connection is its own, and an old seat of the bot is sent away", async () => {
  const client = new EventEmitter();
  client.user = { id: MAIN_ID };
  const sent = [];
  client.sendToGateway = (shard, msg) => sent.push(msg.d);
  let rooms = 0;
  H.deps.makeRoom = async () => { rooms++; const r = new EventEmitter(); r.isConnected = true; r.connect = async () => {}; r.disconnect = async () => { r.isConnected = false; }; return r; };
  H.attachHangout(client);
  await H.joinVc("g9", "vc9", "Hangout", () => {});
  await new Promise((r) => setTimeout(r, 1700)); // (it was set to that channel already, so it steps out and back in)
  assert.equal(sent.at(-1).channel_id, "vc9");
  assert.equal(sent.at(-1).connection_id, undefined);
  client.emit(FluxerEvents.VoiceServerUpdate, { guild_id: "g9", endpoint: "v.example", token: "t1", connection_id: "seatA" });
  await new Promise((r) => setTimeout(r, 20));
  client.emit(FluxerEvents.VoiceStateUpdate, { guild_id: "g9", user_id: MAIN_ID, channel_id: "vc9", connection_id: "seatA" });
  assert.equal(rooms, 1);
  assert.equal(H.bridgeSeat()?.connectionId, "seatA");
  const asking = H.askBridgeConnection("publish");
  const ask = sent.at(-1);
  assert.equal(ask.connection_id, undefined);
  assert.equal(ask.self_stream, true);
  // Fluxer says the new one is in the channel first: it's not a leftover, so nothing is sent away
  const before = sent.length;
  client.emit(FluxerEvents.VoiceStateUpdate, { guild_id: "g9", user_id: MAIN_ID, channel_id: "vc9", connection_id: "streamB" });
  assert.equal(sent.length, before);
  client.emit(FluxerEvents.VoiceServerUpdate, { guild_id: "g9", endpoint: "v.example", token: "t2", connection_id: "streamB" });
  const got = await asking;
  assert.equal(got.connectionId, "streamB");
  assert.equal(rooms, 1, "the call wasn't rebuilt");
  assert.equal(H.bridgeSeat()?.connectionId, "seatA");
  // news about the stream connection leaving doesn't make the bot leave
  client.emit(FluxerEvents.VoiceStateUpdate, { guild_id: "g9", user_id: MAIN_ID, channel_id: null, connection_id: "streamB" });
  assert.equal(H.bridgeSeat()?.connectionId, "seatA");
  // an old seat from before a reconnect, still sitting there: told to leave
  client.emit(FluxerEvents.VoiceStateUpdate, { guild_id: "g9", user_id: MAIN_ID, channel_id: "vc9", connection_id: "oldC" });
  assert.deepEqual(sent.at(-1), { guild_id: "g9", channel_id: null, connection_id: "oldC" });
  assert.equal(H.dropBridgeConnection("streamB"), true);
  assert.deepEqual(sent.at(-1), { guild_id: "g9", channel_id: null, connection_id: "streamB" });
  const was = await H.leaveVc();
  assert.equal(was.channelId, "vc9");
  assert.equal(sent.at(-1).channel_id, null);
  assert.equal(sent.at(-1).connection_id, "seatA", "leaving says which connection");
});

await test("two passes right after each other: one switch, and the old call only goes once the new one is in", async () => {
  const client = new EventEmitter();
  client.user = { id: MAIN_ID };
  client.sendToGateway = () => {};
  const made = [];
  H.deps.makeRoom = async () => { const r = new EventEmitter(); r.isConnected = true; r.connect = async () => {}; r.disconnect = async () => { r.isConnected = false; r.emit("disconnected"); }; made.push(r); return r; };
  H.attachHangout(client);
  await H.joinVc("g8", "vc8", "Hangout", () => {});
  client.emit(FluxerEvents.VoiceServerUpdate, { guild_id: "g8", endpoint: "a.example", token: "t1", connection_id: "S1" });
  await new Promise((r) => setTimeout(r, 30));
  client.emit(FluxerEvents.VoiceStateUpdate, { guild_id: "g8", user_id: MAIN_ID, channel_id: "vc8", connection_id: "S1" });
  client.emit(FluxerEvents.VoiceServerUpdate, { guild_id: "g8", endpoint: "b.example", token: "t2", connection_id: "S1" });
  await new Promise((r) => setTimeout(r, 200));
  client.emit(FluxerEvents.VoiceServerUpdate, { guild_id: "g8", endpoint: "c.example", token: "t3", connection_id: "S1" });
  await new Promise((r) => setTimeout(r, 1800));
  assert.equal(made.length, 2, "one switch for two passes");
  assert.equal(made[0].isConnected, false);
  assert.equal(made[1].isConnected, true);
  assert.equal(H.bridgeSeat()?.connectionId, "S1");
  await H.leaveVc();
});

const SB = await import("../utils/StreamBridge.js");
const VB = await import("../utils/VoiceBridge.js");
await test("who's streaming on Fluxer, for someone in the bridged call", () => {
  const pub = (source) => ({ source });
  const people = new Map([
    ["a", { identity: "user_100000000000000001_c1", name: "", trackPublications: new Map([["s", pub(3)], ["m", pub(2)]]) }],
    ["b", { identity: "user_100000000000000002_c2", name: "", trackPublications: new Map([["m", pub(2)]]) }],
    ["c", { identity: `user_${MIRROR_ID}_x7`, name: "", trackPublications: new Map([["s", pub(3)]]) }],
  ]);
  Object.assign(VB.state, {
    active: true,
    target: { guildId: "dg", channelId: "dvc", name: "General" },
    discordClient: { channels: { cache: new Map([["dvc", { members: new Map([[MAX_DISCORD, {}]]) }]]) } },
    room: { remoteParticipants: people },
    fluxerClient: { users: new Map([["100000000000000001", { username: "kai" }]]), guilds: new Map() },
  });
  SB.open.set("x7", { discordUserId: "someone", purpose: "publish", via: "mirror" }); // (a Discord stream this bridge put there)
  const i = SB.streamInfo({ discordUserId: MAX_DISCORD });
  assert.equal(i.inCall, true);
  assert.deepEqual(i.streams.map((s) => s.name), ["kai"]);
  assert.equal(i.channel, "General");
  assert.equal(SB.streamInfo({ discordUserId: "999999999999999998" }).inCall, false);
  SB.open.delete("x7");
});

const SS = await import("../utils/StreamServer.js");
await test("BelleCord on this computer, and a friend's own key", async () => {
  const server = SS.startStreamServer();
  await new Promise((r) => (server.listening ? r() : server.once("listening", r)));
  await new Promise((r) => setTimeout(r, 20));
  const here = JSON.parse(fs.readFileSync(path.join(tmp, "stream.json"), "utf-8"));
  assert.equal(server.address().address, "127.0.0.1", "only this computer, with no stream address");
  const ask = (body) => fetch(`http://127.0.0.1:${here.port}/v1/stream`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body) }).then(async (r) => ({ status: r.status, data: await r.json() }));
  const mine = await ask({ key: here.key, op: "info", discordUserId: MAX_DISCORD });
  assert.equal(mine.status, 200);
  assert.equal(mine.data.inCall, true);
  assert.equal((await ask({ key: "nope", op: "info", discordUserId: MAX_DISCORD })).status, 401);
  const k = SS.newFriendKey("888888888888888888");
  const friend = await ask({ key: k, op: "info", discordUserId: MAX_DISCORD }); // (a friend's key is only ever them)
  assert.equal(friend.status, 200);
  assert.equal(friend.data.inCall, false);
  const notIn = await ask({ key: k, op: "open", purpose: "watch" });
  assert.equal(notIn.status, 400);
  assert.match(notIn.data.error, /not in the bridged call/);
  SS.dropFriendKey("888888888888888888");
  assert.equal((await ask({ key: k, op: "info" })).status, 401);
  const page = await fetch(`http://127.0.0.1:${here.port}/bellecord/link`).then((r) => r.text());
  assert.match(page, /BelleCord/);
  server.close();
});

console.log(`\n${passed} checks passed${process.exitCode ? ", some failed" : ""}.`);
process.exit(process.exitCode ?? 0); // (the stream bridge's cleanup timer would keep it running)
fs.rmSync(tmp, { recursive: true, force: true });
process.exit(process.exitCode ?? 0);
