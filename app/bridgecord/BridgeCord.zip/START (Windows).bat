@echo off
title BridgeCord
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 goto nonode

if exist "node_modules\" goto run
echo First start: downloading the bridge's parts. This takes a minute or two...
call npm install --omit=dev --no-audit --no-fund
if errorlevel 1 goto installfail

:run
node launcher.js
echo.
pause
exit /b

:nonode
echo Node.js isn't installed yet.
echo Opening the download page. Install the LTS version, then double-click this file again.
start "" https://nodejs.org/en/download
pause
exit /b

:installfail
echo.
echo The download didn't finish. Check your internet connection and double-click this file again.
pause
exit /b
