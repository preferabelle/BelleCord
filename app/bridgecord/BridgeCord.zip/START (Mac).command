#!/bin/bash
cd "$(dirname "$0")"

if ! command -v node >/dev/null 2>&1; then
  echo "Node.js isn't installed yet."
  echo "Opening the download page. Install the LTS version, then double-click this file again."
  open "https://nodejs.org/en/download"
  read -r -p "Press Enter to close."
  exit 0
fi

if [ ! -d node_modules ]; then
  echo "First start: downloading the bridge's parts. This takes a minute or two..."
  if ! npm install --omit=dev --no-audit --no-fund; then
    echo "The download didn't finish. Check your internet connection and try again."
    read -r -p "Press Enter to close."
    exit 1
  fi
fi

node launcher.js
read -r -p "Press Enter to close."
