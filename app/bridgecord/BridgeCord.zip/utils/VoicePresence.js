// mirrors in voice.
// While the voice bridge is on, a Discord person who joins the bridged Discord voice
// channel gets their mirror bot joined to the bridged Fluxer voice channel (showing
// their muted/deafened state), and it leaves when they leave. The mirror doesn't
// carry any sound; it's there so Fluxer people can see who's in the call.
import { Events as FluxerEvents } from "@fluxerjs/core";
import { log } from "./Logger.js";
import { getMirrorByDiscordId, mirrors } from "./Mirrors.js";
import { Mixer } from "./AudioMixer.js";

/** Swappable for tests. */
export const deps = {
  async makeRoom() {
    const { Room } = await import("@livekit/rtc-node");
    return new Room();
  },
};

/** @type {Map<string, {mirror: any, guildId: string, channelId: string, mute: boolean, deaf: boolean, room: any, connectionId: string|null, tries: number, timer: any}>} */
export const seats = new Map();

function sendState(seat, channelId) {
  seat.mirror.client?.sendToGateway?.(0, {
    op: 4,
    d: {
      guild_id: seat.guildId,
      channel_id: channelId,
      self_mute: channelId ? seat.mute : false,
      self_deaf: channelId ? seat.deaf : false,
      // (leaving too: in a community, Fluxer refuses a "leave" that doesn't say which connection)
      ...(seat.connectionId ? { connection_id: seat.connectionId } : {}),
    },
  });
}

async function dropRoom(seat) {
  seat.mixer?.stop();
  seat.mixer = null;
  seat.source = null;
  const track = seat.track;
  seat.track = null;
  await track?.close?.().catch?.(() => {});
  const r = seat.room;
  seat.room = null;
  if (r) await r.disconnect().catch(() => {});
}

/** Give a seated mirror its own voice: it speaks whatever its Discord person says. */
async function startVoice(seat, r) {
  const lk = await import("@livekit/rtc-node");
  const source = new lk.AudioSource(48000, 2);
  const track = lk.LocalAudioTrack.createAudioTrack("voice", source);
  const opts = new lk.TrackPublishOptions();
  opts.source = lk.TrackSource.SOURCE_MICROPHONE;
  await r.localParticipant.publishTrack(track, opts);
  let pending = 0;
  // Same smoothing as the main bridge: a small buffer, and riding out tiny network gaps.
  const mixer = new Mixer(
    (frame) => {
      if (seat.source !== source || pending > 25) return;
      pending++;
      source.captureFrame(new lk.AudioFrame(frame, 48000, 2, 960)).catch(() => {}).finally(() => pending--);
    },
    { primeFrames: 5, graceFrames: 3 },
  );
  mixer.start();
  Object.assign(seat, { source, track, mixer });
}

/**
 * Discord audio for one person: if their mirror is seated in the call, it speaks it
 * (so Fluxer shows them talking and lets people turn them down). `level` is their
 * bridge volume (0 = muted). Returns false if they have no seated mirror.
 */
export function sendToMirror(discordUserId, samples, level = 100) {
  for (const seat of seats.values()) {
    if (seat.mirror.discordId === discordUserId && seat.mixer) {
      if (level > 0) seat.mixer.push("voice", samples);
      else seat.mixer.clear(); // muted: drop whatever's buffered so it stops immediately
      return true;
    }
  }
  return false;
}

/** Fluxer IDs of mirrors, so the bridge never relays a mirror's voice back to Discord. */
export function isMirrorVoice(identity) {
  const id = String(identity ?? "");
  return mirrors.some((m) => id.includes(m.fluxerId));
}

async function connect(seat, endpoint, token) {
  clearTimeout(seat.timer);
  await dropRoom(seat);
  const url = /^wss?:\/\//i.test(endpoint) ? endpoint : `wss://${endpoint}`;
  let r;
  try {
    r = await deps.makeRoom();
    seat.room = r;
    r.on("disconnected", () => {
      if (seat.room !== r || seats.get(seat.mirror.fluxerId) !== seat) return;
      seat.room = null;
      retry(seat, "the voice server hung up");
    });
    await r.connect(url, token, { autoSubscribe: false, dynacast: false });
    if (seats.get(seat.mirror.fluxerId) !== seat) { try { await r.disconnect(); } catch {} return; } // told to leave while connecting
    seat.tries = 0;
    await startVoice(seat, r).catch((e) => log("MIRROR", `${seat.mirror.name} joined voice but can't speak: ${e?.message ?? e}`));
    if (seats.get(seat.mirror.fluxerId) !== seat) { try { await r.disconnect(); } catch {} sendState(seat, null); return; }
    sendState(seat, seat.channelId); // confirm, with their muted/deafened state
    log("MIRROR", `${seat.mirror.name} joined voice (following them on Discord).`);
  } catch (e) {
    if (seat.room === r) seat.room = null;
    retry(seat, e?.message ?? "couldn't connect");
  }
}

function retry(seat, why) {
  if (seats.get(seat.mirror.fluxerId) !== seat) return;
  seat.tries++;
  if (seat.tries > 3) {
    log("MIRROR", `${seat.mirror.name} keeps failing to join voice (${why}). It may not be allowed to Connect to that channel.`);
    return;
  }
  clearTimeout(seat.timer);
  seat.timer = setTimeout(() => ask(seat), 5000 * seat.tries);
}

function ask(seat) {
  if (seats.get(seat.mirror.fluxerId) !== seat || !seat.mirror.ready) return;
  seat.connectionId = null;
  sendState(seat, seat.channelId);
  clearTimeout(seat.timer);
  seat.timer = setTimeout(() => {
    if (seats.get(seat.mirror.fluxerId) === seat && !seat.room) retry(seat, "Fluxer never answered");
  }, 15_000);
}

// ---- more connections for a seated mirror (StreamBridge.js): its person's stream on Fluxer, or watching one ----
// Fluxer lets one account be in a call from a few places at once (like a phone and a PC). A mirror's seat is one of
// them; a stream is another, made here and handed to that person's BelleCord, which talks to the call by itself
// (none of the video goes through the bridge). Each one is told apart from the seat by its connection_id.

/** What one of those connections tells Fluxer about itself. The bridge bot's own (Hangout.js) use it too. */
export function extraVoiceState(guildId, channelId, purpose, streamKey = null) {
  return {
    guild_id: guildId,
    channel_id: channelId,
    self_mute: true,
    self_deaf: purpose !== "watch",
    // a stream connection says it's streaming, so Fluxer shows it as live (and Watch) to everyone in the call
    ...(purpose === "publish" ? { self_stream: true } : {}),
    // a watching one says what it watches, so the person streaming sees who's watching
    ...(purpose === "watch" && streamKey ? { viewer_stream_keys: [streamKey] } : {}),
  };
}

const extras = new Map(); // mirror.fluxerId -> { waiting: fn | null, conns: Map(connectionId -> { purpose, guildId }), gone: Set }
function takeExtra(mirror, d) {
  const x = extras.get(mirror.fluxerId);
  if (!x) return false;
  if (d?.connection_id && (x.conns.has(d.connection_id) || x.gone.has(d.connection_id))) return true; // (news about one of them, not the seat)
  const seat = seats.get(mirror.fluxerId);
  if (!x.waiting || !seat?.room || !seat.connectionId || d?.guild_id !== seat.guildId || !d?.endpoint || !d?.token || !d?.connection_id) return false;
  if (d.connection_id === seat.connectionId) return false;
  const done = x.waiting;
  x.waiting = null;
  done(d);
  return true;
}

/** Is this mirror in the call (connected), so it can open another connection? */
export function mirrorSeated(mirror) {
  const seat = mirror ? seats.get(mirror.fluxerId) : null;
  return !!(seat?.room && seat.connectionId);
}

/** Ask Fluxer for one more connection for this mirror. Resolves { url, token, connectionId }. */
export function askExtraConnection(mirror, purpose = "watch", { streamKey = null, timeoutMs = 12_000 } = {}) {
  const seat = seats.get(mirror.fluxerId);
  if (!seat?.room || !seat.connectionId) return Promise.reject(new Error("their mirror isn't in the Fluxer call yet"));
  hook(mirror);
  const x = extras.get(mirror.fluxerId) ?? { waiting: null, conns: new Map(), gone: new Set() };
  extras.set(mirror.fluxerId, x);
  if (x.waiting) return Promise.reject(new Error("already setting one up, try again in a moment"));
  return new Promise((ok, no) => {
    const timer = setTimeout(() => { if (x.waiting === got) x.waiting = null; no(new Error("Fluxer didn't answer (the call may have too many connections)")); }, timeoutMs);
    const got = (d) => {
      clearTimeout(timer);
      x.conns.set(d.connection_id, { purpose, guildId: seat.guildId });
      ok({ url: /^wss?:\/\//i.test(d.endpoint) ? d.endpoint : `wss://${d.endpoint}`, token: d.token, connectionId: d.connection_id });
    };
    x.waiting = got;
    mirror.client?.sendToGateway?.(0, { op: 4, d: extraVoiceState(seat.guildId, seat.channelId, purpose, streamKey) });
  });
}

/** That connection leaves the call. */
export function dropExtraConnection(mirror, connectionId) {
  const x = extras.get(mirror?.fluxerId);
  const c = x?.conns.get(connectionId);
  if (!c) return false;
  x.conns.delete(connectionId);
  x.gone.add(connectionId); // (anything Fluxer still says about it later isn't the seat's either)
  if (x.gone.size > 200) x.gone = new Set([...x.gone].slice(-100));
  try { mirror.client?.sendToGateway?.(0, { op: 4, d: { guild_id: c.guildId, channel_id: null, connection_id: connectionId } }); } catch {}
  return true;
}

function dropAllExtras(mirror) {
  const x = extras.get(mirror?.fluxerId);
  if (!x) return;
  for (const id of [...x.conns.keys()]) dropExtraConnection(mirror, id);
  x.waiting = null;
}

/** Listen for Fluxer's voice-server answers on a mirror's own connection (once per mirror). */
function hook(mirror) {
  if (mirror.__voiceHooked || !mirror.client) return;
  mirror.__voiceHooked = true;
  mirror.client.on(FluxerEvents.VoiceServerUpdate, (d) => {
    if (takeExtra(mirror, d)) return; // (a stream's own connection, see above)
    const seat = seats.get(mirror.fluxerId);
    if (!seat || d?.guild_id !== seat.guildId || !d?.endpoint || !d?.token) return;
    seat.connectionId = d.connection_id ?? null;
    connect(seat, d.endpoint, d.token);
  });
  // Signed in late (or reconnected)? Take the seat now.
  mirror.client.on(FluxerEvents.Ready, () => {
    const seat = seats.get(mirror.fluxerId);
    if (seat) setTimeout(() => ask(seat), 2000);
  });
}

export function mirrorJoin(mirror, guildId, channelId, flags) {
  hook(mirror);
  const old = seats.get(mirror.fluxerId);
  if (old && old.channelId === channelId && old.guildId === guildId) return mirrorFlags(mirror, flags);
  if (old) mirrorLeave(mirror);
  const seat = { mirror, guildId, channelId, mute: !!flags?.mute, deaf: !!flags?.deaf, room: null, connectionId: null, tries: 0, timer: null };
  seats.set(mirror.fluxerId, seat);
  ask(seat);
}

export function mirrorFlags(mirror, flags) {
  const seat = seats.get(mirror.fluxerId);
  if (!seat) return;
  const mute = !!flags?.mute, deaf = !!flags?.deaf;
  if (seat.mute === mute && seat.deaf === deaf) return;
  seat.mute = mute;
  seat.deaf = deaf;
  if (seat.room) sendState(seat, seat.channelId);
}

export async function mirrorLeave(mirror) {
  const seat = seats.get(mirror.fluxerId);
  if (!seat) return;
  seats.delete(mirror.fluxerId);
  clearTimeout(seat.timer);
  dropAllExtras(mirror); // (their stream leaves with them)
  await dropRoom(seat);
  sendState(seat, null);
  log("MIRROR", `${mirror.name} left voice.`);
}

export async function leaveAllMirrors() {
  for (const seat of [...seats.values()]) await mirrorLeave(seat.mirror);
}

const flagsOf = (voice) => ({ mute: !!(voice?.selfMute || voice?.serverMute), deaf: !!(voice?.selfDeaf || voice?.serverDeaf) });

/**
 * A Discord voice state changed. `want` is the saved voice setup (from Hangout.currentVc()).
 */
export function onDiscordVoiceState(oldState, newState, want) {
  if (!want?.discord) return;
  const userId = newState?.id ?? oldState?.id;
  const mirror = getMirrorByDiscordId(userId);
  if (!mirror) return;
  const target = want.discord.channelId;
  const inNow = newState?.channelId === target;
  const inBefore = oldState?.channelId === target;
  if (inNow && !inBefore) mirrorJoin(mirror, want.guildId, want.channelId, flagsOf(newState));
  else if (!inNow && inBefore) mirrorLeave(mirror);
  else if (inNow) mirrorFlags(mirror, flagsOf(newState));
}

/** Match mirrors to whoever is in the Discord voice channel right now (bridge start / restart). */
export async function syncVoicePresence(discordClient, want) {
  if (!want?.discord) return leaveAllMirrors();
  const channel = discordClient?.channels?.cache?.get(want.discord.channelId);
  const here = new Map();
  for (const member of channel?.members?.values?.() ?? []) here.set(member.id, member);
  for (const seat of [...seats.values()]) {
    if (!here.has(seat.mirror.discordId)) await mirrorLeave(seat.mirror);
  }
  for (const [id, member] of here) {
    const mirror = getMirrorByDiscordId(id);
    if (mirror) mirrorJoin(mirror, want.guildId, want.channelId, flagsOf(member.voice));
  }
}

export function presenceStatus() {
  return [...seats.values()].map((s) => `${s.mirror.name}${s.room ? "" : " (joining)"}`);
}
