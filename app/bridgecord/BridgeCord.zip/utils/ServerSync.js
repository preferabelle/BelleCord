// Make a Discord server match the Fluxer server it's bridged to.
// Copies the Fluxer server's name and icon, its roles (names, colors, permissions, order, shown separately,
// mentionable), its categories, and its text and voice channels (names, topics, age-restricted, slowmode, order,
// category, user limits, and role permission overrides), then bridges every text and voice channel that isn't
// bridged yet. Things already on Discord are matched up and updated, never duplicated: channels by an existing
// bridge first, then by name, then by what they're for ("memes" goes with "shitposts", and the Discord one
// gets renamed). A new channel is only made when nothing on Discord is like it. Discord channels Fluxer doesn't have
// are moved to the bottom. "clean" deletes those and the roles the Fluxer server doesn't have (never roles that
// belong to bots, and never channels bridged to anything).
// Each bridged pair is its own thing: a Discord server only ever gets copied from the Fluxer server it's bridged to.
// Used by bb!syncserver.
import { ChannelType, PermissionFlagsBits } from "discord.js";
import { Routes as FluxerRoutes } from "@fluxerjs/core";
import { Op } from "sequelize";
import { ChannelMap, GuildMap, VoiceChannelMap } from "../db/index.js";
import { log } from "./Logger.js";
import fs from "node:fs";
import path from "node:path";
import Config from "./ConfigHandler.js";

// (which Fluxer icon was copied last, so the same icon isn't uploaded again every time)
const MEMO = path.join(Config.DataFolderPath, "server-sync.json");
const memo = (() => { try { return JSON.parse(fs.readFileSync(MEMO, "utf-8")); } catch { return {}; } })();
const saveMemo = () => { try { fs.writeFileSync(MEMO, JSON.stringify(memo, null, 1)); } catch {} };

const norm = (n) => String(n ?? "").toLowerCase().trim().replace(/\s+/g, "-").replace(/[^\p{L}\p{N}_-]/gu, "").replace(/-+/g, "-").replace(/^-+|-+$/g, "");
const roleNorm = (n) => String(n ?? "").toLowerCase().trim();
// (Fluxer's permission bits are the same as Discord's, plus two of its own: those are dropped)
const DISCORD_BITS = Object.values(PermissionFlagsBits).reduce((a, b) => a | BigInt(b), 0n);
const perms = (p) => BigInt(p ?? 0) & DISCORD_BITS;
const F_TEXT = 0, F_VOICE = 2, F_CAT = 4, F_NEWS = 5;
const F_LINK = 998; // (a Fluxer link channel: Discord has nothing like it)
const kindOf = (t) => (t === F_CAT ? "category" : t === F_VOICE ? "voice" : t === F_TEXT || t === F_NEWS ? "text" : null);
const dKind = (c) => (c.type === ChannelType.GuildCategory ? "category" : c.type === ChannelType.GuildVoice || c.type === ChannelType.GuildStageVoice ? "voice" : c.type === ChannelType.GuildText || c.type === ChannelType.GuildAnnouncement || c.type === ChannelType.GuildForum ? "text" : null);

// ---- which leftover channels are "the same thing" as which (for renaming instead of making new ones)
// Words in common decide, plus channel names that usually mean the same kind of place.
const KINDS = [
  ["general", "chat", "main", "lounge", "talk", "hangout", "chill"],
  ["memes", "meme", "shitposts", "shitpost", "funny", "humor", "jokes"],
  ["games", "game", "gaming", "gamers", "play"],
  ["music", "songs", "song", "tunes", "spotify", "playlist"],
  ["media", "pics", "pictures", "photos", "images", "clips", "videos", "art"],
  ["announcements", "announcement", "news", "updates", "announce"],
  ["rules", "info", "information", "readme", "faq", "guidelines"],
  ["welcome", "lobby", "introductions", "intros", "join", "arrivals"],
  ["off-topic", "offtopic", "random", "misc", "other"],
  ["bots", "bot", "commands", "bot-commands", "botspam", "spam"],
  ["voice", "vc", "call", "calls"],
  ["mods", "staff", "admins", "moderators", "mod-chat", "staff-chat"],
];
const kindOf2 = (w) => KINDS.findIndex((k) => k.includes(w));
const words = (n) => norm(n).split(/[-_]+/).filter((w) => w.length > 1);
function guessPairs(leftF, leftD) {
  const out = [], used = new Set();
  for (const fc of leftF) {
    const fw = words(fc.name), fn = norm(fc.name);
    const fk = new Set([...fw, fn].map(kindOf2).filter((k) => k >= 0));
    let best = null, score = 0;
    for (const d of leftD) {
      if (used.has(d.id)) continue;
      const dn = norm(d.name), dw = words(d.name);
      let s = dw.filter((w) => fw.includes(w)).length;
      if (fn.length > 2 && dn.length > 2 && (fn.includes(dn) || dn.includes(fn))) s += 1;
      if ([...dw, dn].map(kindOf2).some((k) => k >= 0 && fk.has(k))) s += 1;
      if (s > score) { score = s; best = d; }
    }
    if (best) { out.push([String(fc.id), best.id]); used.add(best.id); }
  }
  return out;
}
export async function similarPairs(_a, _b, _kind, leftF, leftD) {
  return guessPairs(leftF, leftD);
}

/** The Discord server a Fluxer server is bridged to (the one most of its bridges go to). */
export async function linkedDiscordServer(fluxerGuildId) {
  const rows = await ChannelMap.findAll({ where: { fluxerGuildId: String(fluxerGuildId) }, raw: true }).catch(() => []);
  const count = new Map();
  for (const r of rows) if (r.discordGuildId) count.set(r.discordGuildId, (count.get(r.discordGuildId) ?? 0) + 1);
  return [...count.entries()].sort((a, b) => b[1] - a[1])[0]?.[0] ?? null;
}

/** The Fluxer server a Discord server is bridged to (the one most of its bridges go to). */
export async function linkedFluxerServer(discordGuildId) {
  const rows = await ChannelMap.findAll({ where: { discordGuildId: String(discordGuildId) }, raw: true }).catch(() => []);
  const count = new Map();
  for (const r of rows) if (r.fluxerGuildId) count.set(r.fluxerGuildId, (count.get(r.fluxerGuildId) ?? 0) + 1);
  return [...count.entries()].sort((a, b) => b[1] - a[1])[0]?.[0] ?? null;
}

/** Everything about the Fluxer server that gets copied. */
async function readFluxer(fluxerClient, fid) {
  const [guild, roles, channels] = await Promise.all([
    fluxerClient.rest.get(FluxerRoutes.guild(fid), { auth: true }).catch(() => null),
    fluxerClient.rest.get(FluxerRoutes.guildRoles(fid), { auth: true }).catch(() => null),
    fluxerClient.rest.get(FluxerRoutes.guildChannels(fid), { auth: true }).catch(() => null),
  ]);
  if (!guild || !Array.isArray(channels)) throw new Error("I couldn't read that Fluxer server. Is the bot in it?");
  return { guild, roles: Array.isArray(roles) ? roles : guild.roles ?? [], channels };
}

/**
 * What would change. Returns { lines (a readable list), steps (to apply), counts }.
 * clean: also remove Discord roles the Fluxer server doesn't have. (Channels are never removed.)
 */
export async function planSync(dGuild, fluxerClient, fid, { clean = false, keep = [] } = {}) {
  const F = await readFluxer(fluxerClient, fid);
  await dGuild.roles.fetch().catch(() => {});
  await dGuild.channels.fetch().catch(() => {});
  const me = dGuild.members.me ?? (await dGuild.members.fetchMe().catch(() => null));
  const top = me?.roles?.highest?.position ?? 0;
  const steps = [], lines = [], skipped = [];
  const counts = { roles: 0, channels: 0, bridges: 0, removed: 0 };

  // ---- server name and icon
  const icon = F.guild.icon ? `https://fluxerusercontent.com/icons/${fid}/${F.guild.icon}.${String(F.guild.icon).startsWith("a_") ? "gif" : "png"}?size=512` : null;
  if (F.guild.name && F.guild.name !== dGuild.name) { steps.push({ t: "guildName", name: F.guild.name }); lines.push(`Rename the server to "${F.guild.name}"`); }
  if (icon && (F.guild.icon !== memo[dGuild.id]?.icon || !dGuild.icon)) { steps.push({ t: "guildIcon", url: icon, hash: F.guild.icon }); lines.push("Use the Fluxer server's icon"); }

  // ---- roles (highest first on Fluxer = highest on Discord)
  const fRoles = F.roles.filter((r) => r && String(r.id) !== String(fid)).sort((a, b) => (b.position ?? 0) - (a.position ?? 0));
  const fEveryone = F.roles.find((r) => String(r.id) === String(fid));
  const dRoles = [...dGuild.roles.cache.values()];
  const roleFor = new Map(); // Fluxer role id -> Discord role (or a step that will create it)
  const usedD = new Set();
  for (const fr of fRoles) {
    const d = dRoles.find((x) => !usedD.has(x.id) && !x.managed && x.id !== dGuild.id && roleNorm(x.name) === roleNorm(fr.name));
    const want = { name: String(fr.name).slice(0, 100), color: Number(fr.color ?? 0), hoist: !!fr.hoist, mentionable: !!fr.mentionable, permissions: perms(fr.permissions) };
    if (d) {
      usedD.add(d.id);
      roleFor.set(String(fr.id), { id: d.id });
      if (d.position >= top) { skipped.push(`role "${d.name}" (it's above the bot's own role)`); continue; }
      const diff = d.name !== want.name || d.color !== want.color || d.hoist !== want.hoist || d.mentionable !== want.mentionable || d.permissions.bitfield !== want.permissions;
      if (diff) { steps.push({ t: "roleEdit", id: d.id, ...want }); lines.push(`Update role "${want.name}"`); counts.roles++; }
    } else {
      const ref = { id: null, fluxerId: String(fr.id) };
      roleFor.set(String(fr.id), ref);
      steps.push({ t: "roleNew", ref, ...want }); lines.push(`Create role "${want.name}"`); counts.roles++;
    }
  }
  if (fEveryone) {
    const p = perms(fEveryone.permissions);
    if (dGuild.roles.everyone.permissions.bitfield !== p) { steps.push({ t: "everyone", permissions: p }); lines.push("Update @everyone's permissions"); }
  }
  steps.push({ t: "roleOrder", order: fRoles.map((r) => roleFor.get(String(r.id))) });
  if (clean) for (const d of dRoles) {
    if (usedD.has(d.id) || d.managed || d.id === dGuild.id || d.position >= top) continue;
    steps.push({ t: "roleDel", id: d.id }); lines.push(`Delete role "${d.name}" (not on Fluxer)`); counts.removed++;
  }

  // ---- channels
  const maps = await ChannelMap.findAll({ where: { discordGuildId: dGuild.id }, raw: true }).catch(() => []);
  const vmaps = await VoiceChannelMap.findAll({ where: { discordGuildId: dGuild.id }, raw: true }).catch(() => []);
  const bridgedTo = new Map(); // Fluxer channel -> Discord channel
  for (const m of maps) if (m.fluxerChannelId && m.discordChannelId) bridgedTo.set(String(m.fluxerChannelId), String(m.discordChannelId));
  for (const m of vmaps) if (m.fluxerChannelId && m.discordChannelId) bridgedTo.set(String(m.fluxerChannelId), String(m.discordChannelId));
  const otherServer = new Set(maps.filter((m) => String(m.fluxerGuildId) !== String(fid)).map((m) => String(m.discordChannelId)));
  const dChans = [...dGuild.channels.cache.values()].filter((c) => dKind(c));
  const usedC = new Set();
  const chanFor = new Map(); // Fluxer channel id -> { id } (or a ref filled in when created)
  const fChans = F.channels.filter((c) => kindOf(c.type)).sort((a, b) => (a.position ?? 0) - (b.position ?? 0));
  for (const c of F.channels) if (Number(c.type) === F_LINK) skipped.push(`🔗${c.name} (Discord doesn't have link channels)`);
  const overwrites = (fc) => (fc.permission_overwrites ?? []).filter((o) => o && (Number(o.type) === 0 || o.type === "role")).map((o) => {
    const role = String(o.id) === String(fid) ? { id: dGuild.id } : roleFor.get(String(o.id));
    return role ? { role, allow: perms(o.allow), deny: perms(o.deny) } : null;
  }).filter(Boolean);

  // Matching each Fluxer channel to a Discord one, per kind (categories first, so channels know their category):
  //   1. already bridged to it   2. same name   3. a Discord channel that's for the same thing ("memes" and
  //   "shitposts", "general" and "chat"): these get paired up and renamed to the Fluxer name
  // Only a Fluxer channel with no match at all gets a new Discord channel. Channels are never deleted.
  for (const kind of ["category", "text", "voice"]) {
    const fl = fChans.filter((c) => kindOf(c.type) === kind);
    const match = new Map(); // Fluxer id -> Discord channel
    const free = (x) => !usedC.has(x.id) && !otherServer.has(x.id) && dKind(x) === kind;
    for (const fc of fl) {
      const via = bridgedTo.get(String(fc.id));
      const d = via ? dChans.find((x) => x.id === via) : null;
      if (d) { match.set(String(fc.id), d); usedC.add(d.id); }
    }
    for (const fc of fl) {
      if (match.has(String(fc.id))) continue;
      const parentD = fc.parent_id ? chanFor.get(String(fc.parent_id))?.id ?? null : null;
      const same = dChans.filter((x) => free(x) && norm(x.name) === norm(fc.name));
      const d = same.find((x) => (x.parentId ?? null) === parentD) ?? same[0];
      if (d) { match.set(String(fc.id), d); usedC.add(d.id); }
    }
    const leftF = fl.filter((fc) => !match.has(String(fc.id)));
    const leftD = dChans.filter(free);
    if (leftF.length && leftD.length) {
      for (const [fId, dId] of await similarPairs(dGuild.id, fid, kind, leftF, leftD)) {
        const d = leftD.find((x) => x.id === dId);
        if (!d || usedC.has(d.id) || match.has(fId)) continue;
        match.set(fId, d); usedC.add(d.id);
      }
    }

    for (const fc of fl) {
      const parentRef = fc.parent_id ? chanFor.get(String(fc.parent_id)) ?? null : null;
      const parentD = parentRef?.id ?? null;
      const d = match.get(String(fc.id)) ?? null;
      const want = { name: String(fc.name).slice(0, 100), kind, topic: kind === "text" ? String(fc.topic ?? "").slice(0, 1024) : undefined, nsfw: !!fc.nsfw, slowmode: Math.min(21600, Number(fc.rate_limit_per_user ?? 0)), userLimit: kind === "voice" ? Math.min(99, Number(fc.user_limit ?? 0)) : undefined, overwrites: overwrites(fc), parentRef, fluxerId: String(fc.id), fluxerType: fc.type, position: fc.position ?? 0 };
      const mark = kind === "category" ? "category " : kind === "voice" ? "🔊 " : "#";
      if (d) {
        const ref = { id: d.id };
        chanFor.set(String(fc.id), ref);
        const renamed = norm(d.name) !== norm(want.name);
        const diff = renamed || (kind === "text" && (d.topic ?? "") !== want.topic) || (kind !== "category" && (!!d.nsfw !== want.nsfw || (d.rateLimitPerUser ?? 0) !== want.slowmode)) || (kind === "voice" && (d.userLimit ?? 0) !== want.userLimit) || (kind !== "category" && (d.parentId ?? null) !== parentD);
        steps.push({ t: "chanEdit", ref, ...want, quiet: !diff });
        if (renamed) { lines.push(`Rename ${mark}${d.name} to ${mark}${want.name}`); counts.channels++; }
        else if (kind !== "category" && (d.parentId ?? null) !== parentD) { const cat = fChans.find((x) => String(x.id) === String(fc.parent_id))?.name; lines.push(`Move ${mark}${want.name} ${cat ? `into "${cat}"` : "out of its category"}`); counts.channels++; }
        else if (diff) { lines.push(`Update ${mark}${want.name}`); counts.channels++; }
      } else {
        const ref = { id: null };
        chanFor.set(String(fc.id), ref);
        steps.push({ t: "chanNew", ref, ...want });
        lines.push(`Create ${kind === "category" ? "category " + want.name : (kind === "voice" ? "voice channel 🔊 " : "channel #") + want.name} (nothing on Discord is like it)`); counts.channels++;
      }
      if (kind !== "category" && !bridgedTo.has(String(fc.id))) { steps.push({ t: "bridge", ref: chanFor.get(String(fc.id)), fluxerId: String(fc.id), kind }); lines.push(`Bridge ${mark}${want.name}`); counts.bridges++; }
    }
  }
  // Discord channels the Fluxer server doesn't have: they go to the bottom (of their category), so the rest is in the
  // same order as Fluxer. "clean" deletes them, unless they're bridged to some other Fluxer server.
  const extras = dChans.filter((x) => !usedC.has(x.id) && !otherServer.has(x.id));
  const bridgedHere = new Set(maps.map((m) => String(m.discordChannelId)));
  const kids = (cat) => dChans.filter((x) => x.parentId === cat.id);
  for (const x of extras) {
    const mark = dKind(x) === "category" ? "category " : dKind(x) === "voice" ? "🔊 " : "#";
    // (a category is only deleted when everything in it goes too)
    const goes = clean && !bridgedHere.has(x.id) && !keep.map(String).includes(String(x.id)) && (dKind(x) !== "category" || kids(x).every((k) => extras.includes(k) && !bridgedHere.has(k.id)));
    if (goes) { steps.push({ t: "chanDel", id: x.id, name: x.name }); lines.push(`Delete ${mark}${x.name} (not on Fluxer)`); counts.removed++; }
    else lines.push(`Move ${mark}${x.name} to the bottom (not on Fluxer)`);
  }
  // how each side is laid out, as the bot sees it (bb!syncserver layout)
  const mk = (k, n) => (k === "voice" ? "🔊" : k === "category" ? "" : Number(n) === F_LINK ? "🔗" : "#");
  const tree = (list, kOf, parentOf, posOf) => {
    const top = list.filter((c) => !parentOf(c) && kOf(c) !== "category").sort((a, b) => posOf(a) - posOf(b));
    const cats = list.filter((c) => kOf(c) === "category").sort((a, b) => posOf(a) - posOf(b));
    const out = top.map((c) => `${mk(kOf(c), c.type)}${c.name}`);
    for (const cat of cats) {
      out.push(`**${cat.name}**`);
      for (const c of list.filter((x) => String(parentOf(x) ?? "") === String(cat.id)).sort((a, b) => posOf(a) - posOf(b))) out.push(`  ${mk(kOf(c), c.type)}${c.name}`);
    }
    const lost = list.filter((c) => parentOf(c) && !cats.some((x) => String(x.id) === String(parentOf(c))));
    for (const c of lost) out.push(`${mk(kOf(c), c.type)}${c.name} (in a category the bot can't see)`);
    return out.join("\n");
  };
  const layout = {
    fluxer: tree(F.channels.filter((c) => kindOf(c.type) || Number(c.type) === F_LINK), (c) => kindOf(c.type), (c) => c.parent_id ?? null, (c) => c.position ?? 0),
    discord: tree(dChans.filter((c) => !extras.includes(c) || !clean), dKind, (c) => c.parentId ?? null, (c) => c.rawPosition ?? c.position ?? 0),
  };
  return { steps, lines, skipped, counts, fluxerName: F.guild.name, fid, extras: extras.map((x) => x.id), layout };
}

/** Do it. progress(text) is called now and then. Returns a short report. */
/** Discord servers being copied onto right now (the server link leaves their new channels alone meanwhile). */
export const syncing = new Set();
export async function applySync(dGuild, fluxerClient, plan, progress = () => {}) {
  syncing.add(dGuild.id);
  try { return await applySyncNow(dGuild, fluxerClient, plan, progress); } finally { setTimeout(() => syncing.delete(dGuild.id), 10_000); }
}
async function applySyncNow(dGuild, fluxerClient, plan, progress) {
  const done = [], failed = [];
  const tryDo = async (what, fn) => { try { await fn(); done.push(what); } catch (e) { failed.push(`${what}: ${e?.message ?? e}`); } };
  const fid = plan.fid;
  let n = 0;
  const tick = (t) => { if (++n % 8 === 0) progress(t); };
  for (const s of plan.steps) {
    if (s.t === "guildName") await tryDo("server name", () => dGuild.setName(s.name));
    else if (s.t === "guildIcon") await tryDo("server icon", async () => { await dGuild.setIcon(s.url); memo[dGuild.id] = { ...(memo[dGuild.id] ?? {}), icon: s.hash }; saveMemo(); });
    else if (s.t === "roleNew") await tryDo(`role ${s.name}`, async () => { const r = await dGuild.roles.create({ name: s.name, color: s.color, hoist: s.hoist, mentionable: s.mentionable, permissions: s.permissions, reason: "Copied from the Fluxer server" }); s.ref.id = r.id; tick("Making roles..."); });
    else if (s.t === "roleEdit") await tryDo(`role ${s.name}`, async () => { await dGuild.roles.edit(s.id, { name: s.name, color: s.color, hoist: s.hoist, mentionable: s.mentionable, permissions: s.permissions, reason: "Matched to the Fluxer server" }); tick("Updating roles..."); });
    else if (s.t === "everyone") await tryDo("@everyone permissions", () => dGuild.roles.everyone.setPermissions(s.permissions, "Matched to the Fluxer server"));
    else if (s.t === "roleOrder") await tryDo("role order", async () => {
      const me = dGuild.members.me ?? (await dGuild.members.fetchMe());
      const top = me.roles.highest.position;
      const ids = s.order.map((r) => r?.id).filter((id) => id && dGuild.roles.cache.get(id) && dGuild.roles.cache.get(id).position < top);
      // highest Fluxer role just under the bot's own role, then down from there
      await dGuild.roles.setPositions(ids.map((id, i) => ({ role: id, position: Math.max(1, top - 1 - i) })));
    });
    else if (s.t === "roleDel") await tryDo("delete role", () => dGuild.roles.delete(s.id, "Not on the Fluxer server"));
    else if (s.t === "chanNew" || s.t === "chanEdit") await tryDo(`${s.kind} ${s.name}`, async () => {
      const permissionOverwrites = s.overwrites.filter((o) => o.role?.id).map((o) => ({ id: o.role.id, type: 0, allow: o.allow, deny: o.deny }));
      const opts = { name: s.kind === "category" ? s.name : s.kind === "voice" ? s.name : s.name.toLowerCase().replace(/\s+/g, "-"), permissionOverwrites, reason: "Copied from the Fluxer server" };
      if (s.kind !== "category") { opts.parent = s.parentRef?.id ?? null; opts.nsfw = s.nsfw; opts.rateLimitPerUser = s.slowmode; }
      if (s.kind === "text") opts.topic = s.topic || null;
      if (s.kind === "voice") opts.userLimit = s.userLimit;
      if (s.t === "chanNew") {
        opts.type = s.kind === "category" ? ChannelType.GuildCategory : s.kind === "voice" ? ChannelType.GuildVoice : ChannelType.GuildText;
        const c = await dGuild.channels.create(opts);
        s.ref.id = c.id;
        tick("Making channels...");
      } else {
        const c = dGuild.channels.cache.get(s.ref.id) ?? (await dGuild.channels.fetch(s.ref.id));
        if (!s.quiet) {
          const { permissionOverwrites: _, name, ...rest } = opts;
          // (Discord only allows 2 renames per channel every 10 minutes and makes the bot wait otherwise: the rename
          //  finishes by itself later, and the rest doesn't wait for it)
          if (c.name !== name) {
            const was = c.name;
            const r = await Promise.race([c.setName(name, "Matched to the Fluxer server").then(() => "ok", (e) => e), new Promise((res) => setTimeout(() => res("wait"), 15000))]);
            if (r === "wait") failed.push(`#${was} becomes ${name} in a few minutes (Discord only lets a channel be renamed twice every 10 minutes)`);
            else if (r !== "ok") failed.push(`rename #${was} to ${name}: ${r?.message ?? r}`);
          }
          await c.edit(rest);
        }
        await c.permissionOverwrites.set(permissionOverwrites, "Matched to the Fluxer server").catch(() => {});
        tick("Updating channels...");
      }
    });
    else if (s.t === "chanDel") await tryDo(`delete #${s.name}`, async () => { const c = dGuild.channels.cache.get(s.id) ?? (await dGuild.channels.fetch(s.id).catch(() => null)); if (c) await c.delete("Not on the Fluxer server"); });
    else if (s.t === "bridge") await tryDo(`bridge ${s.fluxerId}`, () => bridgeOne(dGuild, fluxerClient, fid, s));
  }
  // channel order (within each category) and each channel's category, like the Fluxer server
  const placed = plan.steps.filter((s) => (s.t === "chanNew" || s.t === "chanEdit") && s.ref?.id).sort((a, b) => a.position - b.position);
  await tryDo("channel order", async () => {
    const list = placed.map((s) => ({ channel: s.ref.id, ...(s.kind !== "category" ? { parent: s.parentRef?.id ?? null } : {}) }));
    // (then what Fluxer doesn't have, so it ends up last in its category)
    for (const id of plan.extras ?? []) if (dGuild.channels.cache.get(id) && !list.some((x) => x.channel === id)) list.push({ channel: id });
    await dGuild.channels.setPositions(list.map((x, i) => ({ ...x, position: i })));
  });
  // the server link now knows which categories go together
  try { (await import("./ServerLink.js")).rememberCats(placed.filter((s) => s.kind === "category").map((s) => [s.fluxerId, s.ref.id])); } catch {}
  // check: anything still in the wrong category gets moved one at a time
  await new Promise((r) => setTimeout(r, 2000));
  await dGuild.channels.fetch().catch(() => {});
  for (const s of placed) {
    if (s.kind === "category") continue;
    const c = dGuild.channels.cache.get(s.ref.id);
    const want = s.parentRef?.id ?? null;
    if (!c || (c.parentId ?? null) === want) continue;
    const where = want ? `"${dGuild.channels.cache.get(want)?.name ?? "its category"}"` : "no category";
    await c.setParent(want, { lockPermissions: false, reason: "Matched to the Fluxer server" }).catch((e) => failed.push(`move ${s.kind === "voice" ? "🔊" : "#"}${c.name} to ${where}: ${e?.message ?? e}`));
  }
  log("META", `Copied the Fluxer server "${plan.fluxerName}" onto the Discord server "${dGuild.name}": ${done.length} done, ${failed.length} failed.`);
  return { done: done.length, failed };
}

// one Fluxer channel <-> its Discord channel, bridged both ways (like bb!setupall does)
export async function bridgeOne(dGuild, fluxerClient, fid, s) {
  const dChannel = dGuild.channels.cache.get(s.ref?.id) ?? (await dGuild.channels.fetch(s.ref?.id));
  if (!dChannel) throw new Error("the Discord channel isn't there");
  const have = await ChannelMap.findOne({ where: { [Op.or]: [{ fluxerChannelId: s.fluxerId }, { discordChannelId: dChannel.id }] }, raw: true });
  if (have) return;
  const fHook = await fluxerClient.rest.post(FluxerRoutes.channelWebhooks(s.fluxerId), { body: { name: `Fluxcord Bridge (${s.fluxerId} (F) <-> ${dChannel.id} (D))` }, auth: true });
  const dHook = await dChannel.createWebhook({ name: `Fluxcord Bridge (${dChannel.id} (D) <-> ${s.fluxerId} (F))` });
  const [fg] = await GuildMap.findOrCreate({ where: { guildId: String(fid), guildType: "fluxer" } });
  const [dg] = await GuildMap.findOrCreate({ where: { guildId: dGuild.id, guildType: "discord" } });
  await ChannelMap.create({
    fluxerChannelId: s.fluxerId, discordChannelId: dChannel.id, fluxerGuildId: String(fid), discordGuildId: dGuild.id,
    fluxerWebhookId: fHook?.id ?? "", fluxerWebhookToken: fHook?.token ?? "", discordWebhookId: dHook.id, discordWebhookToken: dHook.token ?? "",
    fluxerGuildMapId: fg.id, discordGuildMapId: dg.id, bridgeType: "both",
  });
  if (s.kind === "voice") await VoiceChannelMap.create({ discordGuildId: dGuild.id, discordChannelId: dChannel.id, fluxerGuildId: String(fid), fluxerChannelId: s.fluxerId });
}
