// chat games everyone plays by typing in a bridged channel (Fluxer or Discord).
//   scramble: unscramble the word first        hangman: guess letters together
//   wyr: would you rather, vote A or B
// Discord players' messages reach Fluxer through the bridge, so everything is judged there.
import { reaction } from "./Output.js";
import { randomInt } from "node:crypto";
import { log } from "./Logger.js";

let announceFn = null;
export function setChatGameAnnouncer(fn) { announceFn = fn; }
const say = (ch, text) => announceFn?.(ch, text);
/** Adjustable for tests. */
export const timing = { scrambleRound: 30_000, scrambleHint: 15_000, gap: 3_000, wyrVote: 30_000, hangmanIdle: 180_000 };

const WORDS = {
  overwatch: ["tracer", "genji", "mercy", "reinhardt", "winston", "zarya", "sombra", "hanzo", "symmetra", "junkrat", "roadhog", "pharah", "reaper", "kiriko", "lucio", "zenyatta", "widowmaker", "cassidy", "baptiste", "brigitte", "moira", "doomfist", "orisa", "sigma", "sojourn", "illari", "ramattra", "mauga"],
  minecraft: ["creeper", "zombie", "skeleton", "enderman", "diamond", "netherite", "obsidian", "redstone", "villager", "pickaxe", "furnace", "beacon", "elytra", "trident", "spider", "emerald", "lantern", "anvil"],
  pokemon: ["pikachu", "charizard", "bulbasaur", "squirtle", "eevee", "gengar", "snorlax", "mewtwo", "lucario", "garchomp", "jigglypuff", "psyduck", "magikarp", "gyarados", "dragonite", "umbreon"],
  general: ["bridge", "keyboard", "pizza", "dragon", "castle", "galaxy", "thunder", "penguin", "volcano", "rainbow", "chocolate", "wizard", "vampire", "butterfly", "pirate", "jellyfish", "pancake", "skeleton"],
};
export const WORD_CATEGORIES = Object.keys(WORDS);
const pick = (a) => a[randomInt(a.length)];
function wordFrom(category) {
  const pool = WORDS[category] ?? Object.values(WORDS).flat();
  return pick(pool);
}
function shuffleWord(w) {
  for (let tries = 0; tries < 20; tries++) {
    const a = [...w];
    for (let i = a.length - 1; i > 0; i--) { const j = randomInt(i + 1); [a[i], a[j]] = [a[j], a[i]]; }
    const s = a.join(" ");
    if (s !== w) return s;
  }
  return [...w].reverse().join(" ");
}
const norm = (s) => String(s ?? "").toLowerCase().replace(/[^a-z]/g, "");

/** @type {Map<string, any>} Fluxer channel -> running chat game */
const running = new Map();
export const chatGameRunning = (ch) => running.has(ch);
export function stopChatGame(ch) {
  const g = running.get(ch);
  if (!g) return false;
  for (const t of g.timers ?? []) clearTimeout(t);
  running.delete(ch);
  return true;
}

// ---------------- scramble ----------------
export function startScramble(ch, starter, category) {
  const g = { type: "scramble", round: 0, rounds: 5, word: null, open: false, scores: new Map(), timers: [], category };
  running.set(ch, g);
  say(ch, `**SCRAMBLE.** ${starter} wants to play. 5 words${category ? ` (${category})` : ""}, ${timing.scrambleRound / 1000} seconds each. Type the real word. First one wins the round.`);
  g.timers.push(setTimeout(() => scrambleNext(ch), timing.gap));
}
function scrambleNext(ch) {
  const g = running.get(ch);
  if (!g) return;
  if (g.round >= g.rounds) return scrambleEnd(ch);
  g.round++;
  g.word = wordFrom(g.category);
  g.open = true;
  say(ch, `**Word ${g.round}/${g.rounds}:** \`${shuffleWord(g.word).toUpperCase()}\``);
  g.timers = [
    setTimeout(() => g.open && say(ch, `-# Hint: it starts with **${g.word[0].toUpperCase()}** and has ${g.word.length} letters.`), timing.scrambleHint),
    setTimeout(() => { if (running.get(ch) === g && g.open) { g.open = false; say(ch, () => `Time! It was **${g.word}**. ${reaction("fail") ?? "Nobody got that one."}`); g.timers.push(setTimeout(() => scrambleNext(ch), timing.gap)); } }, timing.scrambleRound),
  ];
}
function scrambleEnd(ch) {
  const g = running.get(ch);
  running.delete(ch);
  const board = [...g.scores.values()].sort((a, b) => b.pts - a.pts);
  if (!board.length) return say(ch, "Game over. Nobody scored this time.");
  say(ch, () => `**Scramble's over.**\n${board.map((s, i) => `${i + 1}. ${s.name}: ${s.pts}`).join("\n")}\n${board[0].name} wins. ${reaction("win", board[0].name) ?? "Well played!"}`);
}

// ---------------- hangman ----------------
const LIVES = 7;
export function startHangman(ch, starter, category) {
  const word = wordFrom(category);
  const g = { type: "hangman", word, guessed: new Set(), wrong: new Set(), lives: LIVES, timers: [] };
  running.set(ch, g);
  say(ch, `**HANGMAN.** ${starter} started it. Type one letter at a time, or guess the whole word.\n${hangmanBoard(g)}`);
  hangmanIdle(ch);
}
function hangmanIdle(ch) {
  const g = running.get(ch);
  if (!g) return;
  for (const t of g.timers) clearTimeout(t);
  g.timers = [setTimeout(() => { if (running.get(ch) === g) { running.delete(ch); say(ch, () => `Nobody's playing? It was **${g.word}**. ${reaction("fail") ?? "Nobody got that one."}`); } }, timing.hangmanIdle)];
}
function hangmanBoard(g) {
  const shown = [...g.word].map((c) => (g.guessed.has(c) ? c.toUpperCase() : "_")).join(" ");
  const hearts = "♥".repeat(g.lives) + "♡".repeat(LIVES - g.lives);
  return `\`${shown}\`   ${hearts}${g.wrong.size ? `   -# wrong: ${[...g.wrong].join(" ").toUpperCase()}` : ""}`;
}
function hangmanGuess(ch, g, text, player) {
  const t = norm(text);
  if (t.length === 1) {
    if (g.guessed.has(t) || g.wrong.has(t)) return true;
    if (g.word.includes(t)) g.guessed.add(t);
    else { g.wrong.add(t); g.lives--; }
  } else if (t.length === g.word.length && t !== g.word) {
    g.lives--;
    say(ch, `Nope, ${player.name}. Not "${t}". That cost a life.`);
  } else if (t === g.word) {
    for (const c of g.word) g.guessed.add(c);
  } else return false;
  hangmanIdle(ch);
  const solved = [...g.word].every((c) => g.guessed.has(c));
  if (solved) { stopChatGame(ch); say(ch, () => `${hangmanBoard(g)}\n**${player.name}** got it! It was **${g.word}**. ${reaction("win", player.name) ?? "Nice work!"}`); return true; }
  if (g.lives <= 0) { stopChatGame(ch); say(ch, () => `${hangmanBoard(g)}\nOut of lives. It was **${g.word}**. ${reaction("fail") ?? "Better luck next time!"}`); return true; }
  say(ch, hangmanBoard(g));
  return true;
}

// ---------------- would you rather ----------------
const WYR = [
  ["only play support forever", "only play tank forever"],
  ["fight one horse-sized creeper", "a hundred creeper-sized horses"],
  ["never use Discord again", "never use Fluxer again"],
  ["be able to talk to animals", "be able to speak every language"],
  ["always lose at rock paper scissors", "always lose at trivia"],
  ["live in a Minecraft world", "live in the Pokémon world"],
  ["only eat pizza forever", "never eat pizza again"],
  ["have unlimited Robux", "have unlimited Overwatch coins"],
  ["be able to fly", "be able to teleport"],
  ["read minds", "be invisible whenever you want"],
  ["have a rewind button for your life", "have a pause button for your life"],
  ["have a pet dragon", "have a pet that talks"],
  ["never sleep", "never eat"],
  ["know every language", "play every instrument"],
  ["live without music", "live without games"],
];
export function startWyr(ch, starter) {
  const [a, b] = pick(WYR);
  const g = { type: "wyr", a, b, votes: new Map(), timers: [] };
  running.set(ch, g);
  say(ch, `**Would you rather...** (${starter} asked)\n**A)** ${a}\n**B)** ${b}\nType **A** or **B**. ${timing.wyrVote / 1000} seconds.`);
  g.timers.push(setTimeout(() => {
    if (running.get(ch) !== g) return;
    running.delete(ch);
    const va = [...g.votes.values()].filter((v) => v.pick === "a"), vb = [...g.votes.values()].filter((v) => v.pick === "b");
    const names = (l) => (l.length ? l.map((v) => v.name).join(", ") : "nobody");
    const verdict = !g.votes.size ? "Nobody voted." : va.length === vb.length ? "It's a tie." : `**${va.length > vb.length ? "A" : "B"}** wins. ${va.length > vb.length ? "B" : "A"} voters were outnumbered.`;
    say(ch, `**A)** ${names(va)}\n**B)** ${names(vb)}\n${verdict}`);
  }, timing.wyrVote));
}

/** Every Fluxer message in a channel with a chat game. Returns true if it was a game move. */
export function chatGameMessage(ch, text, player) {
  const g = running.get(ch);
  if (!g || /^\s*bb!/i.test(text ?? "")) return false;
  try {
    if (g.type === "scramble") {
      if (!g.open || norm(text) !== g.word) return false;
      g.open = false;
      for (const t of g.timers) clearTimeout(t);
      const s = g.scores.get(player.key) ?? { name: player.name, pts: 0 };
      s.pts++;
      g.scores.set(player.key, s);
      say(ch, `✅ **${player.name}** got it: **${g.word}**.`);
      g.timers = [setTimeout(() => scrambleNext(ch), timing.gap)];
      return true;
    }
    if (g.type === "hangman") return hangmanGuess(ch, g, text, player);
    if (g.type === "wyr") {
      const t = norm(text);
      const pickAB = t === "a" || t === "1" ? "a" : t === "b" || t === "2" ? "b" : null;
      if (!pickAB) return false;
      g.votes.set(player.key, { name: player.name, pick: pickAB });
      return true;
    }
  } catch (e) {
    log("META", "Chat game error:", e?.message ?? e);
  }
  return false;
}

export const START = { scramble: startScramble, hangman: startHangman, wyr: startWyr };
