import { Routes as FluxerRoutes } from "@fluxerjs/core";
import { resolvePerson, discordMembers } from "./WhoIs.js";
import { getLevel, setLevel } from "./VoiceLevels.js";
import { currentVc } from "./Hangout.js";

/**
 * Mute or unmute someone in voice for everyone: a real server mute on their own app
 * (so they can't talk to their own side either), and silence in the bridge.
 */
export async function voiceMute(mute, params, message, discordClient, fluxerClient) {
  const who = await resolvePerson(message, [...params], discordClient, fluxerClient);
  if (!who) return void (await message.reply(`Who? \`bb!${mute ? "mute" : "unmute"} Max\`, or @mention them, or reply to them.`));
  const notes = [];
  if (who.side === "discord") {
    const members = await discordMembers(discordClient, who.id);
    let done = false;
    for (const m of members) {
      if (!m.voice?.channelId) continue;
      try { await m.voice.setMute(mute, mute ? "Muted via the bridge bot" : "Unmuted via the bridge bot"); done = true; }
      catch (e) { notes.push(`Discord wouldn't ${mute ? "mute" : "unmute"} them there (${e?.message ?? e}).`); }
    }
    if (!done && !notes.length) notes.push("They're not in a Discord call right now, so it'll apply when they join.");
  } else {
    const guildId = currentVc()?.guildId ?? message.guildId;
    try {
      await fluxerClient.rest.patch(FluxerRoutes.guildMember(guildId, who.id), { body: { mute }, auth: true });
    } catch (e) {
      notes.push(`Fluxer wouldn't ${mute ? "mute" : "unmute"} them (${String(e?.message ?? e).slice(0, 80)}). My role needs **Mute Members**. They're still silenced on Discord.`);
    }
  }
  // Silence (or restore) them in the bridge either way.
  if (mute) setLevel(who.side, who.id, 0);
  else if (getLevel(who.side, who.id) === 0) setLevel(who.side, who.id, 100);
  const head = mute ? `Muted **${who.name}** in voice. Peace and quiet.` : `Unmuted **${who.name}**. Don't make me regret it.`;
  await message.reply([head, ...notes.map((n) => `-# ${n}`)].join("\n"));
}
