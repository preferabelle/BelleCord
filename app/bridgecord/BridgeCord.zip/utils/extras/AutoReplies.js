// Auto replies: when someone says a key phrase ("send spaghetti"), the bot answers with one of its pictures or
// GIFs, picked at random, on both sides of the bridge. Set up with bb!autoreply. Saved in data/auto-replies.json,
// with the pictures in data/auto-replies/.
import fs from "node:fs";
import path from "node:path";
import { randomBytes } from "node:crypto";
import Config from "../ConfigHandler.js";
import { bridgeOf, copyOf, discordPost, download, extOf, fluxerPost, nameOn, readJson, sniffType, writeJson } from "../AddonTools.js";

const FILE = path.join(Config.DataFolderPath, "auto-replies.json");
const DIR = path.join(Config.DataFolderPath, "auto-replies");
const MAX_PIC = 10 * 1024 * 1024; // what Discord takes from a bot
const MAX_PICS = 40;

let state = readJson(FILE, { list: [] });
state.list ??= [];
const save = () => writeJson(FILE, state);
const newId = () => randomBytes(5).toString("hex");

export const list = () => state.list;
export const find = (idOrPhrase) => {
  const k = String(idOrPhrase ?? "").trim();
  return state.list.find((x) => x.id === k) ?? state.list.find((x) => clean(x.phrase) === clean(k)) ?? (/^\d+$/.test(k) ? state.list[Number(k) - 1] : undefined);
};

/** Lowercase words only, so "Send spaghetti!!" and "send   spaghetti" match "send spaghetti". */
export function clean(s) {
  return String(s ?? "").toLowerCase().normalize("NFKD").replace(/[̀-ͯ]/g, "").replace(/[’‘`']/g, "").replace(/[^\p{L}\p{N}]+/gu, " ").trim();
}
function matches(entry, text) {
  const p = clean(entry.phrase);
  if (!p) { // a phrase that's only emoji or symbols: match it as typed
    const raw = String(entry.phrase ?? "").trim().toLowerCase();
    return !!raw && (entry.match === "whole" ? String(text).trim().toLowerCase() === raw : String(text).toLowerCase().includes(raw));
  }
  const t = clean(text);
  return entry.match === "whole" ? t === p : ` ${t} `.includes(` ${p} `);
}
/** The auto reply this message sets off (the longest matching phrase wins), or null. */
export function replyFor(text) {
  if (!text || String(text).trim().toLowerCase().startsWith(String(Config.BotPrefix).toLowerCase())) return null;
  const hits = state.list.filter((x) => x.on !== false && (x.pics?.length || x.text) && matches(x, text));
  return hits.sort((a, b) => clean(b.phrase).length - clean(a.phrase).length)[0] ?? null;
}

// ---- editing ----
export function upsert({ id, phrase, match, text, on }) {
  phrase = String(phrase ?? "").trim().slice(0, 120);
  let e = id ? state.list.find((x) => x.id === id) : null;
  if (!e && !phrase) throw new Error("Type what someone has to say first.");
  if (phrase) {
    const twin = state.list.find((x) => x !== e && clean(x.phrase) === clean(phrase) && String(x.phrase).trim().toLowerCase() === phrase.toLowerCase());
    if (twin) { if (!e) return twin; throw new Error(`"${phrase}" already has an auto reply.`); }
  }
  if (!e) { e = { id: newId(), phrase, match: "anywhere", text: "", pics: [], on: true, made: Date.now(), uses: 0 }; state.list.push(e); }
  if (phrase) e.phrase = phrase;
  if (match === "whole" || match === "anywhere") e.match = match;
  if (text !== undefined) e.text = String(text ?? "").slice(0, 1500);
  if (on !== undefined) e.on = !!on;
  save();
  return e;
}
export function remove(id) {
  const e = state.list.find((x) => x.id === id);
  if (!e) return false;
  for (const p of e.pics ?? []) { try { fs.unlinkSync(path.join(DIR, p.file)); } catch {} }
  state.list = state.list.filter((x) => x !== e);
  save();
  return true;
}

/** A pasted page link (Giphy, Tenor...) to the picture itself. */
async function pictureFrom(url) {
  url = String(url ?? "").trim();
  const giphy = url.match(/giphy\.com\/(?:gifs|stickers|embed)\/(?:[^/?#]*-)?([A-Za-z0-9]+)(?:[/?#]|$)/i);
  if (giphy) url = `https://media.giphy.com/media/${giphy[1]}/giphy.gif`;
  let got = await download(url, MAX_PIC * 3);
  if (got && !/^(image|video)\//.test(got.type ?? "")) {
    // a web page: use the picture it shows when it's shared
    const html = got.data.toString("utf-8");
    const meta = (p) => html.match(new RegExp(`<meta[^>]+(?:property|name)=["']${p}["'][^>]+content=["']([^"']+)`, "i"))?.[1] ?? html.match(new RegExp(`<meta[^>]+content=["']([^"']+)["'][^>]+(?:property|name)=["']${p}["']`, "i"))?.[1];
    const inner = [meta("og:image"), meta("twitter:image"), meta("og:video")].map((u) => u && u.replace(/&amp;/g, "&")).find((u) => u && /\.gif(\?|$)/i.test(u)) ?? meta("og:image") ?? meta("og:video");
    got = inner ? await download(inner.replace(/&amp;/g, "&"), MAX_PIC * 3) : null;
  }
  return got;
}

/** A picture from an upload (base64) or a link (Giphy and Tenor pages work), checked: { buf, type }. */
export async function readPicture({ data, url }) {
  let buf = data ? Buffer.from(String(data).split(",").pop(), "base64") : null;
  let type = buf ? sniffType(buf) : null;
  if (!buf && url) { const got = await pictureFrom(url); if (!got) throw new Error("I couldn't get a picture from that link."); buf = got.data; type = got.type; }
  if (!buf?.length) throw new Error("That file was empty.");
  type = sniffType(buf) ?? type;
  if (!/^(image\/(png|jpeg|gif|webp)|video\/(mp4|webm))$/.test(type ?? "")) throw new Error("That isn't a picture, GIF or short video I can post.");
  if (buf.length > MAX_PIC) throw new Error(`That one is ${(buf.length / 1048576).toFixed(1)} MB. Discord only takes up to 10 MB from my bot.`);
  return { buf, type };
}
export async function addPicture(id, { data, name, url, from }) {
  const e = state.list.find((x) => x.id === id);
  if (!e) throw new Error("That auto reply is gone. Refresh and try again.");
  if ((e.pics?.length ?? 0) >= MAX_PICS) throw new Error(`One auto reply can have up to ${MAX_PICS} pictures.`);
  const { buf, type } = await readPicture({ data, url });
  fs.mkdirSync(DIR, { recursive: true });
  const pic = { id: newId(), type, name: String(name || `picture.${extOf(type)}`).replace(/[\\/:*?"<>|]/g, "_").slice(0, 80), from: from ?? (url ? "link" : "upload") };
  pic.file = `${e.id}-${pic.id}.${extOf(type)}`;
  if (!/\.[a-z0-9]{2,4}$/i.test(pic.name)) pic.name += "." + extOf(type);
  fs.writeFileSync(path.join(DIR, pic.file), buf);
  (e.pics ??= []).push(pic);
  save();
  return pic;
}
export function removePicture(id, picId) {
  const e = state.list.find((x) => x.id === id);
  const p = e?.pics?.find((x) => x.id === picId);
  if (!p) return false;
  try { fs.unlinkSync(path.join(DIR, p.file)); } catch {}
  e.pics = e.pics.filter((x) => x !== p);
  save();
  return true;
}

// ---- answering ----
const lastPic = new Map(); // entry -> last picture shown (so it doesn't show the same one twice in a row)
const recent = new Map(); // "entry:place" -> time (one answer per message, even though it's on both sides)
function pick(e) {
  if (!e.pics?.length) return null;
  let options = e.pics;
  if (options.length > 1) options = options.filter((p) => p.id !== lastPic.get(e.id));
  const p = options[Math.floor(Math.random() * options.length)];
  lastPic.set(e.id, p.id);
  return p;
}
function busy(key, ms = 6000) {
  const now = Date.now();
  if (now - (recent.get(key) ?? 0) < ms) return true;
  recent.set(key, now);
  if (recent.size > 500) for (const [k, t] of recent) if (now - t > 60_000) recent.delete(k);
  return false;
}

async function answer(ctx, side, msg) {
  const e = replyFor(msg.content);
  if (!e) return;
  const bridge = side === "discord" ? await bridgeOf({ discordChannelId: msg.channelId }) : await bridgeOf({ fluxerChannelId: msg.channelId });
  // the same words can arrive twice when they cross the bridge: answer once
  if (busy(`${e.id}:${bridge?.discordChannelId ?? msg.channelId}`)) return;
  const p = pick(e);
  let data = null;
  if (p) { try { data = fs.readFileSync(path.join(DIR, p.file)); } catch { ctx.log(`auto reply picture missing: ${p.file}`); } }
  const content = e.text ? e.text.replaceAll("{name}", nameOn(msg)) : undefined;
  if (!data && !content) return;
  const files = data ? [{ name: p.name, data }] : [];
  e.uses = (e.uses ?? 0) + 1; e.last = Date.now(); save();
  const here = side === "discord"
    ? discordPost(ctx.discord, msg.channelId, { content, files })
    : fluxerPost(ctx.fluxer, msg.channelId, { content, files });
  await here.catch((err) => ctx.log(`auto reply on ${side} failed:`, err?.message ?? err));
  // the other side of a bridged channel gets it too, right after the message itself crosses over
  if (bridge && bridge.bridgeType !== (side === "discord" ? "fluxer2discord" : "discord2fluxer")) {
    await copyOf(side === "discord" ? { discordMessageId: msg.id } : { fluxerMessageId: msg.id }, 4000);
    const there = side === "discord"
      ? fluxerPost(ctx.fluxer, bridge.fluxerChannelId, { content, files })
      : discordPost(ctx.discord, bridge.discordChannelId, { content, files });
    await there.catch((err) => ctx.log(`auto reply on the other side failed:`, err?.message ?? err));
  }
}

export async function start(ctx) {
  ctx.withDiscord((d) => d.on("messageCreate", (m) => {
    try {
      if (!m.guildId || m.webhookId || m.system) return;
      if (m.author?.bot) return; // (bots, including this one and the linked bots, are left alone)
      if (!state.list.length) return;
      answer(ctx, "discord", m).catch((e) => ctx.log("auto reply:", e?.message ?? e));
    } catch {}
  }));
  ctx.withFluxer((f) => f.on("messageCreate", (m) => {
    try {
      if (!m.guildId || m.webhookId || m.author?.bot || m.author?.id === f.user?.id) return;
      if (!state.list.length) return;
      answer(ctx, "fluxer", m).catch((e) => ctx.log("auto reply:", e?.message ?? e));
    } catch {}
  }));
}
