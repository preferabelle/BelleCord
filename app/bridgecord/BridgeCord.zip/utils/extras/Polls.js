// Polls across the bridge. Fluxer has no polls of its own, so:
//   * A Discord poll in a bridged channel shows up on Fluxer as a card. People on Fluxer vote by reacting with
//     the answer's number, and the card counts Discord's and Fluxer's votes together.
//   * On Discord, a small line under the poll shows Fluxer's votes (Discord won't let anyone add votes to a poll).
//   * bb!poll makes one from either side: a real poll on Discord, and the card on Fluxer.
//   * When it ends, both sides get the final count, everyone's votes included.
// Saved in data/bridged-polls.json.
import path from "node:path";
import { Routes as FluxerRoutes } from "@fluxerjs/core";
import Config from "../ConfigHandler.js";
import { bridgeOf, discordEdit, discordPost, fluxerEdit, fluxerPost, fluxerReact, isMirrorOnFluxer, nameOn, readJson, writeJson } from "../AddonTools.js";

const FILE = path.join(Config.DataFolderPath, "bridged-polls.json");
const NUM = ["1️⃣", "2️⃣", "3️⃣", "4️⃣", "5️⃣", "6️⃣", "7️⃣", "8️⃣", "9️⃣", "🔟"];
const COLOR = 0xe0301e;

let polls = readJson(FILE, []);
if (!Array.isArray(polls)) polls = [];
const save = () => {
  const weekAgo = Date.now() - 7 * 86400000;
  polls = polls.filter((p) => !p.done || (p.ends ?? 0) > weekAgo);
  writeJson(FILE, polls);
};
let C = null; // the bots (see utils/Extras.js)
const pending = []; // polls bb!poll just made on Discord: { question, by, at, fluxerChannel }

// ---- counting ----
function counts(p) {
  const n = p.answers.length;
  const d = (p.dCounts ?? []).slice(0, n);
  while (d.length < n) d.push(0);
  const f = new Array(n).fill(0);
  for (const picks of Object.values(p.fVoters ?? {})) for (const i of picks) if (i >= 0 && i < n) f[i]++;
  return { d, f, all: d.map((x, i) => x + f[i]) };
}
const bar = (share) => { const full = Math.round(share * 10); return "█".repeat(full) + "░".repeat(10 - full); };

function card(p) {
  const { all } = counts(p);
  const total = all.reduce((a, b) => a + b, 0);
  const top = Math.max(0, ...all);
  const lines = p.answers.map((a, i) => {
    const share = total ? all[i] / total : 0;
    const win = p.done && top > 0 && all[i] === top;
    return `${NUM[i]} ${win ? "🏆 " : ""}**${a.text}**\n\`${bar(share)}\` ${all[i]} vote${all[i] === 1 ? "" : "s"}${total ? ` · ${Math.round(share * 100)}%` : ""}`;
  });
  const how = p.done ? "Final results" : `React with a number to vote · ${p.multi ? "pick as many as you like" : "pick one"}`;
  const where = p.d ? "Discord + Fluxer votes together" : "";
  return {
    author: { name: p.by ? `${p.by} made a poll${p.d && p.from === "discord" ? " on Discord" : ""}` : "Poll" },
    title: `📊 ${p.question}${p.done ? " (closed)" : ""}`.slice(0, 256),
    description: lines.join("\n\n").slice(0, 4000),
    color: COLOR,
    footer: { text: [`${total} vote${total === 1 ? "" : "s"}`, where, how, p.done ? "" : "Ends"].filter(Boolean).join(" · ") },
    ...(p.ends ? { timestamp: new Date(p.ends).toISOString() } : {}),
  };
}

function companionText(p) {
  const { f, all } = counts(p);
  const fTotal = f.reduce((a, b) => a + b, 0);
  if (!fTotal && !p.done) return null;
  if (p.done) {
    const top = Math.max(0, ...all);
    return `-# 📊 Final count, with Fluxer's votes: ` + p.answers.map((a, i) => `${top > 0 && all[i] === top ? "🏆 " : ""}${a.text} **${all[i]}**`).join(" · ");
  }
  return `-# 📊 Votes from Fluxer: ` + p.answers.map((a, i) => `${a.text} **${f[i]}**`).join(" · ") + `\n-# With them: ` + p.answers.map((a, i) => `${a.text} ${all[i]}`).join(" · ");
}

// ---- keeping both sides up to date ----
async function readDiscord(p) {
  if (!p.d || !C.discord?.isReady?.()) return;
  const ch = await C.discord.channels.fetch(p.d.channel).catch(() => null);
  const m = await ch?.messages?.fetch({ message: p.d.message, force: true }).catch(() => null);
  if (!m) { if (ch) p.gone = (p.gone ?? 0) + 1; return; }
  p.gone = 0;
  if (!m.poll) return;
  const answers = [...(m.poll.answers?.values?.() ?? [])];
  p.dCounts = p.answers.map((a, i) => (answers.find((x) => String(x.id) === String(a.id)) ?? answers[i])?.voteCount ?? 0);
  if (m.poll.resultsFinalized || (m.poll.expiresTimestamp && m.poll.expiresTimestamp <= Date.now())) p.ends = Math.min(p.ends ?? Infinity, m.poll.expiresTimestamp ?? Date.now());
}

async function readFluxer(p) {
  if (!p.f?.message || !C.fluxer?.isReady?.()) return;
  const voters = {};
  const me = C.fluxer.user?.id;
  for (let i = 0; i < p.answers.length; i++) {
    const users = await C.fluxer.rest.get(`${FluxerRoutes.channelMessageReactionUsers(p.f.channel, p.f.message, NUM[i])}?limit=100`, { auth: true }).catch(() => null);
    if (!Array.isArray(users)) continue;
    for (const u of users) {
      if (!u?.id || u.id === me || u.bot || (await isMirrorOnFluxer(u.id))) continue;
      (voters[u.id] ??= []).push(i);
    }
  }
  p.fRaw = Object.fromEntries(Object.entries(voters).map(([id, picks]) => [id, [...picks]]));
  if (!p.multi) {
    // one answer each: the one they picked last (or their first, if I didn't see them pick)
    for (const [id, picks] of Object.entries(voters)) {
      if (picks.length > 1) voters[id] = [picks.includes(p.fLast?.[id]) ? p.fLast[id] : picks[0]];
    }
  }
  p.fVoters = voters;
  p.fReadAt = Date.now();
}

async function draw(p) {
  if (p.f?.message && C.fluxer?.isReady?.()) {
    const embed = card(p);
    const sig = JSON.stringify(embed);
    if (sig !== p.drawn) {
      const ok = await fluxerEdit(C.fluxer, p.f.channel, p.f.message, { embeds: [embed] }).then(() => true).catch((e) => { C.log("poll card edit failed:", e?.message ?? e); return false; });
      if (ok) p.drawn = sig;
    }
  }
  if (p.d && C.discord?.isReady?.()) {
    const text = companionText(p);
    if (text && text !== p.companionText) {
      let ok = false;
      if (p.companion?.id) ok = await discordEdit(C.discord, p.d.channel, p.companion.id, text);
      if (!ok) {
        const sent = await discordPost(C.discord, p.d.channel, { content: text }).catch(() => null);
        if (sent?.id) p.companion = { id: sent.id };
        ok = !!sent;
      }
      if (ok) p.companionText = text;
    }
  }
}

const busy = new Set();
async function refresh(p) {
  if (busy.has(p)) { p.again = true; return; }
  busy.add(p);
  try {
    do {
      p.again = false;
      await readDiscord(p);
      // after it ends, Fluxer's count is the one from when it ended (later reactions don't count)
      if (!(p.ends && p.ends <= Date.now() && (p.fReadAt ?? 0) >= p.ends)) await readFluxer(p);
      if (!p.done && p.ends && p.ends <= Date.now()) p.done = true;
      if (!p.done && (p.gone ?? 0) >= 3) p.done = true; // the Discord poll was deleted
      await draw(p);
    } while (p.again);
    save();
  } finally { busy.delete(p); }
}
const soon = new Map();
function refreshSoon(p, ms = 1500) {
  clearTimeout(soon.get(p));
  soon.set(p, setTimeout(() => { soon.delete(p); refresh(p).catch((e) => C.log("poll refresh:", e?.message ?? e)); }, ms));
}

// ---- making the Fluxer card ----
async function postCard(p) {
  const sent = await fluxerPost(C.fluxer, p.f.channel, { embeds: [card(p)] });
  if (!sent?.id) throw new Error("Fluxer didn't take the poll card.");
  p.f.message = sent.id;
  p.drawn = JSON.stringify(card(p));
  polls.push(p);
  save();
  for (let i = 0; i < p.answers.length; i++) await fluxerReact(C.fluxer, p.f.channel, sent.id, NUM[i]).catch(() => {});
  return sent;
}

async function fromDiscord(m) {
  if (!m.poll || !m.guildId) return;
  if (polls.some((p) => p.d?.message === m.id)) return;
  const bridge = await bridgeOf({ discordChannelId: m.channelId });
  if (!bridge?.fluxerChannelId || bridge.bridgeType === "fluxer2discord" || !C.fluxer?.isReady?.()) return;
  const question = String(m.poll.question?.text ?? "").trim() || "Poll";
  const mine = pending.findIndex((x) => x.question === question && Date.now() - x.at < 60_000);
  const by = mine >= 0 ? pending.splice(mine, 1)[0].by : nameOn(m);
  const answers = [...(m.poll.answers?.values?.() ?? [])].slice(0, 10).map((a) => ({ id: a.id, text: String(a.text ?? "").trim() || (a.emoji?.name ?? "?") }));
  if (answers.length < 1) return;
  const p = {
    id: `d${m.id}`, from: mine >= 0 ? "command" : "discord", by, question, answers, multi: !!m.poll.allowMultiselect,
    ends: m.poll.expiresTimestamp ?? Date.now() + 24 * 3600000, made: Date.now(),
    d: { channel: m.channelId, message: m.id }, f: { channel: bridge.fluxerChannelId, message: null },
    dCounts: answers.map(() => 0), fVoters: {}, fLast: {},
  };
  await postCard(p);
  C.log(`poll "${question}" is on Fluxer too`);
}

/** bb!poll: a poll from either side. Returns a short note for the person, or null. */
export async function makePoll({ side, channelId, by, question, answers, hours, multi }) {
  if (!C) throw new Error("Polls are still starting up. Try again in a few seconds.");
  question = String(question ?? "").trim().slice(0, 300);
  answers = answers.map((a) => String(a).trim().slice(0, 55)).filter(Boolean).slice(0, 10);
  if (!question || answers.length < 2) throw new Error("A poll needs a question and at least 2 answers: `bb!poll Pizza or tacos? | Pizza | Tacos`");
  hours = Math.max(1, Math.min(768, Math.round(Number(hours) || 24)));
  const bridge = side === "discord" ? await bridgeOf({ discordChannelId: channelId }) : await bridgeOf({ fluxerChannelId: channelId });
  const discordChannel = side === "discord" ? channelId : bridge && bridge.bridgeType !== "discord2fluxer" ? bridge.discordChannelId : null;
  if (discordChannel && C.discord?.isReady?.()) {
    pending.push({ question, by, at: Date.now() });
    const poll = { question: { text: question }, answers: answers.map((text) => ({ text })), duration: hours, allowMultiselect: !!multi };
    let sent = await discordPost(C.discord, discordChannel, { content: `-# 📊 Poll from ${by}`, poll }).catch(() => null);
    if (!sent) {
      const ch = await C.discord.channels.fetch(discordChannel).catch(() => null);
      sent = await ch?.send?.({ content: `-# 📊 Poll from ${by}`, poll, allowedMentions: { parse: [] } }).catch((e) => { throw new Error(`Discord wouldn't take the poll (${e?.message ?? e}).`); });
    }
    // (the Discord poll arriving is what puts the card on Fluxer, so a poll made any way works the same)
    return null;
  }
  // no Discord side: a poll on Fluxer only
  if (side !== "fluxer") throw new Error("I can't reach Discord right now.");
  const p = {
    id: `f${Date.now()}`, from: "command", by, question, answers: answers.map((text, i) => ({ id: String(i + 1), text })), multi: !!multi,
    ends: Date.now() + hours * 3600000, made: Date.now(), d: null, f: { channel: channelId, message: null }, dCounts: [], fVoters: {}, fLast: {},
  };
  await postCard(p);
  return null;
}

export const activePolls = () => polls.filter((p) => !p.done);

export async function start(ctx) {
  C = ctx;
  ctx.withDiscord((d) => d.on("messageCreate", (m) => { if (m.poll) fromDiscord(m).catch((e) => ctx.log("poll from Discord:", e?.message ?? e)); }));
  ctx.withFluxer((f) => {
    const onReact = (added) => async (payload) => {
      try {
        const { reaction, user } = payload ?? {};
        const p = polls.find((x) => x.f?.message && x.f.message === String(reaction?.messageId));
        if (!p || p.done || !user?.id || user.id === f.user?.id) return;
        const i = NUM.indexOf(reaction.emoji?.name);
        if (i < 0 || i >= p.answers.length) return;
        if (p.ends && p.ends <= Date.now()) return; // too late: it's over
        if (added) {
          (p.fLast ??= {})[user.id] = i;
          const had = (p.fRaw ??= {})[user.id] ?? [];
          if (!p.multi) {
            // one answer each: their other number comes off (needs Manage Messages; if not, only the last one counts)
            for (const j of had) {
              if (j !== i) f.rest.delete(FluxerRoutes.channelMessageReactionUser(p.f.channel, p.f.message, NUM[j], user.id), { auth: true }).catch(() => {});
            }
            p.fRaw[user.id] = [i];
          } else if (!had.includes(i)) had.push(i), (p.fRaw[user.id] = had);
        }
        refreshSoon(p, added ? 1500 : 1000);
      } catch {}
    };
    f.on("messageReactionAdd", onReact(true));
    f.on("messageReactionRemove", onReact(false));
  });
  // Discord doesn't tell bots about each vote without an extra permission, so open polls are checked every minute
  setInterval(async () => {
    for (const p of polls.filter((x) => !x.done)) await refresh(p).catch(() => {});
  }, 60_000).unref?.();
  // after a restart: catch up on anything that ended while the bot was off
  setTimeout(async () => { for (const p of polls.filter((x) => !x.done)) await refresh(p).catch(() => {}); }, 30_000).unref?.();
}
