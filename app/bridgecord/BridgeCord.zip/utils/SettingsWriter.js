// lets commands like bb!bridge save lines into settings.txt,
// so setups done from Fluxer survive restarts.
import fs from "node:fs";
import Config from "./ConfigHandler.js";

function lines() {
  try { return fs.readFileSync(Config.SettingsFile, "utf-8").split(/\r?\n/); } catch { return []; }
}
function write(all) {
  fs.writeFileSync(Config.SettingsFile, all.join("\r\n").replace(/(\r\n)+$/, "") + "\r\n");
}
const keyOf = (line) => line.slice(0, line.indexOf(":")).trim().toLowerCase();
const parts = (line) => line.slice(line.indexOf(":") + 1).split("|").map((x) => x.trim());

/** Remove every "key:" line whose parts match, then add the new line (if any). */
export function replaceSetting(key, matches, newLine) {
  const kept = lines().filter((l) => !(l.includes(":") && !l.trim().startsWith("#") && keyOf(l) === key && matches(parts(l))));
  if (newLine) kept.push(newLine);
  write(kept);
}
