// configuration now comes from settings.txt (see utils/Settings.js)
// instead of Fluxcord's config.js, so there's only one plain-text file to edit.
import path from "node:path";
import { fileURLToPath } from "node:url";
import { loadSettings } from "./Settings.js";

export const AppDir = path.resolve(
  path.dirname(fileURLToPath(import.meta.url)),
  "..",
);

// (The two environment overrides exist only for the self-test.)
const settings = loadSettings(
  process.env.BRIDGE_SETTINGS_FILE || path.join(AppDir, "settings.txt"),
);

const DefaultConfig = {
  FluxerAPIBaseURL: "https://api.fluxer.app",
  FluxerCDNBaseURL: "https://fluxerusercontent.com",
  DataFolderPath: process.env.BRIDGE_DATA_DIR || path.join(AppDir, "data"),

  DiscordBotToken: settings.discordToken,
  /** @type {string[]} */
  DiscordVoiceTokens: [],
  // Filled in automatically once the Discord bot signs in.
  DiscordClientId: "0000000000000000000",
  FluxerBotToken: settings.fluxerToken,
  FluxerTempEmojiGuildId: settings.emojiCommunityId || "0000000000000000000",
  // The owner (one person, on Fluxer and optionally Discord) and the admins they choose.
  OwnerId: settings.adminIds[0] ?? null,
  OwnerDiscordId: settings.ownerDiscordId,
  AdminAccountIds: [...settings.adminIds, ...(settings.ownerDiscordId ? [settings.ownerDiscordId] : []), ...settings.extraAdmins.map((a) => a.id)],
  ManagersAreAdmins: settings.managersAreAdmins,
  BotName: settings.botName,
  BotBio: settings.botBio,
  DefaultVoiceChannel: settings.defaultVoice,
  ExtraAdmins: settings.extraAdmins,
  EmbedFooterContent: "",
  LoggingCategories: ["FLUXER", "DISCORD", "META", "MIRROR", "CATCHUP"],
  BotPrefix: settings.prefix,
  FluxerBioStart: "",
  DiscordBioStart: "",
  DatabaseEncryptionToken: "",
  PostgresConnectionString: "",
  /** @type {{ text: string, emoji: string | { fluxer: { name: string, id: string }, discord: string } | undefined }[]} */
  Motds: [],

  // Voice bridging is the heavy part of Fluxcord, so it stays off here.
  VoiceBridgingEnabled: false,
  RunnerWsPort: 8765,
  RunnerSecret: "",

  // Off: it opens a network port, which makes Windows show a firewall popup.
  HealthcheckEnabled: false,
  HealthcheckPort: 8080,
  HealthcheckHost: "127.0.0.1",

  InternalAssetsPrefixUrl: "https://fluxcord.jbcrn.dev/fluxcordInternalAssets",

  // Bridge settings
  Mirrors: settings.mirrors,
  Twins: settings.twins,
  SettingsFile: process.env.BRIDGE_SETTINGS_FILE || path.join(AppDir, "settings.txt"),
  MirrorStatuses: settings.mirrorStatuses,
  CatchUpDays: settings.catchUpDays,
  PracticeMode: !settings.discordToken,
  SettingsProblems: settings.problems,
  SettingsFileMissing: !!settings.missingFile,
  AppDir,
};

export default DefaultConfig;
