// DM bridging.
//
// Fluxer -> Discord. Someone DMs a mirror bot on Fluxer. The message reaches the real person
// on Discord from:
//   - someone with a linked bot (their own Discord bot): that bot, as-is.
//   - anyone else: the main Discord bot, as "**Name:** message".
//
// Discord -> Fluxer. The person answers on Discord:
//   - in a twin's DMs: it goes to that twin's owner.
//   - in the main bot's DMs, replying to a tagged message: it goes to whoever sent that one.
//   - in the main bot's DMs, anything else: it goes to the bot's owner.
// Either way, their mirror bot delivers it on Fluxer, so it shows up from them.
import fs from "node:fs";
import path from "node:path";
import { Routes as FluxerRoutes } from "@fluxerjs/core";
import Config from "./ConfigHandler.js";
import { log } from "./Logger.js";
import { getMirrorByDiscordId, setMirrorMessageHandler } from "./Mirrors.js";
import { resolveBridgeFiles } from "./FluxerWebhookSend.js";
import { getTwinByFluxerId, setTwinDmHandler } from "./Twins.js";

const FILE = path.join(Config.DataFolderPath, "dms.json");
const INTRO_EVERY_MS = 12 * 60 * 60 * 1000;
/** pairs: "mainBotId:discordMessageId" -> Fluxer sender; told: "discordUser:fluxerUser" -> time of last intro */
let state = { pairs: {}, told: {} };
try { state = { ...state, ...JSON.parse(fs.readFileSync(FILE, "utf-8")) }; } catch {}
let main = null;

function save() {
  const keys = Object.keys(state.pairs);
  if (keys.length > 1000) for (const k of keys.slice(0, keys.length - 1000)) delete state.pairs[k];
  try { fs.writeFileSync(FILE, JSON.stringify(state)); } catch {}
}

const nameOf = (u) => u?.globalName ?? u?.global_name ?? u?.displayName ?? u?.username ?? "Someone";
const ownerId = () => Config.OwnerId ?? null; // where replies with no clear recipient go
const isOwner = () => false; // everyone's DMs are name-tagged the same way

function filesFrom(attachments) {
  return [...(attachments?.values?.() ?? attachments ?? [])]
    .map((a) => ({ name: a.filename ?? a.name ?? "file", url: a.url ?? a.proxy_url ?? a.proxyUrl ?? a.proxyURL }))
    .filter((f) => f.url);
}

async function sendOnDiscord(client, discordUserId, content, files) {
  const user = await client.users.fetch(discordUserId);
  return user.send({
    content: content.slice(0, 2000),
    files: files.map((f) => ({ attachment: f.data, name: f.name })),
    allowedMentions: { parse: [] },
  });
}

/** Someone DMed a mirror bot on Fluxer. */
export async function onMirrorDM(mirror, msg) {
  if (msg.guildId || msg.guild_id) return;
  if (msg.author?.id === mirror.fluxerId || msg.author?.bot) return;
  const note = (t) => mirror.send(msg.channelId, { content: `-# ${t}`, allowed_mentions: { parse: [] } }).catch(() => {});
  if (!mirror.discordId) return note("I'm not linked to anyone on Discord yet, so this can't go anywhere.");

  const sender = msg.author;
  const files = await resolveBridgeFiles(filesFrom(msg.attachments));
  if (!msg.content && files.length === 0) return;

  // 1. Their own Discord bot, if they have one that's signed in.
  const twin = isOwner(sender.id) ? null : getTwinByFluxerId(sender.id);
  if (twin?.ready) {
    try {
      await sendOnDiscord(twin.client, mirror.discordId, msg.content ?? "", files);
      return;
    } catch (e) {
      log("MIRROR", `${twin.name}'s Discord bot couldn't DM ${mirror.name}: ${e?.message ?? e}`);
      note(`Your Discord bot couldn't reach ${mirror.name} (it has to be in a Discord server with them), so the main bot passed it on instead.`);
    }
  }

  // 2. The main Discord bot: untagged for the owner, tagged for everyone else.
  if (!main?.isReady?.()) return note("Discord isn't connected right now, so this didn't go through. Try again later.");
  let content = msg.content ?? "";
  if (!isOwner(sender.id)) {
    const who = nameOf(sender);
    const key = `${mirror.discordId}:${sender.id}`;
    const intro = Date.now() - (state.told[key] ?? 0) > INTRO_EVERY_MS
      ? `-# ${who} is messaging you from Fluxer. To answer ${who}, reply to their message. Anything else you send here goes to the bot's owner.\n`
      : "";
    content = `${intro}**${who}:** ${content}`;
    state.told[key] = Date.now();
  }
  try {
    const sent = await sendOnDiscord(main, mirror.discordId, content, files);
    if (!isOwner(sender.id)) state.pairs[`${main.user.id}:${sent.id}`] = sender.id;
    save();
  } catch (e) {
    log("MIRROR", `DM to ${mirror.name} on Discord failed: ${e?.message ?? e}`);
    note(`Couldn't deliver that. ${mirror.name} might have DMs from server members turned off on Discord.`);
  }
}

/** Their mirror delivers a Discord DM to a Fluxer person. */
async function deliver(msg, target) {
  const mirror = getMirrorByDiscordId(msg.author.id);
  if (!mirror) {
    await msg.reply("I only pass DMs along for people who have a mirror bot on Fluxer.").catch(() => {});
    return;
  }
  if (!mirror.ready) {
    await msg.reply("Your Fluxer side isn't online right now, so that didn't go through.").catch(() => {});
    return;
  }
  if (!target) {
    await msg.reply("I don't know who that's for. Reply to someone's message to answer them.").catch(() => {});
    return;
  }
  const files = await resolveBridgeFiles(filesFrom(msg.attachments));
  if (!msg.content && files.length === 0) return;
  try {
    const dm = await mirror.client.rest.post(FluxerRoutes.userMeChannels(), { body: { recipient_id: target }, auth: true });
    await mirror.send(dm.id, { content: msg.content ?? "", files, allowed_mentions: { parse: [] } });
  } catch (e) {
    log("MIRROR", `DM from ${mirror.name} on Fluxer failed: ${e?.message ?? e}`);
    await msg.reply("Couldn't deliver that on Fluxer. They might not accept DMs from bots.").catch(() => {});
  }
}

/** Someone DMed the main Discord bot. */
export async function onDiscordDM(msg) {
  if (msg.author?.bot) return;
  const ref = msg.reference?.messageId;
  const target = (ref && main?.user && state.pairs[`${main.user.id}:${ref}`]) || ownerId();
  await deliver(msg, target);
}

/** Someone DMed a twin (a Fluxer person's own Discord bot). */
export async function onTwinDM(twin, msg) {
  if (msg.author?.bot) return;
  await deliver(msg, twin.fluxerId);
}

export function attachDmBridge(discordClient) {
  main = discordClient;
  setMirrorMessageHandler((mirror, msg) => onMirrorDM(mirror, msg).catch((e) => log("MIRROR", "DM bridge error:", e?.message ?? e)));
  setTwinDmHandler((twin, msg) => onTwinDM(twin, msg).catch((e) => log("MIRROR", "DM bridge error:", e?.message ?? e)));
}
