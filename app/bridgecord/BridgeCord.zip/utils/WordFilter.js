// The word filter (bb!filter).
//
// One list of words for both sides: every bridged server, on Fluxer and on Discord. A message with one of the words
// is deleted where it was sent, before the bridge carries it over, with a short warning that goes away by itself.
// Everyone's messages count (people, other bots and apps), the owner's included. Only the bridge's own copies are skipped,
// since the original was already caught where it was sent.
//
// Spelled-around versions are caught too: capitals, stretched letters (fuuuck), symbols for letters (f*ck, sh1t, @ss),
// letters split up (f.u.c.k, f u c k) and endings (fucking, fucked, fucks). A * on the end of a word catches longer
// words that start with it ("fuck*" also gets "fuckery"), and *word* catches it anywhere, even inside other words.
import fs from "node:fs";
import path from "node:path";
import { Events as FluxerEvents, Routes as FluxerRoutes } from "@fluxerjs/core";
import { Events as DiscordEvents } from "discord.js";
import Config from "./ConfigHandler.js";
import { ChannelMap } from "../db/index.js";
import { isMirrorFluxerId } from "./Mirrors.js";
import { log } from "./Logger.js";

const FILE = path.join(Config.DataFolderPath, "word-filter.json");
let data = null;
function load() {
  if (data) return data;
  try { data = JSON.parse(fs.readFileSync(FILE, "utf-8")); } catch {}
  if (!data) { data = { words: [], warn: true }; save(); }
  return data;
}
function save() { try { fs.writeFileSync(FILE, JSON.stringify(data, null, 1)); } catch {} }
export const filterWords = () => [...load().words];
/** Replace the list (a string with commas or new lines, or an array). Returns the new list. */
export function setFilterWords(words) {
  const list = (Array.isArray(words) ? words : String(words ?? "").split(/[,\n]+/)).map((w) => String(w).trim().toLowerCase()).filter(Boolean);
  load().words = [...new Set(list)].slice(0, 500);
  compiled = null;
  save();
  return filterWords();
}

// ---------------- matching ----------------
const LEET = { "@": "a", "4": "a", "3": "e", "1": "i", "!": "i", "|": "i", "0": "o", "$": "s", "5": "s", "7": "t", "+": "t", "8": "b", "9": "g" };
const VOWEL = /[aeiou]/;
/** Lowercase, no accents, no invisible characters, symbols that stand for letters turned into those letters. */
function normalize(text) {
  return String(text ?? "")
    .normalize("NFKD").replace(/[\u0300-\u036f]/g, "")
    .replace(/[\u200b-\u200f\u2060\ufeff\u00ad]/g, "")
    .toLowerCase()
    .replace(/<a?:(\w+):\d+>/g, " $1 ") // (custom emoji: their names count)
    .replace(/https?:\/\/\S+/g, " ") // (links don't)
    .replace(/[@4310!|$57+89]/g, (c, i, s) => {
      // a symbol only counts as a letter inside a word (so "3 people" or "$5" don't turn into letters)
      const near = (s[i - 1] ?? " ") + (s[i + 1] ?? " ");
      return /[a-z*]/.test(near) ? LEET[c] : c;
    });
}
const ENDINGS = "(?:s|es|ed|d|er|ers|ing|in|n|y|ies|ty|a|as|az|z|ah)?";
let compiled = null;
function compile() {
  if (compiled) return compiled;
  compiled = [];
  for (const raw of load().words) {
    const anywhere = /^\*.*\*$/.test(raw), longer = /\*$/.test(raw) && !anywhere;
    const word = normalize(raw.replace(/^\*|\*$/g, "")).replace(/[^a-z0-9 ]/g, "");
    if (!word.trim()) continue;
    // each letter can be stretched (fuuuck), and a vowel can be a * (f*ck); a space can be any gap
    const body = [...word].map((ch) => (ch === " " ? "[^a-z0-9]+" : `${VOWEL.test(ch) ? `(?:${ch}|\\*)` : ch}+`)).join("");
    const re = anywhere ? body : `(?<![a-z0-9])${body}${longer ? "[a-z]*" : ENDINGS}(?![a-z0-9])`;
    compiled.push({ raw, re: new RegExp(re, "i") });
  }
  return compiled;
}
/** The filtered word in this text, or null. */
export function blockedWord(text) {
  const list = compile();
  if (!list.length || !text) return null;
  const t = normalize(text);
  // letters split up with dots, dashes, stars or spaces ("f.u.c.k", "f u c k"): put back together to check too
  const joined = t.replace(/(?<![a-z0-9])[a-z](?:[\s._\-*~/\\,]+[a-z](?![a-z0-9])){2,}/g, (run) => run.replace(/[^a-z]/g, ""));
  for (const w of list) if (w.re.test(t) || w.re.test(joined)) return w.raw;
  return null;
}

// ---------------- where it applies: every server with a bridged channel ----------------
let places = { at: 0, discord: new Set(), fluxer: new Set(), hooks: new Set() };
export async function placesNow() {
  if (Date.now() - places.at < 5 * 60_000) return places;
  const maps = await ChannelMap.findAll({ raw: true }).catch(() => []);
  places = {
    at: Date.now(),
    discord: new Set(maps.map((m) => String(m.discordGuildId)).filter(Boolean)),
    fluxer: new Set(maps.map((m) => String(m.fluxerGuildId)).filter(Boolean)),
    hooks: new Set(maps.flatMap((m) => [m.discordWebhookId, m.fluxerWebhookId]).filter(Boolean).map(String)),
  };
  return places;
}
const textOf = (m) => [m?.content, ...(m?.embeds ?? []).flatMap((e) => [e?.title, e?.description])].filter(Boolean).join("\n");

/** Discord: a message with a filtered word is deleted (true), so nothing else should use it. */
export async function filterOnDiscord(msg, discordClient) {
  if (!msg?.guildId || msg.author?.id === discordClient?.user?.id) return false;
  const hit = blockedWord(textOf(msg));
  if (!hit) return false;
  const p = await placesNow();
  if (!p.discord.has(String(msg.guildId))) return false;
  if (msg.webhookId && p.hooks.has(String(msg.webhookId))) return false; // (a bridged copy: caught on Fluxer already)
  await msg.delete().catch((e) => log("META", `Word filter couldn't delete a Discord message (${e?.message ?? e}). My bot needs Manage Messages there.`));
  if (load().warn !== false && !msg.author?.bot) {
    const warn = await msg.channel?.send?.({ content: `<@${msg.author.id}>, that word isn't allowed here.`, allowedMentions: { users: [msg.author.id] } }).catch(() => null);
    if (warn) setTimeout(() => warn.delete().catch(() => {}), 6000);
  }
  return true;
}

/** Fluxer: same thing. Mirror bots and the bridge's webhook posts are copies, so they're skipped. */
export async function filterOnFluxer(msg, fluxerClient) {
  if (!msg?.guildId || msg.author?.id === fluxerClient?.user?.id || isMirrorFluxerId(msg.author?.id)) return false;
  const hit = blockedWord(textOf(msg));
  if (!hit) return false;
  const p = await placesNow();
  if (!p.fluxer.has(String(msg.guildId))) return false;
  if (msg.webhookId && p.hooks.has(String(msg.webhookId))) return false;
  await fluxerClient.rest.delete(FluxerRoutes.channelMessage(msg.channelId, msg.id), { auth: true })
    .catch((e) => log("META", `Word filter couldn't delete a Fluxer message (${e?.message ?? e}). The bridge bot needs Manage Messages there.`));
  if (load().warn !== false && !msg.author?.bot) {
    const warn = await fluxerClient.rest.post(FluxerRoutes.channelMessages(msg.channelId), { body: { content: `<@${msg.author.id}>, that word isn't allowed here.`, allowed_mentions: { users: [String(msg.author.id)] } }, auth: true }).catch(() => null);
    if (warn?.id) setTimeout(() => fluxerClient.rest.delete(FluxerRoutes.channelMessage(msg.channelId, warn.id), { auth: true }).catch(() => {}), 6000);
  }
  return true;
}

/** Edits count too: a message edited to have a filtered word goes (and its copy follows, through the bridge). */
export function attachWordFilter(discordClient, fluxerClient) {
  discordClient.on(DiscordEvents.MessageUpdate, async (_old, m) => {
    try { if (m?.partial) m = await m.fetch(); if (m && !m.author?.bot) await filterOnDiscord(m, discordClient); } catch {}
  });
  fluxerClient.on(FluxerEvents.MessageUpdate, async (_old, m) => {
    try { if (m?.content != null) await filterOnFluxer(m, fluxerClient); } catch {}
  });
}
