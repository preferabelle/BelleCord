// mirror bots.
//
// A mirror is a real Fluxer bot account that stands in for one Discord person.
// When that person talks on Discord, the bridge posts through their mirror
// instead of the webhook, so on Fluxer they have roles, a profile, a spot in the
// member list, and an online status that follows their Discord status.
//
// Nothing is ever deleted and re-sent: the mirror's message is the first and
// only copy, so the other side never sees anything disappear.

import {
  Client as FluxerClient,
  Events as FluxerEvents,
  Routes as FluxerRoutes,
} from "@fluxerjs/core";
import Config from "./ConfigHandler.js";
import { log } from "./Logger.js";
import { buildFluxerUserAgent } from "./UserAgent.js";
import { replaceSetting } from "./SettingsWriter.js";
import { twins } from "./Twins.js";
import { fluxerIdFromToken } from "./Settings.js";

// Dispatches a mirror never needs. Skipping them keeps each mirror's
// connection close to idle.
// (MESSAGE_CREATE stays on so mirrors can receive DMs for the DM bridge.)
const IGNORED_EVENTS = [
  "MESSAGE_UPDATE",
  "MESSAGE_DELETE",
  "MESSAGE_DELETE_BULK",
  "MESSAGE_REACTION_ADD",
  "MESSAGE_REACTION_ADD_MANY",
  "MESSAGE_REACTION_REMOVE",
  "MESSAGE_REACTION_REMOVE_ALL",
  "MESSAGE_REACTION_REMOVE_EMOJI",
  "TYPING_START",
  "PRESENCE_UPDATE",
  "VOICE_STATE_UPDATE",
  "CHANNEL_PINS_UPDATE",
  "GUILD_MEMBER_LIST_UPDATE",
];

/** Set by KickSync: called with (mirror, guild) when a mirror is removed from a community. */
let mirrorRemovedHandler = null;
export function setMirrorRemovedHandler(fn) {
  mirrorRemovedHandler = fn;
}

/** Set by the DM bridge: called with (mirror, message) for every message a mirror sees. */
let mirrorMessageHandler = null;
export function setMirrorMessageHandler(fn) {
  mirrorMessageHandler = fn;
}

// Fluxer allows 5 presence changes per 20 seconds per connection.
const PRESENCE_MIN_GAP_MS = 4500;

/** Mirror bots need these to post like a person does. */
export const MIRROR_PERMISSIONS = (
  (1n << 6n) | // Add Reactions
  (1n << 10n) | // View Channel
  (1n << 11n) | // Send Messages
  (1n << 14n) | // Embed Links
  (1n << 15n) | // Attach Files
  (1n << 16n) | // Read Message History
  (1n << 18n) | // Use External Emojis
  (1n << 20n) | // Connect (so a mirror can show up in voice with its person)
  (1n << 26n) | // Change Nickname
  (1n << 37n) // Use External Stickers
).toString();

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

function describeError(e) {
  const code = e?.code ?? e?.rawError?.code ?? e?.status ?? e?.statusCode;
  const msg = e?.message ?? String(e);
  return code ? `${code}: ${msg}` : msg;
}

/** Trims to at most `max` characters without splitting emoji. */
function clip(text, max) {
  const chars = Array.from(text);
  return chars.length <= max ? text : chars.slice(0, max - 1).join("") + "…";
}

/**
 * Turns a discord.js Presence into what a mirror should show on Fluxer.
 * Offline/invisible on Discord becomes invisible on Fluxer (shows as offline).
 * @param {any} presence
 * @returns {{ status: "online"|"idle"|"dnd"|"invisible", text: string|null, emoji: string|null }}
 */
export function presenceFromDiscord(presence) {
  const raw = presence?.status ?? "offline";
  const status = raw === "online" || raw === "idle" || raw === "dnd" ? raw : "invisible";
  if (status === "invisible") return { status, text: null, emoji: null };

  const acts = presence?.activities ?? [];
  const byType = (t) => acts.find((a) => a?.type === t);
  const custom = byType(4);
  const listening = byType(2);
  const playing = byType(0);
  const streaming = byType(1);
  const watching = byType(3);
  const competing = byType(5);

  let text = null;
  let emoji = null;
  if (custom && (custom.state || (custom.emoji && !custom.emoji.id))) {
    text = custom.state || null;
    emoji = custom.emoji && !custom.emoji.id ? custom.emoji.name : null;
  } else if (listening) {
    const song = listening.details;
    const artist = listening.state;
    text = song ? (artist ? `${song} · ${artist}` : song) : `Listening to ${listening.name}`;
    emoji = "🎧";
  } else if (playing) {
    text = `Playing ${playing.name}`;
    emoji = "🎮";
  } else if (streaming) {
    text = `Streaming ${streaming.details || streaming.name}`;
  } else if (watching) {
    text = `Watching ${watching.name}`;
  } else if (competing) {
    text = `Competing in ${competing.name}`;
  }

  return { status, text: text ? clip(text, 128) : null, emoji };
}

class Mirror {
  /** @param {{name: string, discordRef: string|null, discordId: string|null, token: string, fluxerId: string}} def */
  constructor(def) {
    this.name = def.name;
    this.discordRef = def.discordRef;
    this.discordId = def.discordId;
    this.token = def.token;
    this.fluxerId = def.fluxerId;
    /** @type {FluxerClient | null} */
    this.client = null;
    this.ready = false;
    this.tag = null;
    this.signInError = null;
    /** @type {{status: string, text: string|null, emoji: string|null} | null} */
    this.presence = null;
    this.presenceTimer = null;
    this.lastPresenceAt = 0;
    this.lastPresenceKey = "";
    /** What Fluxer says this mirror is currently showing (seen by the main bot). */
    this.fluxerShows = null;
    this.confirmTimer = null;
    this.statusRetries = 0;
    this.lastReconnectAt = 0;
  }

  /** The status in the toolkit's shape, with every field Fluxer's gateway expects. */
  sdkPresence(p = this.presence) {
    if (!p) return { status: "invisible", since: null, afk: false, activities: [] };
    return {
      status: p.status,
      since: null,
      afk: false,
      activities: [],
      customStatus: p.text || p.emoji ? { text: p.text ?? null, emojiName: p.emoji ?? null } : null,
    };
  }

  start() {
    this.client = new FluxerClient({
      rest: {
        api: Config.FluxerAPIBaseURL,
        userAgent: buildFluxerUserAgent(),
      },
      // Sign in already showing the right status (the most reliable way to set it).
      presence: this.sdkPresence(),
      cache: { messages: false },
      ignoredEvents: IGNORED_EVENTS,
      gatewayDebug: false,
    });

    this.client.on(FluxerEvents.Ready, () => {
      this.ready = true;
      this.signInError = null;
      const u = this.client?.user;
      this.tag = u ? `${u.username}#${u.discriminator}` : this.name;
      log("MIRROR", `${this.name} is signed in as ${this.tag}.`);
      // Re-apply whatever status we last knew about.
      this.lastPresenceKey = "";
      if (this.presence) this.flushPresence();
    });
    this.client.on(FluxerEvents.MessageCreate, (msg) => {
      if (!msg.guildId) mirrorMessageHandler?.(this, msg); // DMs only
    });
    // Kicked or banned from a community (outages don't count).
    this.client.on(FluxerEvents.GuildDelete, (guild) => mirrorRemovedHandler?.(this, guild));
    this.client.on(FluxerEvents.Error, (e) => {
      log("MIRROR", `${this.name}: ${describeError(e)}`);
    });

    this.client.login(this.token).catch((e) => {
      this.signInError = describeError(e);
      log(
        "MIRROR",
        `${this.name} couldn't sign in. Check its token in settings.txt. (${this.signInError})`,
      );
    });
  }

  get rest() {
    return this.client?.rest;
  }

  inviteLink(webappUrl = "https://web.fluxer.app") {
    return `${webappUrl}/oauth2/authorize?client_id=${this.fluxerId}&scope=bot&permissions=${MIRROR_PERMISSIONS}`;
  }

  /** Is this mirror a member of the given Fluxer community (as far as we know)? */
  inCommunity(guildId) {
    try {
      return this.client?.guilds?.cache?.has?.(guildId) ?? this.client?.guilds?.has?.(guildId) ?? null;
    } catch {
      return null;
    }
  }

  /**
   * Post a message as this mirror.
   * @param {string} channelId
   * @param {{content?: string, embeds?: any[], files?: {name: string, data: any, flags?: number, description?: string}[], message_reference?: any, allowed_mentions?: any}} params
   */
  async send(channelId, params) {
    const { files, ...json } = params;
    const attachments = [];
    const resolvedFiles = [];
    for (const f of files ?? []) {
      if (!f?.data) continue;
      const id = resolvedFiles.length;
      resolvedFiles.push({ name: f.name, filename: f.name, data: f.data });
      const a = { id, filename: f.name };
      if (f.flags !== undefined) a.flags = f.flags;
      if (f.description != null) a.description = f.description;
      attachments.push(a);
    }
    if (resolvedFiles.length) json.attachments = attachments;
    if (!json.message_reference) delete json.message_reference;
    return await this.client.rest.post(FluxerRoutes.channelMessages(channelId), {
      body: json,
      files: resolvedFiles.length ? resolvedFiles : undefined,
      auth: true,
    });
  }

  async edit(channelId, messageId, body) {
    return await this.client.rest.patch(
      FluxerRoutes.channelMessage(channelId, messageId),
      { body, auth: true },
    );
  }

  async react(channelId, messageId, emojiStr, add) {
    const route = `${FluxerRoutes.channelMessageReaction(channelId, messageId, emojiStr)}/@me`;
    if (add) await this.client.rest.put(route, { auth: true });
    else await this.client.rest.delete(route, { auth: true });
  }

  async typing(channelId) {
    await this.client.rest.post(FluxerRoutes.channelTyping(channelId), { auth: true });
  }

  /** @param {{status: "online"|"idle"|"dnd"|"invisible", text: string|null, emoji: string|null}} p */
  setPresence(p) {
    this.presence = p;
    if (this.presenceTimer) return;
    const wait = Math.max(800, PRESENCE_MIN_GAP_MS - (Date.now() - this.lastPresenceAt));
    this.presenceTimer = setTimeout(() => {
      this.presenceTimer = null;
      this.flushPresence();
    }, wait);
  }

  flushPresence() {
    if (!this.ready || !this.client?.user || !this.presence) return;
    const p = this.presence;
    const key = JSON.stringify(p);
    if (key === this.lastPresenceKey) return;
    try {
      this.client.user.setPresence(/** @type {any} */ (this.sdkPresence(p)));
      this.lastPresenceAt = Date.now();
      this.lastPresenceKey = key;
      log("MIRROR", `${this.name} -> ${p.status === "invisible" ? "offline" : p.status}${p.text ? ` ("${p.text}")` : ""}`);
      this.confirmSoon();
    } catch (e) {
      log("MIRROR", `${this.name}: couldn't update status (${describeError(e)})`);
    }
  }

  /** Did Fluxer actually apply it? If Fluxer reports statuses and it didn't, sign in again with it. */
  confirmSoon() {
    clearTimeout(this.confirmTimer);
    this.confirmTimer = setTimeout(() => {
      if (!fluxerReportsStatuses || !this.presence || !this.ready) return;
      const want = this.presence.status === "invisible" ? ["offline", "invisible"] : [this.presence.status];
      if (this.fluxerShows && want.includes(this.fluxerShows.status)) {
        this.statusRetries = 0;
        return;
      }
      if (this.statusRetries >= 3) {
        if (this.statusRetries === 3) log("MIRROR", `Fluxer isn't taking ${this.name}'s status changes. It still shows ${this.fluxerShows?.status ?? "nothing"}. I'll stop retrying until the next change.`);
        this.statusRetries++;
        return;
      }
      if (Date.now() - this.lastReconnectAt < statusTiming.reconnectGapMs) return;
      this.statusRetries++;
      this.lastReconnectAt = Date.now();
      log("MIRROR", `Fluxer still shows ${this.name} as ${this.fluxerShows?.status ?? "nothing"}, so I'm signing it in again already showing ${want[0]} (try ${this.statusRetries} of 3).`);
      this.reconnect();
    }, statusTiming.confirmMs);
  }

  async reconnect() {
    this.ready = false;
    const old = this.client;
    this.client = null;
    await old?.destroy?.().catch?.(() => {});
    this.lastPresenceKey = "";
    this.start();
  }
}

/** How long to wait before double-checking a status, and the minimum gap between re-sign-ins (adjustable for tests). */
export const statusTiming = { confirmMs: 20_000, reconnectGapMs: 60_000 };
/** Becomes true once Fluxer has sent the main bot any status update, so we know we can double-check. */
let fluxerReportsStatuses = false;

/** The main Fluxer bot saw someone's status on Fluxer. If it's a mirror, remember it. */
export function noteFluxerPresence(p) {
  fluxerReportsStatuses = true;
  const m = byFluxerId.get(p?.userId);
  if (!m) return;
  m.fluxerShows = { status: p.status ?? "offline", text: p.customStatus?.text ?? null, at: Date.now() };
  if (m.presence) {
    const want = m.presence.status === "invisible" ? ["offline", "invisible"] : [m.presence.status];
    if (want.includes(m.fluxerShows.status)) m.statusRetries = 0;
  }
}

/** @type {Mirror[]} */
export const mirrors = (Config.Mirrors ?? []).map((d) => new Mirror(d));
const byFluxerId = new Map(mirrors.map((m) => [m.fluxerId, m]));

/** add (or update) a mirror while running, from bb!bridge. */
export async function addMirror(def) {
  // One mirror per Discord person: retire any other bot that was standing in for them.
  for (const other of mirrors.filter((m) => def.discordId && m.discordId === def.discordId && m.fluxerId !== def.fluxerId)) {
    await removeMirror(other);
  }
  const existing = byFluxerId.get(def.fluxerId);
  const m = existing ?? new Mirror(def);
  if (existing) {
    Object.assign(existing, { name: def.name, discordId: def.discordId, discordRef: def.discordRef });
  } else {
    mirrors.push(m);
    byFluxerId.set(m.fluxerId, m);
    m.start();
  }
  // Copy their current Discord status right away (applied as soon as the bot is signed in).
  if (m.discordId && Config.MirrorStatuses && discordForStatus?.isReady?.()) {
    m.setPresence(presenceFromDiscord(findDiscordPresence(discordForStatus, m.discordId)));
  }
  return m;
}

export async function removeMirror(m) {
  const i = mirrors.indexOf(m);
  if (i >= 0) mirrors.splice(i, 1);
  byFluxerId.delete(m.fluxerId);
  m.ready = false;
  await m.client?.destroy?.().catch?.(() => {});
}

export function isMirrorFluxerId(id) {
  return !!id && byFluxerId.has(String(id));
}

export function getMirrorByDiscordId(id) {
  if (!id) return null;
  return mirrors.find((m) => m.discordId === String(id)) ?? null;
}

export function getReadyMirrorForDiscordUser(id) {
  const m = getMirrorByDiscordId(id);
  return m?.ready ? m : null;
}

export function getMirrorByName(name) {
  if (!name) return null;
  const n = name.replace(/^@/, "").toLowerCase();
  return (
    mirrors.find((m) => m.name.toLowerCase() === n) ??
    mirrors.find((m) => (m.tag ?? "").toLowerCase() === n) ??
    mirrors.find((m) => (m.tag ?? "").toLowerCase().split("#")[0] === n) ??
    null
  );
}

export async function startMirrors() {
  for (const m of mirrors) {
    m.start();
    // Stagger sign-ins so Fluxer doesn't see a burst of identifies.
    await sleep(1500);
  }
}

/**
 * Discord → Fluxer: a ping of a mirrored person becomes a ping of their mirror.
 * @param {string | null | undefined} content
 */
export function discordMentionsToMirrors(content) {
  if (!content) return content;
  return content.replace(/<@!?(\d{15,21})>/g, (full, id) => {
    const m = getMirrorByDiscordId(id);
    if (m) return `<@${m.fluxerId}>`;
    // Pinging someone's own linked Discord bot pings them.
    const twin = twins.find((t) => t.botId === id || t.client?.user?.id === id);
    if (twin) return `<@${twin.fluxerId}>`;
    return full;
  });
}

/**
 * Fluxer → Discord: a ping of a mirror becomes a real ping of the Discord person.
 * @param {string | null | undefined} content
 */
export function fluxerMentionsToDiscord(content) {
  if (!content) return content;
  return content.replace(/<@!?(\d{15,21})>/g, (full, id) => {
    const m = byFluxerId.get(id);
    return m?.discordId ? `<@${m.discordId}>` : full;
  });
}

function namesOf(user, member) {
  return [
    user?.username,
    user?.globalName,
    member?.displayName,
    member?.nickname,
  ]
    .filter(Boolean)
    .map((s) => String(s).toLowerCase());
}

let discordForStatus = null;
/** The Discord connection, so a mirror linked mid-run can copy its person's status right away. */
export function setMirrorDiscord(discordClient) {
  discordForStatus = discordClient;
}

/** Link a mirror to a Discord person, save it in settings.txt, and copy their status now. */
export function linkMirror(m, user) {
  m.discordId = user.id;
  m.discordRef = user.id;
  log("MIRROR", `Linked mirror "${m.name}" to Discord user @${user.username} (${user.id}), and saved it in settings.txt.`);
  try {
    replaceSetting("mirror", (p) => fluxerIdFromToken(p[2]) === m.fluxerId, `mirror: ${m.name} | ${user.id} | ${m.token}`);
  } catch (e) {
    log("MIRROR", `Couldn't save ${m.name}'s Discord ID to settings.txt: ${e?.message ?? e}`);
  }
  if (Config.MirrorStatuses && discordForStatus?.isReady?.()) {
    m.setPresence(presenceFromDiscord(findDiscordPresence(discordForStatus, user.id)));
  }
}

/** Rename a mirror (the name used in bb!practice and in DMs), and save it. */
export function renameMirror(m, newName) {
  m.name = newName;
  replaceSetting("mirror", (p) => fluxerIdFromToken(p[2]) === m.fluxerId, `mirror: ${m.name} | ${m.discordId ?? m.discordRef ?? "their Discord ID"} | ${m.token}`);
}

/**
 * For mirrors set up with a Discord username instead of an ID:
 * link them the first time we see that person post.
 */
export function noteDiscordAuthor(user, member) {
  if (!user?.id) return;
  for (const m of mirrors) {
    if (m.discordId || !m.discordRef) continue;
    if (namesOf(user, member).includes(m.discordRef.replace(/^@/, "").toLowerCase())) {
      linkMirror(m, user);
    }
  }
}

/** At startup, look up any mirrors that were given a username instead of an ID. */
export async function resolveMirrorNames(discordClient) {
  setMirrorDiscord(discordClient);
  for (const m of mirrors) {
    if (m.discordId || !m.discordRef) continue;
    const wanted = m.discordRef.replace(/^@/, "").toLowerCase();
    for (const guild of discordClient.guilds.cache.values()) {
      try {
        const found = await guild.members.search({ query: wanted, limit: 10 });
        const hit = [...found.values()].find((mem) => namesOf(mem.user, mem).includes(wanted));
        if (hit) {
          linkMirror(m, hit.user);
          break;
        }
      } catch {}
    }
    if (!m.discordId) {
      log(
        "MIRROR",
        `Couldn't find a Discord user called "${m.discordRef}" for mirror "${m.name}" yet. Try bb!who to see names and IDs.`,
      );
    }
  }
}

/** Find someone's current Discord presence across every server the bot shares with them. */
export function findDiscordPresence(discordClient, userId) {
  for (const guild of discordClient.guilds.cache.values()) {
    const p = guild.presences?.cache?.get(userId);
    if (p) return p;
  }
  return null;
}

/** Copy every mirrored person's current Discord status onto their mirror. */
export function syncAllPresences(discordClient) {
  for (const m of mirrors) {
    if (!m.discordId) continue;
    m.setPresence(presenceFromDiscord(findDiscordPresence(discordClient, m.discordId)));
  }
}
