import Config from "./ConfigHandler.js";
import { Guild } from "@fluxerjs/core";
import { ChannelMap } from "../db/index.js";

/**
 * the bot's "about me" in each community/server, in the bot's voice.
 * @param {import("@fluxerjs/core").Guild | import("discord.js").Guild} guild
 */
export default async function changeBotBio(guild) {
  const isFluxer = guild instanceof Guild;
  let bridged = 0;
  try {
    bridged = await ChannelMap.count({ where: isFluxer ? { fluxerGuildId: guild.id } : { discordGuildId: guild.id } });
  } catch {}
  // The bio: "bot bio" from settings.txt if set, plus how many channels are bridged.
  const custom = Config.BotBio ? `${Config.BotBio}\n\n` : "";
  const bio = `${custom}Bridging ${bridged} channel${bridged === 1 ? "" : "s"} between Fluxer and Discord. Type ${Config.BotPrefix}help for commands.`;
  try {
    if (isFluxer) await guild.members.me.edit({ bio });
    else await guild.members.editMe({ bio });
  } catch {
    // Some servers don't allow bots a bio; that's fine.
  }
}

/** Refresh the bio everywhere (at startup), so old text is replaced right away. */
export async function refreshAllBios(fluxerClient, discordClient) {
  for (const guild of fluxerClient?.guilds?.values?.() ?? fluxerClient?.guilds?.cache?.values?.() ?? []) await changeBotBio(guild);
  for (const guild of discordClient?.guilds?.cache?.values?.() ?? []) await changeBotBio(guild);
}
