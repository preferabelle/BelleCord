// Extras: features that plug into both bots without living inside the bridge itself (polls, auto-replies,
// the word filter...). Each file in utils/extras/ exports start(ctx). index.js calls startExtras once both bots exist.
//   ctx.discord / ctx.fluxer   the two bots
//   ctx.withDiscord(fn)        fn(discordBot) (right away: the bot exists from the start)
//   ctx.withFluxer(fn)         fn(fluxerBot)
//   ctx.log(...)               a line in the bridge's log
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { log } from "./Logger.js";

const HERE = path.join(path.dirname(fileURLToPath(import.meta.url)), "extras");

export async function startExtras(discord, fluxer) {
  let files = [];
  try { files = fs.readdirSync(HERE).filter((f) => f.endsWith(".js")).sort(); } catch {}
  for (const f of files) {
    const name = f.replace(/\.js$/, "");
    const ctx = { discord, fluxer, withDiscord: (fn) => fn(discord), withFluxer: (fn) => fn(fluxer), log: (...a) => log("EXTRAS", `${name}:`, ...a) };
    try {
      const mod = await import(`./extras/${f}`);
      await mod.start?.(ctx);
    } catch (e) { log("EXTRAS", `${name} didn't start:`, e?.message ?? e); }
  }
}
