// per-person voice volume in the bridge (for everyone), saved across restarts.
// 100 = normal, 0 = muted, up to 200 = louder. Keys: "discord:<id>" or "fluxer:<id>".
import fs from "node:fs";
import path from "node:path";
import Config from "./ConfigHandler.js";

const FILE = path.join(Config.DataFolderPath, "voice-levels.json");
let levels = {};
try { levels = JSON.parse(fs.readFileSync(FILE, "utf-8")); } catch {}
const save = () => { try { fs.writeFileSync(FILE, JSON.stringify(levels)); } catch {} };

export function getLevel(side, id) {
  return levels[`${side}:${id}`] ?? 100;
}
export function setLevel(side, id, pct) {
  const v = Math.max(0, Math.min(200, Math.round(pct)));
  if (v === 100) delete levels[`${side}:${id}`];
  else levels[`${side}:${id}`] = v;
  save();
  return v;
}
/** Scale audio by a level (returns a new array, or the same one at 100%). */
export function applyLevel(samples, pct) {
  if (pct === 100) return samples;
  const g = pct / 100;
  const out = new Int16Array(samples.length);
  for (let i = 0; i < samples.length; i++) {
    const v = samples[i] * g;
    out[i] = v > 32767 ? 32767 : v < -32768 ? -32768 : v;
  }
  return out;
}
