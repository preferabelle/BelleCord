// twins. A twin is a Discord bot that stands in for one Fluxer person
// in DMs (the reverse of a mirror). When that person DMs someone's mirror on Fluxer,
// their twin delivers it on Discord, so it shows up from "them" with no name tag.
// Twins only need DMs, so they use no special Discord switches.
import { Client as DiscordClient, Events, GatewayIntentBits, Partials } from "discord.js";
import Config from "./ConfigHandler.js";
import { log } from "./Logger.js";

/** @type {{name: string, fluxerId: string, token: string, client: any, ready: boolean, tag: string|null, botId: string|null, error: string|null}[]} */
export const twins = [];
let dmHandler = null;
export function setTwinDmHandler(fn) { dmHandler = fn; }

// View/send/read history/attach/embed/react/external emoji (to talk in channels for their person),
// connect/speak/voice activity (voice), change nickname.
export const twinInviteLink = (botId) => `https://discord.com/oauth2/authorize?client_id=${botId}&scope=bot&permissions=104188992`;

function start(t) {
  // DMs for the DM bridge, plus servers and voice states so it can sit in the bridged voice call.
  const c = new DiscordClient({ intents: [GatewayIntentBits.DirectMessages, GatewayIntentBits.Guilds, GatewayIntentBits.GuildVoiceStates], partials: [Partials.Channel] });
  t.client = c;
  c.once(Events.ClientReady, () => {
    t.ready = true;
    t.tag = c.user?.tag ?? t.name;
    t.botId = c.user?.id ?? t.botId;
    log("MIRROR", `${t.name}'s Discord bot is signed in as ${t.tag}.`);
  });
  c.on(Events.MessageCreate, (msg) => {
    if (msg.guildId || msg.author?.bot || msg.author?.id === c.user?.id) return;
    dmHandler?.(t, msg);
  });
  c.login(t.token).catch((e) => {
    t.error = e?.message ?? String(e);
    log("MIRROR", `${t.name}'s Discord bot couldn't sign in: ${t.error}`);
  });
}

export function startTwins() {
  for (const d of Config.Twins ?? []) addTwin(d);
}

export function getTwinByFluxerId(id) {
  return twins.find((t) => t.fluxerId === String(id)) ?? null;
}
export function getTwinByName(name) {
  const n = String(name ?? "").toLowerCase();
  return twins.find((t) => t.name.toLowerCase() === n) ?? null;
}

/** Add or replace the twin for a Fluxer person, and sign it in. */
export function addTwin(def) {
  // One bot per person, and one person per bot: drop any old link for either.
  for (const old of twins.filter((t) => t.fluxerId === def.fluxerId || t.token === def.token || (def.botId && t.botId === def.botId))) removeTwin(old);
  const t = { name: def.name, fluxerId: def.fluxerId, token: def.token, client: null, ready: false, tag: null, botId: def.botId ?? null, error: null };
  twins.push(t);
  start(t);
  return t;
}

export function renameTwin(t, newName) {
  t.name = newName;
}

export function removeTwin(t) {
  const i = twins.indexOf(t);
  if (i >= 0) twins.splice(i, 1);
  t.ready = false;
  t.client?.destroy?.();
}

/** Ask Discord who a bot token belongs to, without signing in. */
export async function checkDiscordToken(token) {
  const res = await fetch("https://discord.com/api/v10/users/@me", { headers: { Authorization: `Bot ${token}` }, signal: AbortSignal.timeout(8000) });
  if (!res.ok) throw new Error(res.status === 401 ? "Discord says that token doesn't work" : `Discord answered ${res.status}`);
  const u = await res.json();
  if (!u.bot) throw new Error("that token isn't for a bot");
  return { id: u.id, username: u.username };
}
