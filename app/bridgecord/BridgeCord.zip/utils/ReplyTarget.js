import { Routes as FluxerRoutes } from "@fluxerjs/core";

/** The message the owner replied to when typing a command (fetched if Fluxer didn't include it). */
export async function repliedTo(message, fluxerClient) {
  let target = message.referencedMessage ?? null;
  const ref = message.messageReference;
  if (!target && ref?.messageId) {
    target = await fluxerClient.rest
      .get(FluxerRoutes.channelMessage(ref.channelId ?? message.channelId, ref.messageId), { auth: true })
      .catch(() => null);
  }
  return target;
}
