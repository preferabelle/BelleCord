// Reads settings.txt, the one file the owner edits.
// Format: "key: value" lines. Lines starting with # are notes.
// Mirror lines: "mirror: <name> | <Discord ID or username> | <mirror bot's Fluxer token>"

import fs from "node:fs";

const FLUXER_TOKEN_RE = /^(\d{15,21})\.[A-Za-z0-9_\-]{20,}$/;
const DISCORD_TOKEN_RE = /^[A-Za-z0-9_\-]{20,}\.[A-Za-z0-9_\-]{4,}\.[A-Za-z0-9_\-]{20,}$/;
const SNOWFLAKE_RE = /^\d{15,21}$/;
// Tokens found anywhere in a line, so stray words or characters around them don't matter.
export const FLUXER_TOKEN_FIND = /\d{15,21}\.[A-Za-z0-9_\-]{20,}/;
export const DISCORD_TOKEN_FIND = /[A-Za-z0-9_\-]{20,}\.[A-Za-z0-9_\-]{4,}\.[A-Za-z0-9_\-]{20,}/;
// Invisible characters that sneak in when copying from apps and websites.
const INVISIBLE = /[\u00A0\u1680\u180E\u2000-\u200F\u2028-\u202F\u205F-\u2064\u3000\uFEFF]/g;
const clean = (v) => (v ?? "").replace(INVISIBLE, "").trim();

/** A value still containing template wording counts as "not filled in". */
function isPlaceholder(value) {
  if (!value) return true;
  const v = value.trim().toLowerCase();
  // Real tokens, IDs and usernames never contain spaces or apostrophes;
  // the template's placeholder wording always does.
  return v === "" || v === "?" || /[\s'’]/.test(v) || v.includes("paste");
}

/** The bot's ID is the part of a Fluxer bot token before the first dot. */
export function fluxerIdFromToken(token) {
  const m = FLUXER_TOKEN_RE.exec((token ?? "").trim());
  return m ? m[1] : null;
}

function yesNo(value, fallback) {
  if (value == null || value.trim() === "") return fallback;
  const v = value.trim().toLowerCase();
  if (["yes", "y", "on", "true", "1"].includes(v)) return true;
  if (["no", "n", "off", "false", "0"].includes(v)) return false;
  return fallback;
}

/**
 * @param {string} text contents of settings.txt
 */
export function parseSettings(text) {
  const out = {
    discordToken: "",
    fluxerToken: "",
    emojiCommunityId: "",
    adminIds: /** @type {string[]} */ ([]),
    extraAdmins: /** @type {{name: string, id: string}[]} */ ([]),
    ownerDiscordId: /** @type {string | null} */ (null),
    managersAreAdmins: true,
    botName: "BridgeCord",
    botBio: "",
    defaultVoice: "",
    catchUpDays: 3,
    mirrorStatuses: true,
    prefix: "b!",
    twins: /** @type {{name: string, fluxerId: string, token: string}[]} */ ([]),
    mirrors: /** @type {{name: string, discordRef: string|null, discordId: string|null, token: string, fluxerId: string}[]} */ ([]),
    problems: /** @type {string[]} */ ([]),
  };

  const lines = text.replace(/^\uFEFF/, "").split(/\r?\n/);
  for (const [i, rawLine] of lines.entries()) {
    const line = rawLine.trim();
    if (!line || line.startsWith("#")) continue;
    const colon = line.indexOf(":");
    if (colon === -1) {
      out.problems.push(`Line ${i + 1} doesn't have a colon, so it was skipped: "${line.slice(0, 40)}"`);
      continue;
    }
    const key = clean(line.slice(0, colon)).toLowerCase().replace(/\s+/g, " ");
    const value = clean(line.slice(colon + 1));

    switch (key) {
      case "discord token": {
        out.sawDiscordLine = true;
        const found = value.match(DISCORD_TOKEN_FIND)?.[0];
        if (found) { out.discordToken = found; break; }
        if (!isPlaceholder(value)) {
          if (!DISCORD_TOKEN_RE.test(value)) {
            out.problems.push("The Discord token doesn't look complete. Copy it again from your bot's page in the Discord Developer Portal.");
          }
          out.discordToken = value;
        }
        break;
      }
      case "fluxer token": {
        out.sawFluxerLine = true;
        const found = value.match(FLUXER_TOKEN_FIND)?.[0];
        if (found) { out.fluxerToken = found; break; }
        if (!isPlaceholder(value)) {
          if (!fluxerIdFromToken(value)) {
            out.problems.push("The bridge's Fluxer token doesn't look complete. Copy it again from Fluxer.");
          }
          out.fluxerToken = value;
        }
        break;
      }
      case "emoji community id":
        if (!isPlaceholder(value)) {
          if (!SNOWFLAKE_RE.test(value)) {
            out.problems.push("The emoji community ID should be only numbers. Type bb!id in that community to get it.");
          } else out.emojiCommunityId = value;
        }
        break;
      case "admin": {
        // "admin: name | 1234567890123456789" (a Fluxer or Discord user ID) -> admin commands
        const id = value.match(/\d{15,21}/)?.[0];
        if (id) out.extraAdmins.push({ name: clean(value.split("|")[0]) || id, id });
        break;
      }
      case "owner fluxer id":
      case "your fluxer id": // older name
        for (const id of value.split(/[,\s]+/)) {
          if (SNOWFLAKE_RE.test(id)) out.adminIds.push(id);
        }
        break;
      case "owner discord id": {
        const id = value.match(/\d{15,21}/)?.[0];
        if (id) out.ownerDiscordId = id;
        break;
      }
      case "server managers are admins":
        out.managersAreAdmins = yesNo(value, true);
        break;
      case "bot name":
        if (value) out.botName = value.slice(0, 32);
        break;
      case "bot bio":
        if (value) out.botBio = value.slice(0, 190);
        break;
      case "default voice channel":
        if (value) out.defaultVoice = value;
        break;
      case "catch up days": {
        const n = Number.parseFloat(value);
        if (Number.isFinite(n) && n >= 0) out.catchUpDays = Math.min(n, 14);
        break;
      }
      case "mirror statuses":
        out.mirrorStatuses = yesNo(value, true);
        break;
      case "twin": {
        // "twin: someone | his Fluxer ID | his Discord bot's token" -> his own bot on Discord
        const [name, fluxerId, rawToken] = value.split("|").map((x) => clean(x));
        const token = rawToken?.match(DISCORD_TOKEN_FIND)?.[0];
        if (name && SNOWFLAKE_RE.test(fluxerId ?? "") && token) out.twins.push({ name, fluxerId, token });
        else out.problems.push(`The linked bot line on line ${i + 1} is missing something. Use the account command to add these instead.`);
        break;
      }
      case "command prefix":
        if (value && !/\s/.test(value)) out.prefix = value;
        break;
      case "mirror": {
        const parts = value.split("|").map((p) => clean(p));
        const [name, ref] = parts;
        const token = parts[2]?.match(FLUXER_TOKEN_FIND)?.[0] ?? parts[2];
        if (!name || isPlaceholder(token)) {
          out.problems.push(
            `The mirror line for "${name || "?"}" doesn't have a bot token yet, so that mirror is off.`,
          );
          break;
        }
        const fluxerId = fluxerIdFromToken(token);
        if (!fluxerId) {
          out.problems.push(`The token on the mirror line for "${name}" doesn't look complete.`);
          break;
        }
        const refFilled = !isPlaceholder(ref) ? ref : null;
        out.mirrors.push({
          name,
          discordRef: refFilled,
          discordId: refFilled && SNOWFLAKE_RE.test(refFilled) ? refFilled : null,
          token,
          fluxerId,
        });
        if (!refFilled) {
          out.problems.push(
            `The mirror "${name}" has no Discord ID yet. It works in practice mode; add the ID to link it to a real Discord person.`,
          );
        }
        break;
      }
      default:
        out.problems.push(`Unknown setting "${key}" on line ${i + 1} was ignored.`);
    }
  }

  // Sanity checks across settings
  const mainId = fluxerIdFromToken(out.fluxerToken);
  const seen = new Set();
  out.mirrors = out.mirrors.filter((m) => {
    if (m.fluxerId === mainId) {
      out.problems.push(`The mirror "${m.name}" uses the bridge's own token. Each mirror needs its own bot.`);
      return false;
    }
    if (seen.has(m.fluxerId)) {
      out.problems.push(`Two mirror lines use the same bot token; only the first ("${m.name}" or earlier) is used.`);
      return false;
    }
    seen.add(m.fluxerId);
    return true;
  });

  return out;
}

export function loadSettings(filePath) {
  if (!fs.existsSync(filePath)) {
    return {
      ...parseSettings(""),
      missingFile: true,
    };
  }
  return { ...parseSettings(fs.readFileSync(filePath, "utf-8")), missingFile: false };
}
