// catch-up after downtime.
//
// When the bridge starts, it looks at each bridged channel on both sides for
// messages newer than the last one it handled, and bridges them in order.
// Only channels that were already bridged before are caught up, and only
// messages from the last few days (settings.txt: "catch up days").

import { botSend, isBotHook } from "./BotOnDiscord.js";
import { ChannelMap, MessageMap } from "../db/index.js";
import Config from "./ConfigHandler.js";
import { log } from "./Logger.js";
import { isMirrorFluxerId } from "./Mirrors.js";
import { DiscordCreateMessageHandler } from "./DiscordHandler.js";
import { FluxerCreateMessageHandler } from "./FluxerHandler.js";

const PAGE = 100;
const MAX_PAGES = 5; // up to 500 missed messages per channel per side
const GAP_MS = 700; // pace sends so neither platform rate-limits us

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

/** Largest snowflake in a list (snowflakes grow over time). */
export function maxSnowflake(ids) {
  let best = null;
  for (const id of ids) {
    if (!id || !/^\d+$/.test(id)) continue;
    if (best === null || BigInt(id) > BigInt(best)) best = id;
  }
  return best;
}

function timeOf(msg) {
  return (
    msg.createdTimestamp ??
    (msg.createdAt instanceof Date ? msg.createdAt.getTime() : Date.parse(msg.createdAt ?? "")) ??
    0
  );
}

/** Fetch every message after `afterId`, oldest first, across a few pages. */
async function fetchAfter(channel, afterId) {
  const all = [];
  let cursor = afterId;
  for (let page = 0; page < MAX_PAGES; page++) {
    const batch = await channel.messages.fetch({ after: cursor, limit: PAGE });
    const list = [...batch.values()];
    if (list.length === 0) break;
    all.push(...list);
    cursor = maxSnowflake(list.map((m) => m.id));
    if (list.length < PAGE) break;
  }
  const seen = new Set();
  return all
    .filter((m) => (seen.has(m.id) ? false : (seen.add(m.id), true)))
    .sort((a, b) => (BigInt(a.id) < BigInt(b.id) ? -1 : 1));
}

/**
 * Decide which fetched messages still need bridging. Kept separate so it can be tested.
 * @param {any[]} messages
 * @param {{ known: Set<string>, cutoff: number, selfId?: string, webhookId?: string, skipAuthor?: (id: string) => boolean }} opts
 */
export function pickMissed(messages, { known, cutoff, selfId, webhookId, skipAuthor }) {
  return messages.filter((m) => {
    if (known.has(m.id)) return false;
    if (timeOf(m) < cutoff) return false;
    if (selfId && m.author?.id === selfId) return false;
    if (webhookId && m.webhookId && m.webhookId === webhookId) return false;
    if (m.webhookId && isBotHook(m.webhookId)) return false; // the bot's own posts are already on Fluxer
    if (skipAuthor && skipAuthor(m.author?.id)) return false;
    return true;
  });
}

async function catchUpChannel(map, cutoff, discordClient, fluxerClient) {
  const rows = await MessageMap.findAll({
    where: { channelMapId: map.id },
    attributes: ["discordMessageId", "fluxerMessageId"],
    raw: true,
  });
  if (rows.length === 0) return 0; // never bridged anything here yet
  const known = new Set(rows.flatMap((r) => [r.discordMessageId, r.fluxerMessageId]));
  const lastDiscord = maxSnowflake(rows.map((r) => r.discordMessageId));
  const lastFluxer = maxSnowflake(rows.map((r) => r.fluxerMessageId));

  let total = 0;

  // Discord → Fluxer
  if (map.bridgeType !== "fluxer2discord" && lastDiscord) {
    const dChannel = await discordClient.channels.fetch(map.discordChannelId);
    if (dChannel?.isTextBased?.()) {
      const missed = pickMissed(await fetchAfter(dChannel, lastDiscord), {
        known,
        cutoff,
        selfId: discordClient.user?.id,
        webhookId: map.discordWebhookId,
      });
      if (missed.length) {
        const fChannel = await fluxerClient.channels.fetch(map.fluxerChannelId);
        await fChannel
          ?.send({ content: `-# I was offline, so here ${missed.length === 1 ? "is the 1 message" : `are the ${missed.length} messages`} you sent on Discord meanwhile.` })
          .catch(() => {});
        for (const msg of missed) {
          try {
            await DiscordCreateMessageHandler(msg, discordClient, fluxerClient, true);
            total++;
          } catch (e) {
            log("CATCHUP", `Couldn't catch up Discord message ${msg.id}: ${e?.message ?? e}`);
          }
          await sleep(GAP_MS);
        }
      }
    }
  }

  // Fluxer → Discord
  if (map.bridgeType !== "discord2fluxer" && lastFluxer) {
    const fChannel = await fluxerClient.channels.fetch(map.fluxerChannelId);
    if (fChannel?.messages) {
      const missed = pickMissed(await fetchAfter(fChannel, lastFluxer), {
        known,
        cutoff,
        selfId: fluxerClient.user?.id,
        webhookId: map.fluxerWebhookId,
        skipAuthor: isMirrorFluxerId,
      });
      if (missed.length) {
        const dChannel = await discordClient.channels.fetch(map.discordChannelId);
        if (dChannel?.isSendable?.()) {
          await botSend(dChannel, `-# I was offline, so here ${missed.length === 1 ? "is the 1 message" : `are the ${missed.length} messages`} you sent on Fluxer meanwhile.`).catch(() => {});
        }
        for (const msg of missed) {
          try {
            await FluxerCreateMessageHandler(msg, fluxerClient, discordClient, map.fluxerGuildId);
            total++;
          } catch (e) {
            log("CATCHUP", `Couldn't catch up Fluxer message ${msg.id}: ${e?.message ?? e}`);
          }
          await sleep(GAP_MS);
        }
      }
    }
  }

  return total;
}

export async function runCatchUp(discordClient, fluxerClient) {
  const days = Number(Config.CatchUpDays) || 0;
  if (days <= 0) return;
  const cutoff = Date.now() - days * 24 * 60 * 60 * 1000;
  const maps = await ChannelMap.findAll({ raw: true });
  let total = 0;
  for (const map of maps) {
    try {
      total += await catchUpChannel(map, cutoff, discordClient, fluxerClient);
    } catch (e) {
      log("CATCHUP", `Skipped catch-up for one channel: ${e?.message ?? e}`);
    }
  }
  if (total > 0) log("CATCHUP", `Caught up on ${total} message${total === 1 ? "" : "s"}.`);
}
