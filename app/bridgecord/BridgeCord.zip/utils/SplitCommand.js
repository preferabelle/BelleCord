/**
 * split a command message into words, letting a space follow the
 * prefix ("bb! keep" works the same as "bb!keep").
 * @param {string | null | undefined} content
 * @param {string} prefix
 * @returns {string[]}
 */
export function splitCommand(content, prefix) {
  let text = (content ?? "").trim();
  if (text.startsWith(prefix)) text = prefix + text.slice(prefix.length).trimStart();
  return text.split(/\s+/);
}
