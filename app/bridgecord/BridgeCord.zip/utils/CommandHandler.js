import { accessNeeded, allowed } from "./Access.js";
import { voiceLine } from "./Output.js";
import { splitCommand } from "./SplitCommand.js";
import { moodifyReply } from "./Output.js";
import { forPlatform, skinOn, skinKeyOn } from "./Output.js";
import { keyOf, nameOf } from "./People.js";
import { botReply } from "./BotOnDiscord.js";
import { ChannelMap, MessageMap } from "../db/index.js";
import { Routes as FluxerRoutesForEcho } from "@fluxerjs/core";
import { Message as FluxerMessageClass } from "@fluxerjs/core";
import { Message as FluxerMessage, EmbedBuilder } from "@fluxerjs/core";
import Config from "../utils/ConfigHandler.js";
import fs from "node:fs";
import ExpiryMap from "expiry-map";
import { checkManageServerPerms } from "./CheckManageServerPerms.js";
import { getGuildPrefix } from "./GetGuildPrefix.js";
import { log } from "./Logger.js";
import { sanitizePings } from "./SanitizePings.js";

export let BridgeMap = new ExpiryMap(120000);
/**
 * @type {ExpiryMap<string, {
 *  guildId: string,
 *  channelId: string,
 *  isFluxer: boolean,
 *  isVoice: boolean,
 *  direction: "f2d" | "d2f" | "both"
 * }>}
 */
export let PendingSetup = new ExpiryMap(300000);

/**
 * @returns {Promise<import('./CommandSchema.d.ts').CommandSchema[]>}
 */
// Spam limit for everyone but the owner and admins: one command every 4 s, at most 4 in 20 s.
const spam = new Map();
export function spamCheck(key, now = Date.now()) {
  const rec = spam.get(key) ?? { times: [], warnedAt: -Infinity };
  rec.times = rec.times.filter((t) => now - t < 20_000);
  spam.set(key, rec);
  const tooFast = rec.times.length > 0 && now - rec.times[rec.times.length - 1] < 4_000;
  const tooMany = rec.times.length >= 4;
  if (tooFast || tooMany) {
    if (now - rec.warnedAt > 20_000) {
      rec.warnedAt = now;
      return "warn";
    }
    return "ignore";
  }
  rec.times.push(now);
  return "ok";
}

/** Post the bot's answer to a Discord person's command on Fluxer too, replying to the bridged copy. */
async function echoToFluxer(message, x, fluxerClient) {
  if (!fluxerClient?.rest) return;
  const map = await ChannelMap.findOne({ where: { discordChannelId: message.channelId }, raw: true });
  if (!map) return;
  // Let the command itself cross the bridge first, so the answer can reply to it.
  let row = null;
  for (let i = 0; i < 10 && !row; i++) {
    await new Promise((r) => setTimeout(r, 500));
    row = await MessageMap.findOne({ where: { discordMessageId: message.id }, raw: true });
  }
  const body = typeof x === "string" ? { content: x } : { content: x?.content, embeds: x?.embeds?.map((e) => e?.toJSON?.() ?? e?.data ?? e) };
  if (!body.content && !body.embeds?.length) return;
  // If the command didn't cross (it had a token, or bridging is off), say who asked what.
  if (!row) {
    const who = message.member?.displayName ?? message.author?.globalName ?? message.author?.username ?? "someone";
    const typed = /bridge\b/i.test(message.content ?? "") ? "a bridge command" : `\`${String(message.content ?? "").slice(0, 120)}\``;
    body.content = `-# ${who} used ${typed} on Discord\n${body.content ?? ""}`;
  }
  if (row?.fluxerMessageId) body.message_reference = { message_id: row.fluxerMessageId, channel_id: map.fluxerChannelId };
  body.allowed_mentions = { parse: [] };
  await fluxerClient.rest.post(FluxerRoutesForEcho.channelMessages(map.fluxerChannelId), { body, auth: true });
}

// Fluxcord's own setup/admin/joke commands, retired. An update can't delete
// files in older installs, so they're skipped by name even if the old files are still there.
const RETIRED = new Set([
  "setup.js", "setupall.js", "verify.js", "probe.js", "prefix.js", "seterrorlogging.js",
  "seterrorreaction.js", "toggletyping.js", "bridgelist.js", "backfill.js", "meow.js", "rawr.js", "waf.js", "keep.js", "muted.js", "website.js", "blackjack.js",
]);

export async function getCommands() {
  const entries = fs.readdirSync("./commands", {
    recursive: true,
  });
  return Promise.all(
    entries
      .map(String)
      .filter((x) => x.endsWith(".js") && !RETIRED.has(x.split(/[\\/]/).pop()) && fs.statSync("./commands/" + x).isFile())
      .flatMap(async (x) => (await import("../commands/" + x)).default),
  );
}

/**
 * @param {import("@fluxerjs/core").Message | import("discord.js").OmitPartialGroupDMChannel<import("discord.js").Message<boolean>>} message
 * @param {DiscordClient} discordClient
 * @param {FluxerClient} fluxerClient
 */
export async function CommandHandler(message, discordClient, fluxerClient) {
  if (message.author.bot || message.webhookId) return;
  // Everything it says back goes to the side it was typed on.
  return forPlatform(message instanceof FluxerMessageClass ? "fluxer" : "discord", () => runCommand(message, discordClient, fluxerClient));
}

async function runCommand(message, discordClient, fluxerClient) {

  const guildPrefix = await getGuildPrefix(message.guildId ?? "");
  // "bb! keep" works the same as "bb!keep".
  const cmdList = splitCommand(message.content, guildPrefix);
  const command = cmdList[0]?.startsWith(guildPrefix)
    ? cmdList[0].slice(guildPrefix.length)
    : cmdList[0]?.replace(Config.BotPrefix, "");
  const commands = await getCommands();
  let commandToRun = commands.find(
    (x) => x.name === command || x.aliases?.find((y) => y === command),
  );

  // On Discord the bot answers through its webhook,
  // and the same answer shows up on Fluxer, so both sides see it.
  if (!(message instanceof FluxerMessageClass) && message.guildId && message.channel) {
    message.reply = async (x) => {
      const sent = await botReply(message, x);
      echoToFluxer(message, x, fluxerClient).catch(() => {});
      return sent;
    };
  }

  // Central place where every reply passes (formatting hooks).
  {
    const sober = message.reply.bind(message);
    message.reply = (x) => sober(moodifyReply(x));
  }

  // No spamming (the owner and admins are exempt).
  if (!Config.AdminAccountIds.includes(message.author.id)) {
    const verdict = spamCheck(`${message instanceof FluxerMessageClass ? "f" : "d"}:${message.author.id}`);
    if (verdict === "warn") {
      await message.reply("Slow down a little. Please wait a few seconds between commands.");
      return;
    }
    if (verdict === "ignore") return;
  }

  let isGrouped = false;

  if (!commandToRun) {
    // check if it's a group command
    const commandGroup = commands.filter((x) =>
      x.groupNames?.find((y) => y === command),
    );

    if (commandGroup.length > 0) {
      const command = cmdList[1];
      commandToRun = commands.find(
        (x) => x.name === command || x.aliases?.find((y) => y === command),
      );
      isGrouped = true;
    } else {
      await message.reply({
        embeds: [
          {
            description: `\`${guildPrefix + command}\` isn't a command. Try \`${guildPrefix}help\`.`,
            color: 0xef0000,
          },
        ],
        allowedMentions: {
          roles: [],
          users: [],
          repliedUser: true,
        },
      });
      return;
    }
  }

  const params = cmdList.slice(isGrouped ? 2 : 1);

  // Owner / admin / everyone.
  if (commandToRun && !(await allowed(message, commandToRun))) {
    await message.reply(accessNeeded(commandToRun) === "owner" ? "Only the bot's owner can use this command." : "Only admins can use this command.");
    return;
  }



  try {
    await commandToRun?.run(params, message, discordClient, fluxerClient);
  } catch (e) {
    log("DEBUG", e);
    try {
      await message.reply({
        // @ts-expect-error
        embeds: [
          new EmbedBuilder()
            .setTitle("A error has occurred while executing this command!")
            .setDescription(
              "Copy this message if you need help fixing it.",
            )
            .addFields({
              name: "Stack trace",
              value: `${e}`,
            }),
        ],
      });
    } catch (replyError) {
      log("META", "Failed to reply with the command error:", replyError);
    }
  }
}
