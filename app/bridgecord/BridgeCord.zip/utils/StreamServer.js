// where BelleCord asks for stream connections (StreamBridge.js does the work).
//  * On this computer: BelleCord's "Your bridge bot" runs the bridge and reads data/stream.json (the port, and a
//    key made fresh at every start), so it works with nothing to set up. It only listens on this computer then.
//  * Friends on other computers: only with a "stream address" in settings.txt, an address that reaches the stream
//    port here (a tunnel like ngrok or Cloudflare Tunnel, or a forwarded port). Each person gets their own key from
//    the stream command on Discord (the bot DMs it, so it's really them). A key only works for that Discord account,
//    and only while they're in the bridged call.
import crypto from "node:crypto";
import fs from "node:fs";
import http from "node:http";
import path from "node:path";
import Config from "./ConfigHandler.js";
import { log } from "./Logger.js";
import { streamClose, streamInfo, streamOpen, streamPing } from "./StreamBridge.js";

const HERE = path.join(Config.DataFolderPath, "stream.json"); // { port, key, address } for BelleCord on this computer
const FRIENDS = path.join(Config.DataFolderPath, "stream-friends.json"); // discordUserId -> { hash, at }

const hash = (k) => crypto.createHash("sha256").update(String(k)).digest("hex");
const same = (a, b) => {
  const x = Buffer.from(String(a)), y = Buffer.from(String(b));
  return x.length === y.length && crypto.timingSafeEqual(x, y);
};
let ownerKey = null;
let server = null;
let friends = {};
try { friends = JSON.parse(fs.readFileSync(FRIENDS, "utf-8")) || {}; } catch {}
const saveFriends = () => { try { fs.mkdirSync(path.dirname(FRIENDS), { recursive: true }); fs.writeFileSync(FRIENDS, JSON.stringify(friends)); } catch {} };

/** A key for one Discord person (the stream command). A new one replaces the old one. */
export function newFriendKey(discordUserId) {
  const key = crypto.randomBytes(24).toString("base64url");
  friends[String(discordUserId)] = { hash: hash(key), at: Date.now() };
  saveFriends();
  return key;
}
export function dropFriendKey(discordUserId) {
  const had = !!friends[String(discordUserId)];
  delete friends[String(discordUserId)];
  saveFriends();
  return had;
}
/** The link the stream command DMs (the key is after the #, so it's never sent to any server, this one included). */
export function friendLink(key) {
  if (!Config.StreamAddress) return null;
  return `${Config.StreamAddress}/bellecord/link#k=${key}&n=${encodeURIComponent(Config.BotName || "BridgeCord")}`;
}
export const streamsOn = () => Config.Streams !== false;

function whoIs(key, body) {
  if (typeof key !== "string" || !key) return null;
  if (ownerKey && same(key, ownerKey)) {
    // (BelleCord on this computer says which Discord account it has open)
    const id = String(body?.discordUserId ?? "");
    return /^\d{15,21}$/.test(id) ? { id, here: true } : null;
  }
  const h = hash(key);
  for (const [id, f] of Object.entries(friends)) if (f?.hash && same(h, f.hash)) return { id, here: false };
  return null;
}

// (40 asks a minute from one address is plenty: BelleCord asks every 15 seconds)
const asks = new Map();
function tooMany(ip) {
  const now = Date.now();
  const list = (asks.get(ip) ?? []).filter((t) => now - t < 60_000);
  list.push(now);
  asks.set(ip, list);
  if (asks.size > 500) for (const [k, v] of asks) if (!v.some((t) => now - t < 60_000)) asks.delete(k);
  return list.length > 40;
}

const LINK_PAGE = `<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Streams with BelleCord</title>
<style>body{font:16px/1.5 system-ui,sans-serif;background:#1e1f22;color:#dbdee1;display:flex;min-height:100vh;margin:0;align-items:center;justify-content:center}main{max-width:460px;padding:24px}h1{font-size:20px;color:#fff}</style></head>
<body><main><h1>This link is for BelleCord</h1><p>Open it in BelleCord (click it in Discord inside BelleCord) and streams in this bridged call cross between Fluxer and Discord for you: going live on Discord shows on Fluxer too, and Fluxer streams get a Watch button.</p><p>Keep it to yourself. It works for your Discord account only.</p></main></body></html>`;

function send(res, code, data) {
  res.writeHead(code, { "content-type": "application/json", "cache-control": "no-store" });
  res.end(JSON.stringify(data));
}

function readBody(req, max = 10_000) {
  return new Promise((ok) => {
    let n = 0, chunks = [];
    req.on("data", (c) => { n += c.length; if (n > max) { req.destroy(); ok(null); } else chunks.push(c); });
    req.on("end", () => { try { ok(JSON.parse(Buffer.concat(chunks).toString("utf-8") || "{}")); } catch { ok(null); } });
    req.on("error", () => ok(null));
  });
}

async function handle(req, res) {
  const url = (req.url || "/").split("?")[0];
  const ip = req.socket?.remoteAddress ?? "?";
  if (req.method === "GET" && url === "/bellecord/link") {
    res.writeHead(200, { "content-type": "text/html; charset=utf-8", "cache-control": "no-store" });
    return res.end(LINK_PAGE);
  }
  if (req.method === "GET" && url === "/v1/hello") return send(res, 200, { ok: true, kind: "bridgecord", name: Config.BotName || "BridgeCord", streams: 1 });
  if (req.method !== "POST" || url !== "/v1/stream") return send(res, 404, { error: "not found" });
  if (tooMany(ip)) return send(res, 429, { error: "slow down" });
  const b = await readBody(req);
  if (!b) return send(res, 400, { error: "bad request" });
  const who = whoIs(b.key, b);
  if (!who) return send(res, 401, { error: "key", why: "That link doesn't work any more. Type the stream command on Discord for a new one." });
  const op = String(b.op ?? "");
  const short = (v, n) => (typeof v === "string" ? v.slice(0, n) : "");
  try {
    if (op === "info") return send(res, 200, streamInfo({ discordUserId: who.id }));
    if (op === "open") return send(res, 200, await streamOpen({ discordUserId: who.id, purpose: short(b.purpose, 10), identity: short(b.identity, 200) }));
    if (op === "close") return send(res, 200, streamClose({ discordUserId: who.id, connectionId: short(b.connectionId, 200) }));
    if (op === "ping") return send(res, 200, streamPing({ discordUserId: who.id, connectionId: short(b.connectionId, 200) }));
    return send(res, 400, { error: "bad request" });
  } catch (e) {
    return send(res, 400, { error: String(e?.message ?? e) });
  }
}

/** Start listening (once). On this computer only, unless settings.txt has a stream address. */
export function startStreamServer() {
  if (server || !streamsOn()) return null;
  ownerKey = crypto.randomBytes(24).toString("base64url");
  const everywhere = !!Config.StreamAddress;
  server = http.createServer((req, res) => {
    handle(req, res).catch(() => { try { send(res, 500, { error: "something went wrong" }); } catch {} });
  });
  server.on("error", (e) => {
    log("META", e?.code === "EADDRINUSE"
      ? `Streams with BelleCord are off: port ${Config.StreamPort} is already in use. Pick another "stream port" in settings.txt.`
      : `Streams with BelleCord are off: ${e?.message ?? e}`);
    server = null;
  });
  server.listen(Config.StreamPort || 0, everywhere ? "0.0.0.0" : "127.0.0.1", () => {
    const port = server.address().port;
    try {
      fs.mkdirSync(path.dirname(HERE), { recursive: true });
      fs.writeFileSync(HERE, JSON.stringify({ port, key: ownerKey, address: Config.StreamAddress || null }), { mode: 0o600 });
    } catch {}
    log("META", everywhere
      ? `Streams with BelleCord: on, for this computer and for friends at ${Config.StreamAddress} (port ${port}).`
      : "Streams with BelleCord: on, for BelleCord on this computer.");
  });
  // (BelleCord shouldn't find an old port after the bridge stops)
  process.once("exit", () => { try { fs.rmSync(HERE, { force: true }); } catch {} });
  return server;
}
