// Message formatting hooks: every reply passes through here.
// The bot speaks in one neutral voice. The one change made here: commands are written as `bb!…`
// in the code, and get shown with whatever "command prefix" is set in settings.txt.
import Config from "./ConfigHandler.js";

const withPrefix = (text) => (typeof text === "string" && Config.BotPrefix !== "bb!" ? text.replaceAll("bb!", Config.BotPrefix) : text);

export const moodify = (text) => withPrefix(text);

/** A reply (text, or a message with content and cards) with the right prefix everywhere. */
export function moodifyReply(reply) {
  if (typeof reply === "string") return withPrefix(reply);
  if (!reply || typeof reply !== "object") return reply;
  const out = { ...reply };
  if (typeof out.content === "string") out.content = withPrefix(out.content);
  if (Array.isArray(out.embeds)) {
    out.embeds = out.embeds.map((e) => {
      const d = { ...(e?.toJSON?.() ?? e?.data ?? e) };
      for (const k of ["title", "description"]) if (d[k]) d[k] = withPrefix(d[k]);
      if (d.footer?.text) d.footer = { ...d.footer, text: withPrefix(d.footer.text) };
      if (Array.isArray(d.fields)) d.fields = d.fields.map((f) => ({ ...f, name: withPrefix(f.name), value: withPrefix(f.value) }));
      return d;
    });
  }
  return out;
}

export const forPlatform = (_platform, fn) => fn();
export const reaction = () => null;
export const skinLine = () => null;
export const currentSkin = () => null;
export const skinOn = () => null;
export const skinKeyOn = () => null;
export const currentSkinPicture = () => null;
export const personaOf = () => "default";
export const withPersonaTag = (reply) => reply;
/** A fixed line with {placeholders} filled in. */
export function voiceLine(_key, line, vars = {}) {
  let out = withPrefix(line);
  for (const [k, v] of Object.entries(vars)) out = out.replaceAll(`{${k}}`, v);
  return out;
}
