// Voice connects securely, and the voice part checks those connections against the system's list
// of trusted certificates. Some systems (slim Docker images, very bare Linux installs) don't have
// that list. Node.js carries its own, so if the system has none, hand Node's list to the voice part.
import fs from "node:fs";
import path from "node:path";
import tls from "node:tls";
import Config from "./ConfigHandler.js";
import { log } from "./Logger.js";

const SYSTEM_BUNDLES = [
  "/etc/ssl/certs/ca-certificates.crt",
  "/etc/pki/tls/certs/ca-bundle.crt",
  "/etc/pki/ca-trust/extracted/pem/tls-ca-bundle.pem",
  "/etc/ssl/ca-bundle.pem",
  "/etc/ssl/cert.pem",
  "/etc/pki/tls/cacert.pem",
];

export function ensureCertificates(bundles = SYSTEM_BUNDLES) {
  if (process.platform !== "linux") return null; // Windows and Mac always have their own
  if (process.env.SSL_CERT_FILE && fs.existsSync(process.env.SSL_CERT_FILE)) return process.env.SSL_CERT_FILE;
  if (bundles.some((f) => fs.existsSync(f))) return null; // the system has them
  try {
    const file = path.join(Config.DataFolderPath, "ca-certificates.pem");
    fs.mkdirSync(path.dirname(file), { recursive: true });
    fs.writeFileSync(file, tls.rootCertificates.join("\n"));
    process.env.SSL_CERT_FILE = file;
    log("META", "This system has no security certificates installed, so voice uses Node.js's own list.");
    return file;
  } catch (e) {
    log("META", `Couldn't set up security certificates for voice (${e?.message ?? e}).`);
    return null;
  }
}
