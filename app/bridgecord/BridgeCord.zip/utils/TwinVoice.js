// personal Discord bots in voice.
// While the voice bridge is on, a Fluxer person who joins the bridged Fluxer call gets their
// personal Discord bot (their "twin") joined to the bridged Discord call, speaking their voice.
// So on Discord they get their own speaking light and their own volume slider. It leaves
// when they leave. (the owner's own voice already comes from the Discord bot.)
import { Readable } from "node:stream";
import {
  AudioPlayerStatus,
  NoSubscriberBehavior,
  StreamType,
  VoiceConnectionStatus,
  createAudioPlayer,
  createAudioResource,
  entersState,
  joinVoiceChannel,
} from "@discordjs/voice";
import { log } from "./Logger.js";
import { FRAME_SAMPLES, Mixer } from "./AudioMixer.js";
import { getTwinByFluxerId, twins } from "./Twins.js";

/** Swappable for tests. */
export const deps = { join: joinVoiceChannel };

const FRAME_BYTES = FRAME_SAMPLES * 2;
const SILENT = Buffer.alloc(FRAME_BYTES);
/** @type {Map<string, any>} Fluxer user id -> seat */
export const seats = new Map();
/** @type {{guildId: string, channelId: string, name: string} | null} the bridged Discord voice channel */
let target = null;
const warned = new Set();

export function setTwinVoiceTarget(t) {
  target = t ?? null;
  if (!target) leaveAllTwins();
}

/** Is this Discord account one of the personal bots? (never relay their audio back) */
export function isTwinBot(discordUserId) {
  return twins.some((t) => t.client?.user?.id === discordUserId || t.botId === discordUserId);
}

/** A steady audio stream for one bot (same cushion and pause handling as the Discord bot). */
function makeOutput(seat) {
  seat.out = new Readable({ read() {} });
  seat.queue = [];
  seat.playing = false;
  seat.lastReal = 0;
  seat.player = createAudioPlayer({ behaviors: { noSubscriber: NoSubscriberBehavior.Play, maxMissedFrames: 250 } });
  seat.player.on("error", () => {});
  seat.player.play(createAudioResource(seat.out, { inputType: StreamType.Raw }));
  seat.mixer = new Mixer((frame) => {
    const buf = Buffer.from(frame.buffer, frame.byteOffset, frame.byteLength);
    seat.lastReal = Date.now();
    if (!seat.playing) {
      seat.queue.push(buf);
      if (seat.queue.length >= 5) {
        // After a quiet spell the player may have stopped for good: give it a fresh stream.
        const st = seat.player.state.status;
        if (st !== AudioPlayerStatus.Playing && st !== AudioPlayerStatus.Buffering) {
          seat.out?.destroy();
          seat.out = new Readable({ read() {} });
          seat.player.play(createAudioResource(seat.out, { inputType: StreamType.Raw }));
        }
        seat.playing = true;
        for (const b of seat.queue.splice(0)) seat.out.push(b);
      }
      return;
    }
    if (seat.out.readableLength < FRAME_BYTES * 15) seat.out.push(buf);
  }, { primeFrames: 3, graceFrames: 2 });
  seat.mixer.onSilence = () => {
    if (!seat.playing) { if (seat.queue.length) { for (const b of seat.queue.splice(0)) seat.out.push(b); seat.playing = true; } return; }
    if (Date.now() - seat.lastReal < 3000) { if (seat.out.readableLength < FRAME_BYTES * 8) seat.out.push(SILENT); }
    else seat.playing = false;
  };
  seat.mixer.start();
}

export async function twinJoin(fluxerUserId, flags = {}) {
  if (!target || seats.has(fluxerUserId)) return;
  const twin = getTwinByFluxerId(fluxerUserId);
  if (!twin?.ready) return;
  const guild = twin.client.guilds?.cache?.get(target.guildId);
  if (!guild) {
    if (!warned.has(twin.name)) { warned.add(twin.name); log("MIRROR", `${twin.name}'s Discord bot isn't in the Discord server, so it can't join voice.`); }
    return;
  }
  const seat = { twin, fluxerUserId, conn: null, tries: 0 };
  seats.set(fluxerUserId, seat);
  makeOutput(seat);
  const connect = async () => {
    if (seats.get(fluxerUserId) !== seat) return;
    const conn = deps.join({
      channelId: target.channelId,
      guildId: target.guildId,
      adapterCreator: guild.voiceAdapterCreator,
      selfMute: !!flags.mute,
      selfDeaf: !!flags.deaf,
      group: twin.client.user.id, // each bot needs its own voice connection
      daveEncryption: true,
    });
    seat.conn = conn;
    conn.subscribe?.(seat.player);
    conn.on?.(VoiceConnectionStatus.Disconnected, async () => {
      try {
        await Promise.race([entersState(conn, VoiceConnectionStatus.Signalling, 5000), entersState(conn, VoiceConnectionStatus.Connecting, 5000)]);
      } catch {
        if (seats.get(fluxerUserId) === seat && seat.tries++ < 3) { conn.destroy(); setTimeout(connect, 5000 * seat.tries); }
      }
    });
    log("MIRROR", `${twin.name}'s Discord bot joined voice (following them on Fluxer).`);
  };
  await connect().catch((e) => log("MIRROR", `${twin.name}'s Discord bot couldn't join voice: ${e?.message ?? e}`));
}

/** Their muted/deafened state on Fluxer, shown on their Discord bot. */
export function twinFlags(fluxerUserId, flags) {
  const seat = seats.get(fluxerUserId);
  if (!seat?.conn || !target) return;
  seat.conn.rejoin?.({ channelId: target.channelId, selfMute: !!flags.mute, selfDeaf: !!flags.deaf });
}

export function twinLeave(fluxerUserId) {
  const seat = seats.get(fluxerUserId);
  if (!seat) return;
  seats.delete(fluxerUserId);
  seat.mixer?.stop();
  seat.player?.stop(true);
  seat.out?.destroy();
  seat.conn?.destroy?.();
  log("MIRROR", `${seat.twin.name}'s Discord bot left voice.`);
}

export function leaveAllTwins() {
  for (const id of [...seats.keys()]) twinLeave(id);
}

/** A Fluxer person's voice: their own Discord bot speaks it, if it's in the call. */
export function sendToTwin(fluxerUserId, samples) {
  const seat = seats.get(fluxerUserId);
  if (!seat?.conn || seat.conn.state?.status !== VoiceConnectionStatus.Ready) return false;
  seat.mixer.push("voice", samples);
  return true;
}

export function twinVoiceStatus() {
  return [...seats.values()].map((s) => `${s.twin.name}${s.conn?.state?.status === VoiceConnectionStatus.Ready ? "" : " (joining)"}`);
}
