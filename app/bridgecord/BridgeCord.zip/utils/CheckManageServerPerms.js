import { PermissionFlagsBits } from "discord.js";
import { Client, PermissionFlags } from "@fluxerjs/core";
import DefaultConfig from "./ConfigHandler.js";

/**
 * Can this person manage things?
 *   - Bridge admins (the owner and anyone added with bb!admin) always can, even in DMs.
 *   - On Fluxer: the community owner, or anyone with Administrator or Manage Community.
 *     Roles are fetched fresh from Fluxer (the toolkit only counts roles it happened to
 *     have loaded, which made real admins look like nobodies). In a DM, any of the owner's
 *     communities counts.
 *   - On Discord: Manage Server in that server.
 * @param {string} guildId
 * @param {string} userId
 * @param {import('@fluxerjs/core').Client | import('discord.js').Client} client
 */
export async function checkManageServerPerms(guildId, userId, client) {
  if (DefaultConfig.AdminAccountIds.includes(userId)) return true;
  if (client instanceof Client) {
    const ids = guildId ? [guildId] : [...(client.guilds?.keys?.() ?? [])];
    for (const id of ids) {
      if (await fluxerManages(client, id, userId)) return true;
    }
    return false;
  }
  if (!guildId || !client?.guilds?.fetch) return false;
  const guild = await client.guilds.fetch(guildId).catch(() => null);
  const member = await guild?.members?.fetch(userId).catch(() => null);
  return !!member?.permissions?.has(PermissionFlagsBits.ManageGuild);
}

async function fluxerManages(client, guildId, userId) {
  const guild = await client.guilds?.fetch?.(guildId).catch(() => null);
  if (guild?.ownerId && String(guild.ownerId) === String(userId)) return true;
  const member = await client.rest.get(`/guilds/${guildId}/members/${userId}`, { auth: true }).catch(() => null);
  if (!member) return false;
  const roles = await client.rest.get(`/guilds/${guildId}/roles`, { auth: true }).catch(() => null);
  let bits = 0n;
  if (Array.isArray(roles)) {
    const byId = new Map(roles.map((r) => [String(r.id), BigInt(r.permissions ?? 0)]));
    bits |= byId.get(String(guildId)) ?? 0n; // @everyone
    for (const id of member.roles ?? []) bits |= byId.get(String(id)) ?? 0n;
  } else {
    // Couldn't list roles: fall back to the toolkit's own calculation.
    const m = await guild?.fetchMember?.(userId).catch(() => null);
    bits = m?.permissions?.bitfield ?? 0n;
  }
  const want = (flag) => (bits & BigInt(flag)) === BigInt(flag);
  return want(PermissionFlags.Administrator) || want(PermissionFlags.ManageGuild);
}

/**
 * @param {string} guildId
 * @param {string} userId
 * @param {import('@fluxerjs/core').Client | import('discord.js').Client} client
 */
export async function checkPingPerms(guildId, userId, client) {
  if (!userId) return;

  let guild;
  try {
    guild = await client.guilds.fetch(guildId);
  } catch {
    return false;
  }
  if (!guild) return false;

  let member;
  try {
    member =
      client instanceof Client
        ? await guild.fetchMember(userId)
        : await guild.members.fetch(userId);
  } catch {
    return false;
  }

  if (!member) return false;

  return member.permissions.has(
    client instanceof Client
      ? PermissionFlags.MentionEveryone
      : PermissionFlagsBits.MentionEveryone,
  );
}
