// shared runner for "do something to a Discord member" commands.
import { resolvePerson, discordMembers } from "./WhoIs.js";
import { hierarchyProblem } from "./DiscordControl.js";

/**
 * Resolve who's meant (name, mirror, @mention, or reply), then run `act(member)` in every
 * Discord server they're in. Reports what worked and exactly why anything didn't.
 */
export async function onMember(message, words, discordClient, fluxerClient, act, { verb, failVerb, check = true } = {}) {
  if (!discordClient?.isReady?.()) return void (await message.reply("I'm not connected to Discord right now."));
  const who = await resolvePerson(message, words, discordClient, fluxerClient);
  if (!who || who.side !== "discord") return void (await message.reply(`Who on Discord? Use their Discord name, a mirror's name, or reply to their message.`));
  const members = await discordMembers(discordClient, who.id);
  if (!members.length) return void (await message.reply(`${who.name} isn't in any Discord server with me. `));
  const done = [], failed = [];
  for (const m of members) {
    const problem = check ? hierarchyProblem(m) : null;
    if (problem) { failed.push(`${m.guild.name}: ${problem}`); continue; }
    try { const note = await act(m); done.push(typeof note === "string" && note ? `${m.guild.name} (${note})` : m.guild.name); }
    catch (e) { failed.push(`${m.guild.name}: Discord said "${e?.message ?? e}".`); }
  }
  const lines = [];
  if (done.length) lines.push(`Done: ${verb} **${who.name}** in ${done.join(", ")}.`);
  if (failed.length) lines.push(`Couldn't ${failVerb ?? "do that"}. ${failed.join("\n")}`);
  await message.reply(lines.join("\n"));
}
