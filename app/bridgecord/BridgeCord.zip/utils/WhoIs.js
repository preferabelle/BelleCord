// figure out who a command means, on either side.
//   a Fluxer @mention, a reply, a mirror's name, or a Discord username/display name.
// Returns { side: "discord", id, name, mirror? } or { side: "fluxer", id, name } or null.
import { getMirrorByDiscordId, getMirrorByName, mirrors } from "./Mirrors.js";
import { repliedTo } from "./ReplyTarget.js";
import { findDiscordPerson } from "../commands/bridge.js";

export async function resolvePerson(message, words, discordClient, fluxerClient) {
  const fromFluxerUser = (u) => {
    const mirror = mirrors.find((m) => m.fluxerId === u?.id);
    if (mirror?.discordId) return { side: "discord", id: mirror.discordId, name: mirror.name, mirror };
    return u?.id ? { side: "fluxer", id: u.id, name: u.globalName ?? u.global_name ?? u.username ?? u.id } : null;
  };
  // 1. an @mention on Fluxer
  const mentioned = [...(message.mentions?.values?.() ?? message.mentions ?? [])].find((u) => u?.id && u.id !== fluxerClient?.user?.id);
  if (mentioned) return fromFluxerUser(mentioned);
  // 2. a reply
  const target = message.guildId && fluxerClient ? await repliedTo(message, fluxerClient).catch(() => null) : null;
  if (target?.author) {
    if (!(target.webhookId ?? target.webhook_id)) return fromFluxerUser(target.author);
    words = [target.author.username]; // a Discord person shown through the webhook: look them up by name
  }
  const text = words.join(" ").replace(/^@/, "").trim();
  if (!text) return null;
  // 3. a mirror's name
  const mirror = getMirrorByName(text);
  if (mirror?.discordId) return { side: "discord", id: mirror.discordId, name: mirror.name, mirror };
  // 4. a Discord person
  if (discordClient?.isReady?.()) {
    const { user } = await findDiscordPerson(discordClient, text);
    if (user) return { side: "discord", id: user.id, name: user.globalName ?? user.username, mirror: getMirrorByDiscordId(user.id) };
  }
  return null;
}

/** Every Discord server the Discord bot is in where this person is a member. */
export async function discordMembers(discordClient, userId) {
  const out = [];
  for (const g of discordClient?.guilds?.cache?.values?.() ?? []) {
    const m = await g.members.fetch(userId).catch(() => null);
    if (m) out.push(m);
  }
  return out;
}
