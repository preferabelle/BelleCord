// find a Fluxer person by ID, @mention, username, display name, or nickname,
// across the communities the bridge bot is in. Tries Fluxer's member list, then what the
// bot already knows about each community's members.
const SNOWFLAKE = /^<?@?!?(\d{15,21})>?$/;

function addPerson(people, m) {
  const u = m?.user ?? m ?? {};
  if (!u.id || u.bot) return;
  const prev = people.get(u.id) ?? {};
  people.set(u.id, {
    id: u.id,
    username: u.username ?? prev.username,
    globalName: u.global_name ?? u.globalName ?? prev.globalName,
    nick: m?.nick ?? m?.nickname ?? prev.nick,
  });
}

export async function findFluxerPerson(fluxerClient, text) {
  const want = String(text ?? "").trim().replace(/^@/, "");
  if (!want) return { user: null };
  const id = want.match(SNOWFLAKE)?.[1];
  const people = new Map();
  for (const guild of fluxerClient?.guilds?.values?.() ?? []) {
    // 1. Fluxer's member list
    const list = await fluxerClient.rest.get(`/guilds/${guild.id}/members?limit=1000`, { auth: true }).catch(() => null);
    for (const m of Array.isArray(list) ? list : list?.members ?? []) addPerson(people, m);
    // 2. Members the bot has already seen in that community
    for (const m of guild.members?.values?.() ?? guild.members?.cache?.values?.() ?? []) addPerson(people, m);
  }
  if (id) return { user: people.get(id) ?? { id, username: id } };
  const lower = want.toLowerCase();
  const names = (p) => [p.username, p.globalName, p.nick].filter(Boolean).map((n) => n.toLowerCase());
  const all = [...people.values()];
  const exact = all.filter((p) => names(p).includes(lower));
  if (exact.length === 1) return { user: exact[0] };
  const partial = all.filter((p) => names(p).some((n) => n.startsWith(lower) || n.includes(lower)));
  if (exact.length === 0 && partial.length === 1) return { user: partial[0] };
  return { user: null, maybe: (exact.length ? exact : partial).slice(0, 5).map((p) => p.username ?? p.id) };
}
