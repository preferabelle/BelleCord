// The other way round from ServerSync.js: make a Fluxer server match the Discord server it's bridged to.
// Copies the Discord server's name and icon, its roles (names, colors, permissions, order, shown separately,
// mentionable), its categories, and its text and voice channels (names, topics, age-restricted, slowmode, order,
// category, user limits, role permission overrides), then bridges every text and voice channel that isn't bridged
// yet. Things already on Fluxer are matched up and updated, never duplicated: by an existing bridge, then by name,
// then by what they're for (renamed to the Discord name). Fluxer channels Discord doesn't have go to the bottom;
// "clean" deletes them and the roles Discord doesn't have (never bridged channels, link channels, or bot roles).
// Used by bb!syncserver to fluxer.
import { ChannelType, PermissionFlagsBits } from "discord.js";
import { Routes as FluxerRoutes } from "@fluxerjs/core";
import { ChannelMap, VoiceChannelMap } from "../db/index.js";
import { log } from "./Logger.js";
import fs from "node:fs";
import path from "node:path";
import Config from "./ConfigHandler.js";

const MEMO = path.join(Config.DataFolderPath, "server-sync-to-fluxer.json");
const memo = (() => { try { return JSON.parse(fs.readFileSync(MEMO, "utf-8")); } catch { return {}; } })();
const saveMemo = () => { try { fs.writeFileSync(MEMO, JSON.stringify(memo, null, 1)); } catch {} };

const norm = (n) => String(n ?? "").toLowerCase().trim().replace(/\s+/g, "-").replace(/[^\p{L}\p{N}_-]/gu, "").replace(/-+/g, "-").replace(/^-+|-+$/g, "");
const roleNorm = (n) => String(n ?? "").toLowerCase().trim();
const DISCORD_BITS = Object.values(PermissionFlagsBits).reduce((a, b) => a | BigInt(b), 0n);
// (Fluxer has a couple of permissions of its own: whatever a Fluxer role already had of those is kept)
const fluxerPerms = (discordBits, fluxerNow) => ((BigInt(fluxerNow ?? 0) & ~DISCORD_BITS) | (BigInt(discordBits ?? 0) & DISCORD_BITS));
const F_TEXT = 0, F_VOICE = 2, F_CAT = 4, F_NEWS = 5, F_LINK = 998;
const fKind = (t) => (t === F_CAT ? "category" : t === F_VOICE ? "voice" : t === F_TEXT || t === F_NEWS ? "text" : null);
const dKind = (c) => (c.type === ChannelType.GuildCategory ? "category" : c.type === ChannelType.GuildVoice || c.type === ChannelType.GuildStageVoice ? "voice" : c.type === ChannelType.GuildText || c.type === ChannelType.GuildAnnouncement ? "text" : null);
const fTypeOf = (kind) => (kind === "category" ? F_CAT : kind === "voice" ? F_VOICE : F_TEXT);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function readFluxer(F, fid) {
  const [guild, roles, channels, me] = await Promise.all([
    F.rest.get(FluxerRoutes.guild(fid), { auth: true }).catch(() => null),
    F.rest.get(FluxerRoutes.guildRoles(fid), { auth: true }).catch(() => null),
    F.rest.get(FluxerRoutes.guildChannels(fid), { auth: true }).catch(() => null),
    F.rest.get(FluxerRoutes.guildMember(fid, F.user?.id), { auth: true }).catch(() => null),
  ]);
  if (!guild || !Array.isArray(channels)) throw new Error("I couldn't read that Fluxer server. Is the bot in it?");
  const roleList = Array.isArray(roles) ? roles : guild.roles ?? [];
  const owner = String(guild.owner_id ?? "") === String(F.user?.id ?? "-");
  const myRoles = new Set((me?.roles ?? []).map(String));
  const top = owner ? Infinity : Math.max(0, ...roleList.filter((r) => myRoles.has(String(r.id))).map((r) => r.position ?? 0));
  return { guild, roles: roleList, channels, top };
}

/** What would change on the Fluxer server. Same shape as planSync's answer, plus toFluxer: true. */
export async function planSyncToFluxer(dGuild, F, fid, { clean = false, keep = [] } = {}) {
  const X = await readFluxer(F, fid);
  await dGuild.roles.fetch().catch(() => {});
  await dGuild.channels.fetch().catch(() => {});
  const steps = [], lines = [], skipped = [];
  const counts = { roles: 0, channels: 0, bridges: 0, removed: 0 };

  // ---- server name and icon
  if (dGuild.name && dGuild.name !== X.guild.name) { steps.push({ t: "guildName", name: dGuild.name }); lines.push(`Rename the Fluxer server to "${dGuild.name}"`); }
  if (dGuild.icon && (memo[fid]?.icon !== dGuild.icon || !X.guild.icon)) { steps.push({ t: "guildIcon", url: dGuild.iconURL({ extension: String(dGuild.icon).startsWith("a_") ? "gif" : "png", size: 512 }), hash: dGuild.icon }); lines.push("Use the Discord server's icon"); }

  // ---- roles (highest first)
  const dRoles = [...dGuild.roles.cache.values()].filter((r) => r.id !== dGuild.id && !r.managed).sort((a, b) => b.position - a.position);
  const fRoles = X.roles.filter((r) => r && String(r.id) !== String(fid));
  const roleFor = new Map(); // Discord role id -> Fluxer role ref
  const usedF = new Set();
  for (const dr of dRoles) {
    const f = fRoles.find((x) => !usedF.has(String(x.id)) && !x.managed && roleNorm(x.name) === roleNorm(dr.name));
    const want = { name: dr.name.slice(0, 100), color: dr.color ?? 0, hoist: !!dr.hoist, mentionable: !!dr.mentionable, perms: dr.permissions.bitfield };
    if (f) {
      usedF.add(String(f.id));
      roleFor.set(dr.id, { id: String(f.id) });
      if ((f.position ?? 0) >= X.top) { skipped.push(`role "${f.name}" (it's above the bot's own role on Fluxer)`); continue; }
      const p = fluxerPerms(want.perms, f.permissions);
      const diff = f.name !== want.name || Number(f.color ?? 0) !== want.color || !!f.hoist !== want.hoist || !!f.mentionable !== want.mentionable || BigInt(f.permissions ?? 0) !== p;
      if (diff) { steps.push({ t: "roleEdit", id: String(f.id), ...want, permissions: String(p) }); lines.push(`Update role "${want.name}"`); counts.roles++; }
    } else {
      const ref = { id: null };
      roleFor.set(dr.id, ref);
      steps.push({ t: "roleNew", ref, ...want, permissions: String(BigInt(want.perms) & DISCORD_BITS) }); lines.push(`Create role "${want.name}"`); counts.roles++;
    }
  }
  const fEveryone = X.roles.find((r) => String(r.id) === String(fid));
  if (fEveryone) {
    const p = fluxerPerms(dGuild.roles.everyone.permissions.bitfield, fEveryone.permissions);
    if (BigInt(fEveryone.permissions ?? 0) !== p) { steps.push({ t: "everyone", permissions: String(p) }); lines.push("Update @everyone's permissions"); }
  }
  steps.push({ t: "roleOrder", order: dRoles.map((r) => roleFor.get(r.id)) });
  if (clean) for (const f of fRoles) {
    if (usedF.has(String(f.id)) || f.managed || (f.position ?? 0) >= X.top) continue;
    steps.push({ t: "roleDel", id: String(f.id), name: f.name }); lines.push(`Delete role "${f.name}" (not on Discord)`); counts.removed++;
  }

  // ---- channels
  const maps = await ChannelMap.findAll({ where: { fluxerGuildId: String(fid) }, raw: true }).catch(() => []);
  const vmaps = await VoiceChannelMap.findAll({ where: { fluxerGuildId: String(fid) }, raw: true }).catch(() => []);
  const bridgedTo = new Map(); // Discord channel -> Fluxer channel
  for (const m of [...maps, ...vmaps]) if (m.fluxerChannelId && m.discordChannelId) bridgedTo.set(String(m.discordChannelId), String(m.fluxerChannelId));
  const otherServer = new Set(maps.filter((m) => String(m.discordGuildId) !== String(dGuild.id)).map((m) => String(m.fluxerChannelId)));
  const fChans = X.channels.filter((c) => fKind(c.type));
  const dChans = [...dGuild.channels.cache.values()].filter((c) => dKind(c)).sort((a, b) => (a.rawPosition ?? 0) - (b.rawPosition ?? 0));
  for (const c of dGuild.channels.cache.values()) if (c.type === ChannelType.GuildForum || c.type === ChannelType.GuildMedia) skipped.push(`#${c.name} (Fluxer doesn't have forum channels)`);
  const usedC = new Set();
  const chanFor = new Map(); // Discord channel id -> Fluxer ref
  const overwrites = (dc) => [...(dc.permissionOverwrites?.cache?.values?.() ?? [])].filter((o) => o.type === 0).map((o) => {
    const role = o.id === dGuild.id ? { id: String(fid) } : roleFor.get(o.id);
    return role ? { role, allow: o.allow.bitfield & DISCORD_BITS, deny: o.deny.bitfield & DISCORD_BITS } : null;
  }).filter(Boolean);
  const { similarPairs } = await import("./ServerSync.js");

  for (const kind of ["category", "text", "voice"]) {
    const dl = dChans.filter((c) => dKind(c) === kind);
    const match = new Map(); // Discord id -> Fluxer channel
    const free = (x) => !usedC.has(String(x.id)) && !otherServer.has(String(x.id)) && fKind(x.type) === kind;
    for (const dc of dl) {
      const via = bridgedTo.get(dc.id);
      const f = via ? fChans.find((x) => String(x.id) === via) : null;
      if (f) { match.set(dc.id, f); usedC.add(String(f.id)); }
    }
    for (const dc of dl) {
      if (match.has(dc.id)) continue;
      const parentF = dc.parentId ? chanFor.get(dc.parentId)?.id ?? null : null;
      const same = fChans.filter((x) => free(x) && norm(x.name) === norm(dc.name));
      const f = same.find((x) => String(x.parent_id ?? "") === String(parentF ?? "")) ?? same[0];
      if (f) { match.set(dc.id, f); usedC.add(String(f.id)); }
    }
    const leftD = dl.filter((dc) => !match.has(dc.id));
    const leftF = fChans.filter(free);
    if (leftD.length && leftF.length) {
      // (the pairing helper takes "the side being copied" first)
      for (const [dId, fId] of await similarPairs(`tf:${dGuild.id}`, fid, kind, leftD.map((c) => ({ id: c.id, name: c.name, topic: c.topic })), leftF.map((c) => ({ id: String(c.id), name: c.name, topic: c.topic })))) {
        const f = leftF.find((x) => String(x.id) === String(fId));
        if (!f || usedC.has(String(f.id)) || match.has(dId)) continue;
        match.set(dId, f); usedC.add(String(f.id));
      }
    }
    for (const dc of dl) {
      const parentRef = dc.parentId ? chanFor.get(dc.parentId) ?? null : null;
      const f = match.get(dc.id) ?? null;
      const want = { name: dc.name.slice(0, 100), kind, topic: kind === "text" ? String(dc.topic ?? "").slice(0, 1024) : undefined, nsfw: !!dc.nsfw, slowmode: Number(dc.rateLimitPerUser ?? 0), userLimit: kind === "voice" ? Number(dc.userLimit ?? 0) : undefined, overwrites: overwrites(dc), parentRef, discordId: dc.id, position: dc.rawPosition ?? 0 };
      const mark = kind === "category" ? "category " : kind === "voice" ? "🔊 " : "#";
      if (f) {
        const ref = { id: String(f.id) };
        chanFor.set(dc.id, ref);
        const renamed = norm(f.name) !== norm(want.name);
        const moved = kind !== "category" && String(f.parent_id ?? "") !== String(parentRef?.id ?? "");
        const diff = renamed || moved || (kind === "text" && (f.topic ?? "") !== want.topic) || (kind !== "category" && (!!f.nsfw !== want.nsfw || Number(f.rate_limit_per_user ?? 0) !== want.slowmode)) || (kind === "voice" && Number(f.user_limit ?? 0) !== want.userLimit);
        steps.push({ t: "chanEdit", ref, ...want, quiet: !diff });
        if (renamed) { lines.push(`Rename ${mark}${f.name} to ${mark}${want.name}`); counts.channels++; }
        else if (moved && parentRef) { lines.push(`Move ${mark}${want.name} into "${dGuild.channels.cache.get(dc.parentId)?.name ?? "its category"}"`); counts.channels++; }
        else if (moved) { lines.push(`Move ${mark}${want.name} out of its category`); counts.channels++; }
        else if (diff) { lines.push(`Update ${mark}${want.name}`); counts.channels++; }
      } else {
        const ref = { id: null };
        chanFor.set(dc.id, ref);
        steps.push({ t: "chanNew", ref, ...want });
        lines.push(`Create ${kind === "category" ? "category " + want.name : (kind === "voice" ? "voice channel 🔊 " : "channel #") + want.name} (nothing on Fluxer is like it)`); counts.channels++;
      }
      if (kind !== "category" && !bridgedTo.has(dc.id)) { steps.push({ t: "bridge", ref: chanFor.get(dc.id), discordId: dc.id, kind }); lines.push(`Bridge ${mark}${want.name}`); counts.bridges++; }
    }
  }

  // Fluxer channels Discord doesn't have: to the bottom, or deleted with "clean" (never bridged or link channels)
  const extras = fChans.filter((x) => !usedC.has(String(x.id)) && !otherServer.has(String(x.id)));
  const bridgedHere = new Set(maps.map((m) => String(m.fluxerChannelId)));
  const kids = (cat) => fChans.filter((x) => String(x.parent_id ?? "") === String(cat.id));
  for (const x of extras) {
    const k = fKind(x.type);
    const mark = k === "category" ? "category " : k === "voice" ? "🔊 " : "#";
    const goes = clean && !bridgedHere.has(String(x.id)) && !keep.map(String).includes(String(x.id)) && (k !== "category" || (kids(x).every((c) => extras.includes(c) && !bridgedHere.has(String(c.id))) && !X.channels.some((c) => Number(c.type) === F_LINK && String(c.parent_id ?? "") === String(x.id))));
    if (goes) { steps.push({ t: "chanDel", id: String(x.id), name: x.name }); lines.push(`Delete ${mark}${x.name} (not on Discord)`); counts.removed++; }
    else lines.push(`Move ${mark}${x.name} to the bottom (not on Discord)`);
  }
  for (const c of X.channels) if (Number(c.type) === F_LINK) skipped.push(`🔗${c.name} stays as it is (Discord doesn't have link channels)`);
  return { steps, lines, skipped, counts, fluxerName: X.guild.name, discordName: dGuild.name, fid, extras: extras.map((x) => String(x.id)), toFluxer: true };
}

/** Do it. Same report as applySync. */
export async function applySyncToFluxer(dGuild, F, plan, progress = () => {}) {
  const { syncing } = await import("./ServerSync.js");
  syncing.add(dGuild.id); // (the server link leaves both sides alone meanwhile)
  try { return await applyNow(dGuild, F, plan, progress); } finally { setTimeout(() => syncing.delete(dGuild.id), 10_000); }
}
async function applyNow(dGuild, F, plan, progress) {
  const done = [], failed = [];
  const fid = plan.fid;
  const tryDo = async (what, fn) => { try { await fn(); done.push(what); } catch (e) { failed.push(`${what}: ${e?.message ?? e}`); } };
  let n = 0;
  const tick = (t) => { if (++n % 8 === 0) progress(t); };
  const ow = (s) => s.overwrites.filter((o) => o.role?.id).map((o) => ({ id: String(o.role.id), type: 0, allow: String(o.allow), deny: String(o.deny) }));
  for (const s of plan.steps) {
    if (s.t === "guildName") await tryDo("server name", () => F.rest.patch(FluxerRoutes.guild(fid), { body: { name: s.name }, auth: true }));
    else if (s.t === "guildIcon") await tryDo("server icon", async () => {
      const r = await fetch(s.url);
      if (!r.ok) throw new Error(`couldn't download the icon (${r.status})`);
      const uri = `data:${r.headers.get("content-type") || "image/png"};base64,${Buffer.from(await r.arrayBuffer()).toString("base64")}`;
      await F.rest.patch(FluxerRoutes.guild(fid), { body: { icon: uri }, auth: true });
      memo[fid] = { ...(memo[fid] ?? {}), icon: s.hash }; saveMemo();
    });
    else if (s.t === "roleNew") await tryDo(`role ${s.name}`, async () => { const r = await F.rest.post(FluxerRoutes.guildRoles(fid), { body: { name: s.name, color: s.color, hoist: s.hoist, mentionable: s.mentionable, permissions: s.permissions }, auth: true }); s.ref.id = String(r?.id ?? ""); tick("Making roles..."); });
    else if (s.t === "roleEdit") await tryDo(`role ${s.name}`, async () => { await F.rest.patch(FluxerRoutes.guildRole(fid, s.id), { body: { name: s.name, color: s.color, hoist: s.hoist, mentionable: s.mentionable, permissions: s.permissions }, auth: true }); tick("Updating roles..."); });
    else if (s.t === "everyone") await tryDo("@everyone permissions", () => F.rest.patch(FluxerRoutes.guildRole(fid, fid), { body: { permissions: s.permissions }, auth: true }));
    else if (s.t === "roleOrder") await tryDo("role order", async () => {
      const X = await readFluxer(F, fid);
      const below = (id) => (X.roles.find((r) => String(r.id) === String(id))?.position ?? Infinity) < X.top;
      const ids = s.order.map((r) => r?.id).filter((id) => id && below(id));
      if (!ids.length) return;
      const topPos = Number.isFinite(X.top) ? X.top - 1 : ids.length;
      await F.rest.patch(FluxerRoutes.guildRoles(fid), { body: ids.map((id, i) => ({ id: String(id), position: Math.max(1, topPos - i) })), auth: true });
    });
    else if (s.t === "roleDel") await tryDo(`delete role ${s.name}`, () => F.rest.delete(FluxerRoutes.guildRole(fid, s.id), { auth: true }));
    else if (s.t === "chanNew") await tryDo(`${s.kind} ${s.name}`, async () => {
      const body = { name: s.name, type: fTypeOf(s.kind), ...(s.kind !== "category" && s.parentRef?.id ? { parent_id: s.parentRef.id } : {}), ...(s.kind === "text" && s.topic ? { topic: s.topic } : {}), ...(s.kind !== "category" ? { nsfw: s.nsfw } : {}), ...(s.kind === "voice" && s.userLimit ? { user_limit: s.userLimit } : {}), permission_overwrites: ow(s) };
      const c = await F.rest.post(FluxerRoutes.guildChannels(fid), { body, auth: true });
      s.ref.id = String(c?.id ?? "");
      if (s.kind !== "category" && s.slowmode) await F.rest.patch(FluxerRoutes.channel(s.ref.id), { body: { rate_limit_per_user: s.slowmode }, auth: true }).catch(() => {});
      tick("Making channels...");
    });
    else if (s.t === "chanEdit") await tryDo(`${s.kind} ${s.name}`, async () => {
      const body = { permission_overwrites: ow(s) };
      if (!s.quiet) {
        body.name = s.name;
        if (s.kind !== "category") { body.parent_id = s.parentRef?.id ?? null; body.nsfw = s.nsfw; body.rate_limit_per_user = s.slowmode; }
        if (s.kind === "text") body.topic = s.topic || null;
        if (s.kind === "voice") body.user_limit = s.userLimit;
      }
      await F.rest.patch(FluxerRoutes.channel(s.ref.id), { body, auth: true });
      tick("Updating channels...");
    });
    else if (s.t === "chanDel") await tryDo(`delete #${s.name}`, () => F.rest.delete(FluxerRoutes.channel(s.id), { auth: true }));
    else if (s.t === "bridge") await tryDo(`bridge #${dGuild.channels.cache.get(s.discordId)?.name ?? s.discordId}`, async () => {
      if (!s.ref?.id) throw new Error("its Fluxer channel wasn't made");
      const { bridgeOne } = await import("./ServerSync.js");
      await bridgeOne(dGuild, F, fid, { ref: { id: s.discordId }, fluxerId: s.ref.id, kind: s.kind });
    });
  }
  // order and categories, like Discord (then what Discord doesn't have, last in its category)
  const placed = plan.steps.filter((s) => (s.t === "chanNew" || s.t === "chanEdit") && s.ref?.id).sort((a, b) => a.position - b.position);
  await tryDo("channel order", async () => {
    const deleted = new Set(plan.steps.filter((s) => s.t === "chanDel").map((s) => s.id));
    const list = placed.map((s) => ({ id: s.ref.id, ...(s.kind !== "category" ? { parent_id: s.parentRef?.id ?? null } : {}) }));
    for (const id of plan.extras ?? []) if (!deleted.has(id) && !list.some((x) => x.id === id)) list.push({ id });
    await F.rest.patch(FluxerRoutes.guildChannels(fid), { body: list.map((x, i) => ({ ...x, position: i })), auth: true });
  });
  // the server link now knows which categories go together
  try { (await import("./ServerLink.js")).rememberCats(placed.filter((s) => s.kind === "category").map((s) => [s.ref.id, s.discordId])); } catch {}
  // check: anything still in the wrong category gets moved one at a time
  await sleep(2000);
  const now = await F.rest.get(FluxerRoutes.guildChannels(fid), { auth: true }).catch(() => null);
  if (Array.isArray(now)) for (const s of placed) {
    if (s.kind === "category") continue;
    const c = now.find((x) => String(x.id) === String(s.ref.id));
    const want = s.parentRef?.id ?? null;
    if (!c || String(c.parent_id ?? "") === String(want ?? "")) continue;
    await F.rest.patch(FluxerRoutes.channel(s.ref.id), { body: { parent_id: want }, auth: true }).catch((e) => failed.push(`move #${c.name}: ${e?.message ?? e}`));
  }
  log("META", `Copied the Discord server "${dGuild.name}" onto the Fluxer server "${plan.fluxerName}": ${done.length} done, ${failed.length} failed.`);
  return { done: done.length, failed };
}
