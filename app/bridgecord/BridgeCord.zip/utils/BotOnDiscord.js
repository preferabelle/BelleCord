// How the bot speaks on Discord: as itself (its own bot account), like any normal bot.

/** Kept for compatibility with older code paths; the bot's own avatar is used on Discord. */
export function setBotAvatar(_url) {}
export const botHookIds = () => [];
export const isBotHook = () => false;

/**
 * The bot says something in a Discord channel. `replyTo` (a Discord message) makes it a reply.
 * No pings unless the payload asks for them on purpose.
 */
export async function botSend(channel, payload, replyTo = null) {
  const opts = typeof payload === "string" ? { content: payload } : { ...payload };
  opts.allowedMentions = opts.allowedMentions ?? { parse: [] };
  if (replyTo?.id) opts.reply = { messageReference: replyTo.id, failIfNotExists: false };
  return channel?.send?.(opts).catch(() => null);
}

/** The bot answers a Discord message. */
export async function botReply(message, payload) {
  return botSend(message.channel, payload, message);
}
