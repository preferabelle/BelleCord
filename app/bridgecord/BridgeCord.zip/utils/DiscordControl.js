// shared pieces for the owner's Discord control commands.
import { ChannelType } from "discord.js";

/** Why the bot can't act on this member (Discord's role order), or null if it can. */
export function hierarchyProblem(member) {
  const guild = member?.guild;
  const me = guild?.members?.me;
  if (!guild || !me) return "I'm not in that server.";
  if (member.id === guild.ownerId) return `they own **${guild.name}**, so Discord won't let anyone do that to them.`;
  if (member.id === me.id) return "that's me. No.";
  if (member.roles.highest.comparePositionTo(me.roles.highest) >= 0) {
    return (
      `their highest role **${member.roles.highest.name}** is at or above my highest role **${me.roles.highest.name}**. ` +
      `Discord only lets me act on people *below* my role, even as an admin. Fix: a Discord admin opens Server Settings → Roles and drags **${me.roles.highest.name}** above **${member.roles.highest.name}**.`
    );
  }
  return null;
}

const squash = (s) => String(s ?? "").toLowerCase().replace(/[^a-z0-9]/g, "");

/** Find a Discord text channel by name, #mention, or ID across the bot's servers. */
export function findDiscordChannel(discordClient, text) {
  const id = String(text ?? "").match(/^<?#?(\d{15,21})>?$/)?.[1];
  for (const g of discordClient?.guilds?.cache?.values?.() ?? []) {
    const chans = [...g.channels.cache.values()].filter((c) => c.isTextBased?.() && c.type !== ChannelType.GuildVoice);
    const hit = id ? chans.find((c) => c.id === id) : chans.find((c) => squash(c.name) === squash(text)) ?? chans.find((c) => squash(c.name).includes(squash(text)));
    if (hit) return hit;
  }
  return null;
}

/** Parse "10m", "2h", "1d", or a plain number of minutes into milliseconds. */
export function parseDuration(text) {
  const m = String(text ?? "").trim().toLowerCase().match(/^(\d+(?:\.\d+)?)\s*(s|sec|m|min|h|hr|hour|hours|d|day|days)?$/);
  if (!m) return null;
  const n = Number(m[1]);
  const unit = m[2] ?? "m";
  const mult = unit.startsWith("s") ? 1000 : unit.startsWith("h") ? 3600_000 : unit.startsWith("d") ? 86_400_000 : 60_000;
  return Math.round(n * mult);
}

/** A Discord voice channel by name or ID. */
export function findVoiceChannel(discordClient, text) {
  const id = String(text ?? "").match(/^<?#?(\d{15,21})>?$/)?.[1];
  for (const g of discordClient?.guilds?.cache?.values?.() ?? []) {
    const vcs = [...g.channels.cache.values()].filter((c) => c.type === ChannelType.GuildVoice || c.type === ChannelType.GuildStageVoice);
    const hit = id ? vcs.find((c) => c.id === id) : vcs.find((c) => squash(c.name) === squash(text)) ?? vcs.find((c) => squash(c.name).includes(squash(text)));
    if (hit) return hit;
  }
  return null;
}

/** The Discord channel meant: one named in `words`, or the Discord side of the Fluxer channel this was typed in. */
export async function discordChannelFor(message, discordClient, words, ChannelMap) {
  if (words?.length) {
    const named = findDiscordChannel(discordClient, words.join(" "));
    if (named) return named;
  }
  const map = await ChannelMap.findOne({ where: { fluxerChannelId: message.channelId }, raw: true }).catch(() => null);
  return map ? discordClient.channels.fetch(map.discordChannelId).catch(() => null) : null;
}

/** The Discord message for the Fluxer message the owner replied to (its original or its copy). */
export async function discordMessageForReply(message, discordClient, MessageMap, ChannelMap) {
  const refId = message.messageReference?.messageId ?? message.referencedMessage?.id;
  if (!refId) return { error: "Reply to the message you mean." };
  const row = await MessageMap.findOne({ where: { fluxerMessageId: refId }, raw: true }).catch(() => null);
  if (!row?.discordMessageId) return { error: "That message isn't on Discord (it wasn't bridged)." };
  const map = await ChannelMap.findOne({ where: { id: row.channelMapId }, raw: true }).catch(() => null);
  const ch = map ? await discordClient.channels.fetch(map.discordChannelId).catch(() => null) : null;
  const msg = await ch?.messages?.fetch(row.discordMessageId).catch(() => null);
  return msg ? { msg, fluxerId: refId } : { error: "I can't find it on Discord anymore." };
}

/**
 * The Fluxer community a command is about: where it was typed on Fluxer, or (typed on Discord)
 * the Fluxer side of that bridged channel, or else any bridged community.
 */
export async function fluxerGuildFor(message, ChannelMap, FluxerMessage) {
  if (message instanceof FluxerMessage && message.guildId) return { guildId: message.guildId, channelId: message.channelId };
  const map =
    (await ChannelMap.findOne({ where: { discordChannelId: message.channelId }, raw: true }).catch(() => null)) ??
    (await ChannelMap.findOne({ raw: true }).catch(() => null));
  return map ? { guildId: map.fluxerGuildId, channelId: map.fluxerChannelId } : null;
}
