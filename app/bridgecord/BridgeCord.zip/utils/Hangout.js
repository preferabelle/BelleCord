// the bridge bot sitting in a voice channel, muted and deafened.
// Joining takes two steps on Fluxer: ask the gateway to join (it answers with a
// LiveKit voice-server address and pass), then actually connect to that server.
// We connect without a microphone and without subscribing to anyone's audio,
// so it uses almost nothing.
//
// Fluxer lets one account hold several voice connections at once, and a join without a
// connection_id is always a NEW one. So:
//   * signing in again keeps the seat the bot has (the same connection_id), and only joins
//     fresh if that seat is gone
//   * news about the bot's other connections is ignored: the ones it opens for streams
//     (StreamBridge.js, at the bottom), and old seats from before a reconnect, which are told
//     to leave
//   * a new pass for a call that's still connected doesn't rebuild the call, passes that come close together are
//     taken once (the last one), and switching to a new pass connects the new call before letting go of the old
//     one, so nobody hears a gap
//   * the Fluxer connection signing in again doesn't make the Discord side rejoin a call it's still in
// It never takes video either: a bridge only needs voices (VoiceBridge.js picks them).
import fs from "node:fs";
import path from "node:path";
import { Events as FluxerEvents } from "@fluxerjs/core";
import Config from "./ConfigHandler.js";
import { log } from "./Logger.js";
import { attachFluxerRoom, bridgeStatus, detachFluxerRoom, startBridge, stopBridge } from "./VoiceBridge.js";
import { extraVoiceState, leaveAllMirrors, syncVoicePresence } from "./VoicePresence.js";

const FILE = path.join(Config.DataFolderPath, "vc.json");
/** @type {{ guildId: string, channelId: string, name: string, discord?: {guildId: string, channelId: string, name: string} | null } | null} */
let want = null;
try { want = JSON.parse(fs.readFileSync(FILE, "utf-8")); } catch {}
let client = null;
let room = null;
let connectionId = null;
let drops = [];
let rejoinTimer = null;
let answerTimer = null;
let seatConfirmed = false;
let lastEndpoint = null;
// the bridge bot's own stream connections (see the bottom). ids: connectionId -> { purpose, guildId }
const extra = { waiting: null, lateUntil: 0, ids: new Map(), gone: new Set() };
/** Tells whoever asked (the channel they typed in) when something goes wrong. */
let notify = (text) => log("META", text);

/** Swappable for tests. */
export const deps = {
  async makeRoom() {
    const { Room } = await import("@livekit/rtc-node");
    return new Room();
  },
};

function save() {
  try {
    if (want) fs.writeFileSync(FILE, JSON.stringify(want));
    else fs.rmSync(FILE, { force: true });
  } catch {}
}

function sendState(guildId, channelId) {
  client?.sendToGateway(0, {
    op: 4,
    d: {
      guild_id: guildId,
      channel_id: channelId,
      self_mute: !!channelId && !want?.discord,
      self_deaf: !!channelId && !want?.discord,
      // (leaving too: in a community, Fluxer refuses a "leave" that doesn't say which connection)
      ...(connectionId ? { connection_id: connectionId } : {}),
    },
  });
}

async function dropRoom() {
  await detachFluxerRoom().catch(() => {});
  const r = room;
  room = null;
  if (r) await r.disconnect().catch(() => {});
}

// (keep = ask for the seat the bot already has, after a reconnect; otherwise it's a brand new seat)
function askToJoin({ keep = false } = {}) {
  if (!want) return;
  if (!keep) {
    connectionId = null;
    cancelExtraWait("the bridge is joining the call again, try again in a moment");
  }
  seatConfirmed = false;
  sendState(want.guildId, want.channelId);
  clearTimeout(answerTimer);
  answerTimer = setTimeout(() => {
    if (!want) return;
    // asked to keep the seat and Fluxer said nothing: that seat is gone, so take a new one
    if (keep && !seatConfirmed) {
      log("META", `Voice: the old seat in ${want.name} wasn't there any more, joining again.`);
      askToJoin();
      return;
    }
    if (!room) notify(`Fluxer never answered when I asked to join ${want.name}. Check that my role is allowed to Connect there.`);
  }, keep ? 8_000 : 15_000);
}
const roomAlive = () => { try { return !!room && room.isConnected !== false; } catch { return !!room; } };

/** Come back after being dropped, but never spam join/leave. */
function rejoinLater(reason) {
  if (!want) return;
  const now = Date.now();
  drops = drops.filter((t) => now - t < 10 * 60 * 1000);
  drops.push(now);
  if (drops.length > 3) {
    const certs = /certificate/i.test(String(reason));
    notify(
      certs
        ? `I couldn't connect to ${want.name}: this computer is missing its security certificates, which voice needs. Update the bridge to the latest version (with Docker: \`docker compose up -d --build\`). On Linux you can also run \`sudo apt-get install ca-certificates\`. Then try again.`
        : `I couldn't stay connected to ${want.name} (${reason}), so I stopped trying. Try \`${Config.BotPrefix}voice on\` again.`,
    );
    want = null;
    save();
    dropAllBridgeConnections();
    dropRoom();
    return;
  }
  clearTimeout(rejoinTimer);
  rejoinTimer = setTimeout(() => askToJoin(), 5000 * drops.length);
}

// (a pass for a call that's still connected: wait a moment for one right behind it, then switch over once)
let nextPass = null, passTimer = null;
function takePass(endpoint, token) {
  if (!roomAlive()) { clearTimeout(passTimer); nextPass = null; return connectVoice(endpoint, token); }
  nextPass = { endpoint, token };
  clearTimeout(passTimer);
  passTimer = setTimeout(() => { const p = nextPass; nextPass = null; if (p && want) connectVoice(p.endpoint, p.token); }, 1500);
}

async function switchVoice(old, endpoint, token) {
  const url = /^wss?:\/\//i.test(endpoint) ? endpoint : `wss://${endpoint}`;
  let r;
  try { r = await deps.makeRoom(); } catch { return; }
  old.__bcReplaced = true; // (its hang-up, when Fluxer lets it go, isn't a drop)
  r.on("disconnected", () => {
    if (room !== r || r.__bcReplaced) return;
    room = null;
    rejoinLater("the voice server hung up");
  });
  try {
    await r.connect(url, token, { autoSubscribe: false, dynacast: false });
  } catch (e) {
    try { await r.disconnect(); } catch {}
    old.__bcReplaced = false;
    log("META", `Voice: Fluxer's new pass for ${want?.name} didn't connect (${e?.message ?? e}), so I stayed on the one I had.`);
    if (!roomAlive()) { room = null; rejoinLater("the voice server hung up"); }
    return;
  }
  lastEndpoint = endpoint;
  room = r;
  if (want?.discord) {
    await detachFluxerRoom({ keepTwins: true }).catch(() => {});
    await attachFluxerRoom(r, client).catch((e) => log("META", "Voice bridge: couldn't move to the new pass on Fluxer:", e?.message ?? e));
  }
  try { old.removeAllListeners?.(); } catch {}
  old.disconnect?.().catch?.(() => {});
  log("META", `Voice: moved to Fluxer's new voice pass for ${want?.name} without leaving the call.`);
}

async function connectVoice(endpoint, token) {
  clearTimeout(answerTimer);
  // (still in the call: the new one connects first, then the old one goes)
  const old = roomAlive() ? room : null;
  if (old) return switchVoice(old, endpoint, token);
  await dropRoom();
  lastEndpoint = endpoint;
  const url = /^wss?:\/\//i.test(endpoint) ? endpoint : `wss://${endpoint}`;
  let r;
  try {
    r = await deps.makeRoom();
  } catch (e) {
    notify("I can't do voice on this computer: the voice part didn't load. Close me and start again so I can download it.");
    log("META", "LiveKit failed to load:", e?.message ?? e);
    return;
  }
  room = r;
  r.on("disconnected", () => {
    if (room !== r || r.__bcReplaced) return; // we left on purpose, reconnected, or moved to a new pass
    room = null;
    rejoinLater("the voice server hung up");
  });
  try {
    const bridging = !!want?.discord;
    // (never everything: the bridge picks the voices itself in VoiceBridge.js, so streams and cameras stay out)
    await r.connect(url, token, { autoSubscribe: false, dynacast: false });
    if (bridging) {
      await attachFluxerRoom(r, client).catch((e) => {
        log("META", "Voice bridge: couldn't start on Fluxer:", e?.message ?? e);
        notify(`I'm in ${want?.name}, but I couldn't start relaying voices: ${e?.message ?? e}`);
      });
    } else {
      log("META", `Sitting in ${want?.name}, muted and deafened.`);
    }
    if (want) sendState(want.guildId, want.channelId); // confirm muted + deafened on the live connection
  } catch (e) {
    if (room === r) room = null;
    log("META", "Voice connect failed:", e?.message ?? e);
    rejoinLater(e?.message ?? "couldn't connect");
  }
}

export function attachHangout(fluxerClient) {
  client = fluxerClient;
  // A new sign-in: ask for the seat the bot already has (same connection_id). Only if the call itself dropped, or
  // that seat is gone, does it join fresh.
  fluxerClient.on(FluxerEvents.Ready, () => {
    if (!want) return;
    const keep = !!connectionId && roomAlive();
    setTimeout(() => askToJoin({ keep }), keep ? 500 : 2000);
  });
  fluxerClient.on(FluxerEvents.VoiceServerUpdate, (d) => {
    if (!want || d?.guild_id !== want.guildId || !d?.endpoint || !d?.token) return;
    const id = d.connection_id ?? null;
    if (id && (extra.ids.has(id) || extra.gone.has(id))) return; // (one of the stream connections)
    if (id && connectionId && id !== connectionId && roomAlive()) {
      // a new connection while the bot is settled in the call: the one asked for a stream
      if (extra.waiting) { const w = extra.waiting; extra.waiting = null; w.done(d); return; }
      // (one that was asked for and given up on: it leaves again)
      if (Date.now() < extra.lateUntil) { client?.sendToGateway(0, { op: 4, d: { guild_id: want.guildId, channel_id: null, connection_id: id } }); return; }
    }
    const sameSeat = !!connectionId && (!id || id === connectionId);
    connectionId = id ?? connectionId ?? null;
    seatConfirmed = true;
    clearTimeout(answerTimer);
    // the seat it kept, on the same voice server, and the call never dropped: nothing to rebuild
    if (sameSeat && roomAlive() && d.endpoint === lastEndpoint) return;
    takePass(d.endpoint, d.token);
  });
  fluxerClient.on(FluxerEvents.VoiceStateUpdate, (d) => {
    if (!want || d?.user_id !== fluxerClient.user?.id || d?.guild_id !== want.guildId) return;
    const theirSeat = d.connection_id ?? null;
    if (theirSeat && (extra.ids.has(theirSeat) || extra.gone.has(theirSeat))) return; // (a stream connection)
    // another connection of the bot's: not the call it's in. One being opened for a stream right now gets its pass
    // next; anything else still sitting in a channel is a leftover seat from before a reconnect, told to leave.
    if (theirSeat && connectionId && theirSeat !== connectionId) {
      if (extra.waiting || Date.now() < extra.lateUntil) return;
      if (d.channel_id) client?.sendToGateway(0, { op: 4, d: { guild_id: want.guildId, channel_id: null, connection_id: theirSeat } });
      return;
    }
    if (d.channel_id === want.channelId) { seatConfirmed = true; if (theirSeat) connectionId = theirSeat; return; }
    // its real seat was moved or disconnected. (A blip while reconnecting can say "nowhere" for a moment, so it
    // only counts if the call itself isn't running any more, or it's still that way a few seconds later.)
    const seat = connectionId;
    setTimeout(() => {
      if (!want || connectionId !== seat || (seatConfirmed && roomAlive())) return;
      dropAllBridgeConnections();
      dropRoom();
      rejoinLater("someone moved or disconnected me");
    }, roomAlive() ? 4000 : 0);
    seatConfirmed = false;
  });
}

/**
 * Sit in (or bridge) a Fluxer voice channel.
 * @param discordTarget when given, bridge voice with this Discord voice channel.
 */
export async function joinVc(guildId, channelId, name, tell, discordTarget = null, discordClient = null) {
  if (tell) notify = tell;
  const before = want;
  const hadSeat = !!room || !!before;
  dropAllBridgeConnections();
  want = { guildId, channelId, name, discord: discordTarget };
  drops = [];
  save();
  if (before?.discord && !discordTarget) {
    await stopBridge().catch(() => {});
    await leaveAllMirrors().catch(() => {});
  }
  if (discordTarget) {
    await startBridge(discordClient, client, discordTarget).catch((e) => log("META", "Voice bridge: Discord side failed to start:", e?.message ?? e));
    // Mirrors of anyone already in the Discord call join too.
    setTimeout(() => syncVoicePresence(discordClient, want).catch(() => {}), 3000);
  }
  // Start fresh so the room is joined in the right mode. If we were already seated,
  // step out first: asking to join a channel you're already in may get no answer.
  clearTimeout(rejoinTimer);
  await dropRoom();
  if (hadSeat && before) {
    sendState(before.guildId, null);
    connectionId = null;
    rejoinTimer = setTimeout(() => askToJoin(), 1500);
  } else {
    askToJoin();
  }
}

/** What we're set to do right now (for status and for resuming after a restart). */
export function currentVc() {
  return want;
}

/** After Discord connects (startup or reconnect), resume the Discord half of a saved voice bridge. */
export async function resumeVoiceBridge(discordClient) {
  if (!want?.discord) return;
  // (the Fluxer connection signing in again calls this too: when the Discord side is still in that call, it stays)
  try {
    const b = bridgeStatus();
    if (b?.active && b?.discord === "ready" && String(b?.target?.channelId ?? "") === String(want.discord.channelId)) return;
  } catch {}
  await startBridge(discordClient, client, want.discord).catch((e) => log("META", "Voice bridge: couldn't resume on Discord:", e?.message ?? e));
  setTimeout(() => syncVoicePresence(discordClient, want).catch(() => {}), 5000);
}

export async function leaveVc() {
  const was = want;
  dropAllBridgeConnections();
  if (was?.discord) {
    await stopBridge().catch(() => {});
    await leaveAllMirrors().catch(() => {});
  }
  want = null;
  save();
  clearTimeout(rejoinTimer);
  clearTimeout(answerTimer);
  await dropRoom();
  if (was) sendState(was.guildId, null);
  connectionId = null;
  return was;
}

// ---- more connections for the bridge bot itself (StreamBridge.js) ----
// Someone in the bridged call who uses BelleCord but has no mirror shows their Discord stream on Fluxer, or watches
// a Fluxer stream, through one more connection of the bridge bot. Each one is told apart from the seat by its
// connection_id, and leaves by itself when it's done.
function cancelExtraWait(why) {
  const w = extra.waiting;
  extra.waiting = null;
  w?.fail(new Error(why));
}

/** The bridge bot's seat, when it's settled in the call and can open another connection. */
export function bridgeSeat() {
  if (!want || !connectionId || !seatConfirmed || !roomAlive()) return null;
  return { guildId: want.guildId, channelId: want.channelId, connectionId, userId: client?.user?.id ?? null };
}

/** Ask Fluxer for one more connection for the bridge bot. Resolves { url, token, connectionId }. */
export function askBridgeConnection(purpose = "watch", { streamKey = null, timeoutMs = 12_000 } = {}) {
  const seat = bridgeSeat();
  if (!seat) return Promise.reject(new Error("the bridge isn't settled in the Fluxer call right now"));
  if (extra.waiting) return Promise.reject(new Error("already setting one up, try again in a moment"));
  return new Promise((ok, no) => {
    const timer = setTimeout(() => {
      if (extra.waiting !== w) return;
      extra.waiting = null;
      extra.lateUntil = Date.now() + 30_000; // (if it shows up after all, it's sent away)
      no(new Error("Fluxer didn't answer (the call may have too many connections)"));
    }, timeoutMs);
    const w = {
      done(d) {
        clearTimeout(timer);
        extra.ids.set(d.connection_id, { purpose, guildId: seat.guildId });
        ok({ url: /^wss?:\/\//i.test(d.endpoint) ? d.endpoint : `wss://${d.endpoint}`, token: d.token, connectionId: d.connection_id });
      },
      fail(e) { clearTimeout(timer); no(e); },
    };
    extra.waiting = w;
    client?.sendToGateway(0, { op: 4, d: extraVoiceState(seat.guildId, seat.channelId, purpose, streamKey) });
  });
}

/** That connection leaves the call. */
export function dropBridgeConnection(id) {
  const c = extra.ids.get(id);
  if (!c) return false;
  extra.ids.delete(id);
  extra.gone.add(id);
  if (extra.gone.size > 200) extra.gone = new Set([...extra.gone].slice(-100));
  try { client?.sendToGateway(0, { op: 4, d: { guild_id: c.guildId, channel_id: null, connection_id: id } }); } catch {}
  return true;
}

function dropAllBridgeConnections() {
  cancelExtraWait("the bridge left the call");
  for (const id of [...extra.ids.keys()]) dropBridgeConnection(id);
}
