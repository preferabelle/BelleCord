// the bridge bot sitting in a voice channel, muted and deafened.
// Joining takes two steps on Fluxer: ask the gateway to join (it answers with a
// LiveKit voice-server address and pass), then actually connect to that server.
// We connect without a microphone and without subscribing to anyone's audio,
// so it uses almost nothing.
import fs from "node:fs";
import path from "node:path";
import { Events as FluxerEvents } from "@fluxerjs/core";
import Config from "./ConfigHandler.js";
import { log } from "./Logger.js";
import { attachFluxerRoom, detachFluxerRoom, startBridge, stopBridge } from "./VoiceBridge.js";
import { leaveAllMirrors, syncVoicePresence } from "./VoicePresence.js";

const FILE = path.join(Config.DataFolderPath, "vc.json");
/** @type {{ guildId: string, channelId: string, name: string, discord?: {guildId: string, channelId: string, name: string} | null } | null} */
let want = null;
try { want = JSON.parse(fs.readFileSync(FILE, "utf-8")); } catch {}
let client = null;
let room = null;
let connectionId = null;
let drops = [];
let rejoinTimer = null;
let answerTimer = null;
/** Tells whoever asked (the channel they typed in) when something goes wrong. */
let notify = (text) => log("META", text);

/** Swappable for tests. */
export const deps = {
  async makeRoom() {
    const { Room } = await import("@livekit/rtc-node");
    return new Room();
  },
};

function save() {
  try {
    if (want) fs.writeFileSync(FILE, JSON.stringify(want));
    else fs.rmSync(FILE, { force: true });
  } catch {}
}

function sendState(guildId, channelId) {
  client?.sendToGateway(0, {
    op: 4,
    d: {
      guild_id: guildId,
      channel_id: channelId,
      self_mute: !!channelId && !want?.discord,
      self_deaf: !!channelId && !want?.discord,
      ...(channelId && connectionId ? { connection_id: connectionId } : {}),
    },
  });
}

async function dropRoom() {
  await detachFluxerRoom().catch(() => {});
  const r = room;
  room = null;
  if (r) await r.disconnect().catch(() => {});
}

function askToJoin() {
  if (!want) return;
  connectionId = null;
  sendState(want.guildId, want.channelId);
  clearTimeout(answerTimer);
  answerTimer = setTimeout(() => {
    if (want && !room) notify(`Fluxer never answered when I asked to join ${want.name}. Check that my role is allowed to Connect there.`);
  }, 15_000);
}

/** Come back after being dropped, but never spam join/leave. */
function rejoinLater(reason) {
  if (!want) return;
  const now = Date.now();
  drops = drops.filter((t) => now - t < 10 * 60 * 1000);
  drops.push(now);
  if (drops.length > 3) {
    const certs = /certificate/i.test(String(reason));
    notify(
      certs
        ? `I couldn't connect to ${want.name}: this computer is missing its security certificates, which voice needs. Update the bridge to the latest version (with Docker: \`docker compose up -d --build\`). On Linux you can also run \`sudo apt-get install ca-certificates\`. Then try again.`
        : `I couldn't stay connected to ${want.name} (${reason}), so I stopped trying. Try \`bb!voice on\` again.`,
    );
    want = null;
    save();
    dropRoom();
    return;
  }
  clearTimeout(rejoinTimer);
  rejoinTimer = setTimeout(askToJoin, 5000 * drops.length);
}

async function connectVoice(endpoint, token) {
  clearTimeout(answerTimer);
  await dropRoom();
  const url = /^wss?:\/\//i.test(endpoint) ? endpoint : `wss://${endpoint}`;
  let r;
  try {
    r = await deps.makeRoom();
  } catch (e) {
    notify("I can't do voice on this computer: the voice part didn't load. Close me and start again so I can download it.");
    log("META", "LiveKit failed to load:", e?.message ?? e);
    return;
  }
  room = r;
  r.on("disconnected", () => {
    if (room !== r) return; // we left on purpose or reconnected
    room = null;
    rejoinLater("the voice server hung up");
  });
  try {
    const bridging = !!want?.discord;
    await r.connect(url, token, { autoSubscribe: bridging, dynacast: false });
    if (bridging) {
      await attachFluxerRoom(r, client).catch((e) => {
        log("META", "Voice bridge: couldn't start on Fluxer:", e?.message ?? e);
        notify(`I'm in ${want?.name}, but I couldn't start relaying voices: ${e?.message ?? e}`);
      });
    } else {
      log("META", `Sitting in ${want?.name}, muted and deafened.`);
    }
    if (want) sendState(want.guildId, want.channelId); // confirm muted + deafened on the live connection
  } catch (e) {
    if (room === r) room = null;
    log("META", "Voice connect failed:", e?.message ?? e);
    rejoinLater(e?.message ?? "couldn't connect");
  }
}

export function attachHangout(fluxerClient) {
  client = fluxerClient;
  // Voice seats don't survive a reconnect, so take it again every time we sign in.
  fluxerClient.on(FluxerEvents.Ready, () => {
    if (want) setTimeout(askToJoin, 2000);
  });
  fluxerClient.on(FluxerEvents.VoiceServerUpdate, (d) => {
    if (!want || d?.guild_id !== want.guildId || !d?.endpoint || !d?.token) return;
    connectionId = d.connection_id ?? null;
    connectVoice(d.endpoint, d.token);
  });
  fluxerClient.on(FluxerEvents.VoiceStateUpdate, (d) => {
    if (!want || d?.user_id !== fluxerClient.user?.id || d?.guild_id !== want.guildId) return;
    if (d.channel_id === want.channelId) return;
    dropRoom();
    rejoinLater("someone moved or disconnected me");
  });
}

/**
 * Sit in (or bridge) a Fluxer voice channel.
 * @param discordTarget when given, bridge voice with this Discord voice channel.
 */
export async function joinVc(guildId, channelId, name, tell, discordTarget = null, discordClient = null) {
  if (tell) notify = tell;
  const before = want;
  const hadSeat = !!room || !!before;
  want = { guildId, channelId, name, discord: discordTarget };
  drops = [];
  save();
  if (before?.discord && !discordTarget) {
    await stopBridge().catch(() => {});
    await leaveAllMirrors().catch(() => {});
  }
  if (discordTarget) {
    await startBridge(discordClient, client, discordTarget).catch((e) => log("META", "Voice bridge: Discord side failed to start:", e?.message ?? e));
    // Mirrors of anyone already in the Discord call join too.
    setTimeout(() => syncVoicePresence(discordClient, want).catch(() => {}), 3000);
  }
  // Start fresh so the room is joined in the right mode. If we were already seated,
  // step out first: asking to join a channel you're already in may get no answer.
  clearTimeout(rejoinTimer);
  await dropRoom();
  if (hadSeat && before) {
    sendState(before.guildId, null);
    rejoinTimer = setTimeout(askToJoin, 1500);
  } else {
    askToJoin();
  }
}

/** What we're set to do right now (for status and for resuming after a restart). */
export function currentVc() {
  return want;
}

/** After Discord connects (startup or reconnect), resume the Discord half of a saved voice bridge. */
export async function resumeVoiceBridge(discordClient) {
  if (!want?.discord) return;
  await startBridge(discordClient, client, want.discord).catch((e) => log("META", "Voice bridge: couldn't resume on Discord:", e?.message ?? e));
  setTimeout(() => syncVoicePresence(discordClient, want).catch(() => {}), 5000);
}

export async function leaveVc() {
  const was = want;
  if (was?.discord) {
    await stopBridge().catch(() => {});
    await leaveAllMirrors().catch(() => {});
  }
  want = null;
  save();
  clearTimeout(rejoinTimer);
  clearTimeout(answerTimer);
  await dropRoom();
  if (was) sendState(was.guildId, null);
  return was;
}
