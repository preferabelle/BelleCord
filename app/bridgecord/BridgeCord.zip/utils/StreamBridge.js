// streams across the bridge, for people in the bridged call who use BelleCord.
// A Discord bot can't watch or send a Discord stream (Go Live), so the bridge can't carry streams by itself. BelleCord
// has Fluxer and Discord in one window, so it does that part, straight with Fluxer's call:
//   * someone goes live on Discord: their BelleCord shows the same screen in the Fluxer call too, as their mirror
//     (or as the bridge bot, if they don't have a mirror). Everyone on Fluxer can watch it, BelleCord or not.
//   * someone streams on Fluxer: BelleCord offers "Watch" on the Discord side and plays it in a small window.
// The bridge only sets it up. It asks Fluxer for one more voice connection (VoicePresence.js for a mirror, Hangout.js
// for the bridge bot) and hands it to their BelleCord, which talks to the call by itself, so no video ever goes
// through the bridge. BelleCord asks through StreamServer.js. A connection nobody checks in on for 90 seconds closes.
import { Events as FluxerEvents } from "@fluxerjs/core";
import { log } from "./Logger.js";
import { state as voice } from "./VoiceBridge.js";
import { askExtraConnection, dropExtraConnection, mirrorSeated } from "./VoicePresence.js";
import { askBridgeConnection, bridgeSeat, currentVc, dropBridgeConnection } from "./Hangout.js";
import { getMirrorByDiscordId } from "./Mirrors.js";

const SCREEN = 3, SCREEN_AUDIO = 4; // (LiveKit's numbers for a shared screen and its sound)
/** connectionId -> { discordUserId, via: "mirror" | "bridge", mirror, purpose, accountId, at, ping, live } */
export const open = new Map();

// Fluxer names each connection in the call user_<account>_<connection>, and a stream by <community>:<channel>:<connection>.
const accountOf = (identity) => /^user_(\d+)_/.exec(String(identity ?? ""))?.[1] ?? String(identity ?? "").match(/\d{15,21}/)?.[0] ?? null;
const connectionOf = (identity) => /^user_\d+_(.+)$/.exec(String(identity ?? ""))?.[1] ?? null;
function streamKey(identity) {
  const want = currentVc(), c = connectionOf(identity);
  return want && c ? `${want.guildId}:${want.channelId}:${c}` : null;
}

/** Is this Discord person in the bridged Discord call right now? */
export function inBridgedCall(discordUserId) {
  if (!voice.active || !voice.target) return false;
  const ch = voice.discordClient?.channels?.cache?.get(voice.target.channelId);
  return !!ch?.members?.has?.(String(discordUserId));
}

/** Their mirror, if it's in the Fluxer call. */
function seatedMirror(discordUserId) {
  const m = getMirrorByDiscordId(String(discordUserId));
  return m && mirrorSeated(m) ? m : null;
}

function nameOf(p) {
  const id = accountOf(p?.identity);
  const fc = voice.fluxerClient, gid = currentVc()?.guildId;
  try {
    const g = fc?.guilds?.get?.(gid) ?? fc?.guilds?.cache?.get?.(gid);
    const m = g?.members?.get?.(id) ?? g?.members?.cache?.get?.(id);
    const u = fc?.users?.get?.(id) ?? fc?.users?.cache?.get?.(id);
    const n = m?.nick || m?.displayName || u?.globalName || u?.global_name || u?.username;
    if (n) return String(n);
  } catch {}
  return p?.name && p.name !== p.identity ? String(p.name) : "Someone";
}

/** What their BelleCord needs to know: are they in the bridged call, and who's streaming on Fluxer. */
export function streamInfo({ discordUserId }) {
  const inCall = inBridgedCall(discordUserId);
  const mirror = getMirrorByDiscordId(String(discordUserId));
  const seated = inCall ? seatedMirror(discordUserId) : null;
  const bridgeHere = inCall && !!bridgeSeat();
  const streams = [];
  if (inCall) {
    for (const p of voice.room?.remoteParticipants?.values?.() ?? []) {
      const pubs = [...(p.trackPublications?.values?.() ?? [])];
      if (!pubs.some((x) => x.source === SCREEN)) continue;
      // (a Discord stream this bridge put on Fluxer: everyone on Discord sees it there already)
      if (open.has(connectionOf(p.identity) ?? "")) continue;
      streams.push({ identity: String(p.identity), name: nameOf(p), audio: pubs.some((x) => x.source === SCREEN_AUDIO) });
    }
  }
  const mine = [...open.values()].find((o) => o.discordUserId === String(discordUserId) && o.purpose === "publish");
  return {
    inCall,
    canStream: !!seated || bridgeHere,
    as: seated ? "mirror" : bridgeHere ? "bridge" : null, // (what their stream shows up as on Fluxer)
    hasMirror: !!mirror,
    channel: inCall ? voice.target?.name ?? currentVc()?.name ?? null : null,
    streams,
    ...(mine && mine.live === false ? { warn: "no-stream-permission" } : {}),
  };
}

/** A new Fluxer connection for this person: "publish" (their Discord stream on Fluxer) or "watch". */
export async function streamOpen({ discordUserId, purpose, identity }) {
  purpose = purpose === "publish" ? "publish" : "watch";
  discordUserId = String(discordUserId ?? "");
  if (!inBridgedCall(discordUserId)) throw new Error("You're not in the bridged call on Discord.");
  // (one of each kind per person at a time: a new one replaces the old one)
  for (const [id, o] of open) if (o.discordUserId === discordUserId && o.purpose === purpose) streamClose({ discordUserId, connectionId: id });
  const key = purpose === "watch" && identity ? streamKey(identity) : null;
  const mirror = seatedMirror(discordUserId);
  let got, via, accountId;
  if (mirror) {
    got = await askExtraConnection(mirror, purpose, { streamKey: key });
    via = "mirror";
    accountId = mirror.fluxerId;
  } else {
    if (!bridgeSeat()) throw new Error("The bridge isn't in the Fluxer call right now.");
    got = await askBridgeConnection(purpose, { streamKey: key });
    via = "bridge";
    accountId = bridgeSeat()?.userId ?? voice.fluxerClient?.user?.id ?? null;
  }
  open.set(got.connectionId, { discordUserId, via, mirror, purpose, accountId, at: Date.now(), ping: Date.now(), live: null });
  const who = mirror ? mirror.name : "the bridge bot";
  log("META", `Stream bridge: a ${purpose === "publish" ? "connection to show a Discord stream on Fluxer" : "connection to watch a Fluxer stream"} for ${who}.`);
  return { ...got, purpose, as: via, name: mirror ? mirror.name : null };
}

/** Done with it (or BelleCord closed): it leaves the Fluxer call. */
export function streamClose({ discordUserId, connectionId }) {
  const id = String(connectionId ?? "");
  const o = open.get(id);
  if (!o || o.discordUserId !== String(discordUserId ?? "")) return { closed: false };
  open.delete(id);
  if (o.via === "mirror") dropExtraConnection(o.mirror, id);
  else dropBridgeConnection(id);
  log("META", `Stream bridge: ${o.via === "mirror" ? o.mirror.name + "'s" : "the bridge bot's"} ${o.purpose} connection closed.`);
  return { closed: true };
}

/** BelleCord checks in every 30 seconds while it's using one. */
export function streamPing({ discordUserId, connectionId }) {
  const o = open.get(String(connectionId ?? ""));
  if (!o || o.discordUserId !== String(discordUserId ?? "")) return { ok: false };
  o.ping = Date.now();
  return { ok: true, inCall: inBridgedCall(o.discordUserId), ...(o.purpose === "publish" && o.live === false ? { warn: "no-stream-permission" } : {}) };
}

/**
 * The bridge bot sees everyone's voice states in the community, so it notices when Fluxer turned a stream
 * connection's "live" off: that account isn't allowed to stream in that channel (it needs the Stream permission).
 */
export function attachStreamBridge(fluxerClient) {
  fluxerClient.on(FluxerEvents.VoiceStateUpdate, (d) => {
    const o = d?.connection_id ? open.get(d.connection_id) : null;
    if (!o || o.purpose !== "publish") return;
    const live = d.self_stream === true || d.self_stream === "true";
    if (o.live !== live) {
      o.live = live;
      if (!live) log("META", `Stream bridge: Fluxer won't show the stream from ${o.via === "mirror" ? o.mirror.name : "the bridge bot"} as live. It needs the Stream permission in that voice channel.`);
    }
  });
}

// (nobody checking in, or they left the call: closed)
setInterval(() => {
  for (const [id, o] of open) if (Date.now() - o.ping > 90_000 || !inBridgedCall(o.discordUserId)) streamClose({ discordUserId: o.discordUserId, connectionId: id });
}, 15_000).unref?.();
