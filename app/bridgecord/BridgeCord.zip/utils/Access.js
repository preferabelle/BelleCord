// Who can do what.
//   owner:    the person in settings.txt ("owner fluxer id", optionally "owner discord id"). Everything.
//   admin:    people the owner adds with the admins command, and (unless switched off in
//             settings) people who manage the server: Administrator / Manage Community on Fluxer,
//             Manage Server on Discord.
//   everyone: help, info, and games. Nothing that changes the bot or either server.
import Config from "./ConfigHandler.js";
import { checkManageServerPerms } from "./CheckManageServerPerms.js";

export function isOwner(userId) {
  return !!userId && (userId === Config.OwnerId || userId === Config.OwnerDiscordId);
}

/** "owner", "admin", or "everyone" for whoever sent this message. */
export async function accessLevel(message) {
  const id = message?.author?.id;
  if (isOwner(id)) return "owner";
  if (id && Config.AdminAccountIds.includes(id)) return "admin";
  if (Config.ManagersAreAdmins) {
    const manages = await checkManageServerPerms(message.guildId ?? "", id, message.client).catch(() => false);
    if (manages) return "admin";
  }
  return "everyone";
}

/** What a command needs. Older flags map onto the three levels. */
export function accessNeeded(command) {
  if (command?.access) return command.access;
  return command?.requireOwner || command?.requireElevated ? "admin" : "everyone";
}

export async function allowed(message, command) {
  const need = accessNeeded(command);
  if (need === "everyone") return true;
  const level = await accessLevel(message);
  return need === "owner" ? level === "owner" : level !== "everyone";
}
