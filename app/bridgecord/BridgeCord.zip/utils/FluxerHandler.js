import { getTwinByFluxerId, twins } from "./Twins.js";
import { ChannelMap, MessageMap } from "../db/index.js";
import Config from "../utils/ConfigHandler.js";
import { CommandHandler } from "./CommandHandler.js";
import { cloudUploadAttachments } from "./CloudUpload.js";
import { Op } from "sequelize";
import truncate from "truncate";
import { readFileSync } from "node:fs";
import {
  parseFluxerEmojiToDiscord,
  removeLinkEmbeds,
  traverseMessageLinks,
} from "./EmojiStickerParser.js";
import { fluxerEmbedToDiscord } from "./EmbedConverter.js";
import { parseMentions } from "./MessageContentParser.js";
import { sanitizePings } from "./SanitizePings.js";
import { log } from "./Logger.js";
import { getGuildPrefix } from "./GetGuildPrefix.js";
import { processReplyContent } from "./ProcessReplyContent.js";
import { getFluxerMediaBaseUrl } from "./GetFluxerUrls.js";
import {
  isFluxerSpoilerAttachment,
  toDiscordSpoilerFilename,
} from "./SpoilerAttachments.js";
import { checkPingPerms } from "./CheckManageServerPerms.js";
import { cacheUser, resolveMentions } from "./MentionResolver.js";
import { resetBridgeHealth } from "./BridgeHealth.js";
import { resolveDiscordThreadId } from "./DiscordThreadResolver.js";
import { processSticker } from "./StickerProcessor.js";
import { fluxerMentionsToDiscord, isMirrorFluxerId } from "./Mirrors.js";


let fluxcordBotEmojiCfg = undefined;

async function downloadFluxerAttachment(url) {
  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      const res = await fetch(url);
      if (!res.ok) return null;
      return Buffer.from(await res.arrayBuffer());
    } catch (e) {
      if (attempt === 1) {
        log("FLUXER", `Failed to download Fluxer attachment ${url}`, e);
        return null;
      }
    }
  }
  return null;
}

async function getFluxerAvatarURL(user, member) {
  if (!user?.avatarURL) return undefined;
  const avatar = member?.avatar ?? user.avatar;
  if (!avatar) {
    return user.avatarURL() ?? undefined;
  }

  const mediaBase =
    (await getFluxerMediaBaseUrl().catch(() => undefined)) ??
    Config.FluxerCDNBaseURL;
  const cdnBase = mediaBase.replace(/\/$/, "");
  const extension = avatar.startsWith("a_") ? "gif" : "webp";
  const path = member?.avatar
    ? `guilds/${member.guild.id}/users/${user.id}/avatars`
    : `avatars/${user.id}`;

  return `${cdnBase}/${path}/${avatar}.${extension}?size=160`;
}

function isFluxerMessageNotFoundError(error) {
  return (
    error?.code === "MESSAGE_NOT_FOUND" ||
    error?.code === "UNKNOWN_MESSAGE" ||
    error?.statusCode === 404 ||
    (error?.cause?.statusCode === 404 &&
      /message .* not found/i.test(error?.message ?? ""))
  );
}

function isDiscordUnknownMessageError(error) {
  return (
    error?.code === 10008 ||
    (error?.status === 404 && /unknown message/i.test(error?.message ?? ""))
  );
}

const earlyBridgeEmojiThreshold = 3;

function countCustomEmojis(content) {
  if (!content) return 0;
  const matches = content.match(/<a?:.+?:\d+>/g);
  return matches ? matches.length : 0;
}

/**
 * @param {import("@fluxerjs/core").Message} message
 * @param {import("@fluxerjs/core").Client} client
 * @param {import("discord.js").Client} discordClient
 */
/** the same Discord message, as seen by the personal bot that sent it (so it can edit/delete it). */
async function twinsCopy(discordMessage) {
  if (!discordMessage?.author) return null;
  const twin = twins.find((t) => t.client?.user?.id === discordMessage.author.id);
  if (!twin?.ready) return null;
  const ch = await twin.client.channels.fetch(discordMessage.channelId).catch(() => null);
  return ch?.messages?.fetch(discordMessage.id).catch(() => null) ?? null;
}

export async function FluxerCreateMessageHandler(
  message,
  client,
  discordClient,
  forceGuildId = null,
) {
  log(
    "DEBUG",
    `FluxerCreate received id=${message.id} channelId=${message.channelId} guildId=${forceGuildId ?? message.guildId} authorId=${message.author?.id} type=${message.type} hasReference=${Boolean(message.messageReference)}`,
  );
  cacheUser(message.author);

  // mirror bots post things that came FROM Discord; never send them back.
  if (isMirrorFluxerId(message.author?.id)) {
    log("DEBUG", `FluxerCreate skip id=${message.id} reason=mirrorBot`);
    return;
  }

  if (!fluxcordBotEmojiCfg)
    fluxcordBotEmojiCfg = JSON.parse(
      readFileSync(Config.DataFolderPath + "/fluxcord.json", "utf-8"),
    );

  const guildId = forceGuildId || message.guildId;

  if (!guildId || message.type === 6) {
    log(
      "DEBUG",
      `FluxerCreate skip id=${message.id} reason=unsupportedGuildOrType type=${message.type}`,
    );
    return;
  }

  const guildPrefix = await getGuildPrefix(guildId);
  if (message.content.startsWith(guildPrefix)) {
    log(
      "DEBUG",
      `FluxerCreate id=${message.id} isCommand=${!forceGuildId}`,
    );
    if (forceGuildId) return;
    CommandHandler(message, discordClient, client);
    return;
  }

  const channelMapViaUserId = await ChannelMap.findOne({
    where: {
      [Op.or]: {
        discordWebhookId: message.author.id,
        fluxerWebhookId: message.author.id,
      },
    },
  });

  if (channelMapViaUserId) {
    log(
      "DEBUG",
      `FluxerCreate skip id=${message.id} authorId=${message.author.id} reason=webhookAuthor`,
    );
    return;
  }

  const channelMap = await ChannelMap.findOne({
    where: {
      fluxerChannelId: message.channelId,
    },
    raw: true,
  });

  if (channelMap?.bridgeType === "discord2fluxer") {
    log(
      "DEBUG",
      `FluxerCreate skip id=${message.id} channelId=${message.channelId} reason=oneWayBridge bridgeType=${channelMap.bridgeType}`,
    );
    return;
  }

  /** @type {import("../db/models/MessageMap.js").MessageMap | null} */
  let messageReference;
  if (message.messageReference) {
    messageReference = await MessageMap.findOne({
      where: {
        [Op.or]: [
          {
            fluxerMessageId: message.messageReference.messageId,
          },
          {
            discordMessageId: message.messageReference.messageId,
          },
        ],
      },
    });

    if (messageReference && messageReference.channelMapId !== channelMap?.id) {
      messageReference = null;
    }
  }

  let forwardedMessage;
  if (message.messageReference?.type === 1) {
    forwardedMessage = message.messageSnapshots[0];
    messageReference = undefined;
  }

  const userJoin =
    message.type === 7
      ? `*@${message.author.username}${message.author.discriminator !== "0000" ? `#${message.author.discriminator}` : ""} joined the bridged community*`
      : "";

  if (!channelMap || channelMap.fluxerWebhookId === message.webhookId) {
    log(
      "DEBUG",
      `FluxerCreate skip id=${message.id} channelId=${message.channelId} reason=${!channelMap ? "noChannelMap" : "webhookEcho"} webhookId=${message.webhookId ?? "none"}`,
    );
    return;
  }

  log(
    "DEBUG",
    `FluxerCreate bridge start id=${message.id} channelMapId=${channelMap.id} hasForward=${Boolean(forwardedMessage)} hasReply=${Boolean(messageReference)} attachmentCount=${(forwardedMessage ?? message).attachments?.length ?? 0} stickerCount=${message.stickers?.length ?? 0}`,
  );

  const mediaBase =
    (await getFluxerMediaBaseUrl().catch(() => undefined)) ??
    Config.FluxerCDNBaseURL;

  const stickerFiles = [];
  const stickerFallbacks = [];

  for (const sticker of message.stickers) {
    const url = `${mediaBase}/stickers/${sticker.id}.webp?size=320&animated=${sticker.animated}`;
    const processed = await processSticker(url, {
      animated: sticker.animated,
      name: sticker.name,
    });

    if (processed) {
      stickerFiles.push({ name: processed.filename, attachment: processed.buffer });
    } else {
      stickerFallbacks.push(`[${sticker.name}](${url})`);
    }
  }

  const stickerMsg = stickerFallbacks.join(", ");

  const overAttachments =
    (forwardedMessage ?? message).attachments?.filter(
      (x) => x.size > 9999000,
    ) ?? [];
  const overAttachmentsStr = overAttachments
    .map((x) => `[${x.filename}](<${x.proxyUrl ?? x.url}>)`)
    .join(" ");

  const webhook = await discordClient.fetchWebhook(
    channelMap.discordWebhookId,
    channelMap.discordWebhookToken,
  );

  const threadId = await resolveDiscordThreadId(
    discordClient,
    channelMap.discordChannelId,
  );

  // the owner talks through the Discord bot itself (a real member), not a webhook.
  // People with their own linked Discord bot talk through it; everyone else through the webhook.
  const speakerTwin = getTwinByFluxerId(message.author.id);
  const speakerClient = speakerTwin?.ready && speakerTwin.client?.channels ? speakerTwin.client : null;

  const fastUsername = message.author.globalName ?? message.author.username;

  let earlyDiscordMsgId = null;
  const earlySourceText = (forwardedMessage ?? message).content ?? "";
  const customEmojiCount = countCustomEmojis(earlySourceText);
  if (!speakerClient && customEmojiCount >= earlyBridgeEmojiThreshold) {
    const loadingEmoji = fluxcordBotEmojiCfg.discordLoadingEmoji
      ? `<a:loading:${fluxcordBotEmojiCfg.discordLoadingEmoji}>`
      : "⏳";
    const loadingText =
      earlySourceText.replace(/<a?:.+?:\d+>/g, loadingEmoji) ||
      `${loadingEmoji} Bridging message with ${customEmojiCount} custom emojis...`;
    try {
      const earlyMsg = await webhook.send({
        content:
          (forwardedMessage
            ? `-# <:reply_l:${fluxcordBotEmojiCfg.discordReplyEmoji.replyL}><:reply_r:${fluxcordBotEmojiCfg.discordReplyEmoji.replyR}> Forwarded message\n`
            : "") +
          loadingText +
          userJoin,
        username: fastUsername,
        avatarURL: await getFluxerAvatarURL(message.author, undefined),
        allowedMentions: { parse: [] },
        ...(threadId ? { threadId } : {}),
      });
      earlyDiscordMsgId = earlyMsg.id;
      log(
        "DEBUG",
        `FluxerCreate early bridge id=${message.id} discordId=${earlyDiscordMsgId} emojiCount=${customEmojiCount}`,
      );
    } catch (e) {
      log("DISCORD", `Early bridge placeholder failed for ${message.id}`, e);
    }
  }

  let guildUser = undefined;
  try {
    guildUser = await message.guild.fetchMember(message.author.id);
  } catch {
    guildUser = undefined;
  }

  const otherSideGuild = await discordClient.guilds.fetch(
    channelMap.discordGuildId,
  );

  const canUserPing = await checkPingPerms(guildId, message.author.id, client);

  const parsedContent = await traverseMessageLinks(
    await parseFluxerEmojiToDiscord(
      await resolveMentions(
        otherSideGuild,
        sanitizePings(
          await parseMentions(
            forwardedMessage ?? message,
            fluxerMentionsToDiscord((forwardedMessage ?? message).content),
            otherSideGuild,
          ),
          canUserPing,
        ),
      ),
      discordClient,
      channelMap.discordGuildId,
    ),
  );

  const attachmentDescs =
    (forwardedMessage ?? message).attachments
      ?.filter((x) => x.size < 19999000)
      .map((a) => ({
        url: a.proxyUrl ?? a.url ?? "",
        name: toDiscordSpoilerFilename(
          a.filename,
          isFluxerSpoilerAttachment(a),
        ),
        description: a.description,
      })) ?? [];

  const files = [];
  for (const desc of attachmentDescs) {
    if (!desc.url) continue;
    const data = await downloadFluxerAttachment(desc.url);
    if (!data) continue;
    files.push({
      attachment: data,
      name: desc.name,
      description: desc.description,
    });
  }

  files.push(...stickerFiles);

  const attachments =
    files.length > 0
      ? await cloudUploadAttachments(
        discordClient,
        channelMap.discordChannelId,
        files,
      )
      : undefined;

  /** @type {import("discord.js").MessagePayload | import("discord.js").WebhookMessageCreateOptions} */
  const webhookPayload = {
    content:
      // @ts-expect-error
      (forwardedMessage
        ? `-# <:reply_l:${fluxcordBotEmojiCfg.discordReplyEmoji.replyL}><:reply_r:${fluxcordBotEmojiCfg.discordReplyEmoji.replyR}> Forwarded message\n`
        : "") +
      (messageReference
        ? `-# <:reply_l:${fluxcordBotEmojiCfg.discordReplyEmoji.replyL}><:reply_r:${fluxcordBotEmojiCfg.discordReplyEmoji.replyR}> ${messageReference.messageSource === "discord" ? `<@${messageReference.authorId}>` : `@${message.referencedMessage?.author.username}#${message.referencedMessage?.author.discriminator}`}: [${await processReplyContent(message.referencedMessage)}](<https://discord.com/channels/${channelMap.discordGuildId}/${channelMap.discordChannelId}/${messageReference.discordMessageId}>)\n`
        : "") +
      parsedContent +
      userJoin +
      stickerMsg +
      (overAttachmentsStr
        ? "\n-# has attachments over 20mb: " + overAttachmentsStr
        : ""),
    // @ts-expect-error
    attachments,
    username: guildUser?.displayName ?? message.author.globalName ?? message.author.username,
    embeds: await fluxerEmbedToDiscord(
      forwardedMessage ?? message,
      discordClient,
    ),
    avatarURL: await getFluxerAvatarURL(message.author, guildUser),
    allowedMentions: {
      parse: ["roles", "users", ...(canUserPing ? ["everyone"] : [])],
    },
    ...(threadId ? { threadId } : {}),
  };

  let msg;
  if (speakerClient) {
    // the owner's bot (or this person's own bot) posts it as a real member.
    try {
      const channel = await speakerClient.channels.fetch(threadId ?? channelMap.discordChannelId);
      const replyTo = messageReference?.discordMessageId ?? null;
      const ownContent =
        (forwardedMessage ? "-# Forwarded message\n" : "") +
        parsedContent +
        userJoin +
        stickerMsg +
        (overAttachmentsStr ? "\n-# has attachments over 20mb: " + overAttachmentsStr : "");
      msg = await channel.send({
        content: ownContent || undefined,
        files: files.map((f) => ({ attachment: f.attachment, name: f.name, description: f.description })),
        embeds: webhookPayload.embeds,
        allowedMentions: webhookPayload.allowedMentions,
        ...(replyTo ? { reply: { messageReference: replyTo, failIfNotExists: false } } : {}),
      });
    } catch (e) {
      // Their bot isn't in that channel or can't post there: the usual way still works.
      log("MIRROR", `${speakerTwin?.name}'s Discord bot couldn't post in that channel (${e?.message ?? e}), so it went the usual way.`);
      msg = null;
    }
  }
  if (msg) {
    // sent above
  } else if (earlyDiscordMsgId) {
    try {
      msg = await webhook.editMessage(earlyDiscordMsgId, {
        ...webhookPayload,
        ...(threadId ? { threadId } : {}),
      });
    } catch (e) {
      log(
        "DISCORD",
        `Failed to edit early bridged Discord message ${earlyDiscordMsgId}`,
        e,
      );

      try {
        if (threadId) {
          await webhook.deleteMessage(earlyDiscordMsgId, threadId);
        } else {
          await webhook.deleteMessage(earlyDiscordMsgId);
        }
      } catch (e) {
        log(
          "DISCORD",
          `Failed to delete early bridged Discord message ${earlyDiscordMsgId}`,
          e,
        );
      }

      msg = await webhook.send(webhookPayload);
    }
  } else {
    msg = await webhook.send(webhookPayload);
  }

  resetBridgeHealth(guildId);

  log(
    "DEBUG",
    `FluxerCreate bridged fluxerId=${message.id} discordId=${msg.id} channelMapId=${channelMap.id} fileCount=${files.length} hasReply=${Boolean(messageReference)} hasThread=${Boolean(threadId)}`,
  );

  let bridgedMessageMap;
  try {
    bridgedMessageMap = await MessageMap.create({
      messageSource: "fluxer",
      discordMessageId: msg.id,
      fluxerMessageId: message.id,
      fluxerReplyId: message.messageReference?.messageId ?? null,
      discordReplyId: messageReference?.discordMessageId ?? null,
      channelMapId: channelMap.id,
      authorId: message.author.id,
    });
  } catch (e) {
    log("DB", "Failed to save Fluxer -> Discord message map", e);
  }

  const checkMsg = async () => {
    const channel = message.channel;
    if (channel?.isTextBased() && channel.messages) {
      try {
        await channel.messages.fetch(message.id);
      } catch (e) {
        if (isFluxerMessageNotFoundError(e)) {
          try {
            await msg.delete();
          } catch { }
          await bridgedMessageMap?.destroy();
          return;
        }

        log("FLUXER", "Source message fetch failed", e);
      }
    }
  };
  setTimeout(checkMsg, 1000);
  setTimeout(checkMsg, 2500);
  setTimeout(checkMsg, 5000);
}

/**
 * @param {FluxerMessage | null} oldMessage
 * @param {import("@fluxerjs/core").Message | import("@fluxerjs/core").PartialMessage} newMessage
 * @param {import("discord.js").Client} client
 */
export async function FluxerUpdateMessageHandler(
  oldMessage,
  newMessage,
  client,
) {
  log(
    "DEBUG",
    `FluxerUpdate received id=${newMessage.id} channelId=${newMessage.channelId} guildId=${newMessage.guildId} authorId=${newMessage.author?.id} partial=${Boolean(newMessage.partial)}`,
  );
  if (newMessage.partial) return;
  if (isMirrorFluxerId(newMessage.author?.id)) return;

  const channelMapViaUserId = await ChannelMap.findOne({
    where: {
      [Op.or]: {
        discordWebhookId: newMessage.author.id,
        fluxerWebhookId: newMessage.author.id,
      },
    },
  });

  if (channelMapViaUserId) return;

  const messageExisting = await MessageMap.findOne({
    where: {
      fluxerMessageId: newMessage.id,
    },
    include: ["channelMap"],
  });

  if (messageExisting) {
    const channelMap = messageExisting.channelMap;
    const webhook = await client.fetchWebhook(
      channelMap.discordWebhookId,
      channelMap.discordWebhookToken,
    );

    /** @type {import("../db/models/MessageMap.js").MessageMap | null} */
    let messageReference;
    if (newMessage.messageReference) {
      messageReference = await MessageMap.findOne({
        where: {
          [Op.or]: [
            {
              fluxerMessageId: newMessage.messageReference.messageId,
            },
            {
              discordMessageId: newMessage.messageReference.messageId,
            },
          ],
        },
      });

      if (
        messageReference &&
        messageReference.channelMapId !== messageExisting.channelMapId
      ) {
        messageReference = null;
      }
    }

    const canUserPing = await checkPingPerms(
      newMessage.guildId,
      newMessage.author.id,
      client,
    );

    const otherSideGuild = await client.guilds.fetch(channelMap.discordGuildId);

    const editContent =
      // @ts-expect-error
      (messageReference
        ? `-# <:reply_l:${fluxcordBotEmojiCfg.discordReplyEmoji.replyL}><:reply_r:${fluxcordBotEmojiCfg.discordReplyEmoji.replyR}> ${messageReference.messageSource === "discord" ? `<@${messageReference.authorId}>` : `@${newMessage.referencedMessage?.author.username}#${newMessage.referencedMessage?.author.discriminator}`}: [${await processReplyContent(newMessage.referencedMessage)}](<https://discord.com/channels/${channelMap.discordGuildId}/${channelMap.discordChannelId}/${messageReference.discordMessageId}>)\n`
        : "") +
      (await traverseMessageLinks(
        await parseFluxerEmojiToDiscord(
          await resolveMentions(
            otherSideGuild,
            sanitizePings(
              await parseMentions(
                newMessage,
                fluxerMentionsToDiscord(newMessage.content),
                otherSideGuild,
              ),
              canUserPing,
            ),
          ),
          client,
          channelMap.discordGuildId,
        ),
      ));
    const editDescs = newMessage.attachments
      .map((x) => ({ url: x.url ?? "", name: x.filename }))
      .filter((x) => x.url);
    const editFiles = [];
    for (const a of editDescs) {
      const data = await downloadFluxerAttachment(a.url);
      if (!data) continue;
      editFiles.push({ attachment: data, name: a.name });
    }

    const attachments =
      editFiles.length > 0
        ? await cloudUploadAttachments(
          client,
          channelMap.discordChannelId,
          editFiles,
        )
        : undefined;

    if (!editContent && !attachments?.length) {
      log("DEBUG", `FluxerUpdate skip id=${newMessage.id} reason=emptyEdit`);
      return;
    }

    const threadId = await resolveDiscordThreadId(
      client,
      channelMap.discordChannelId,
    );

    log(
      "DEBUG",
      `FluxerUpdate bridged fluxerId=${newMessage.id} discordId=${messageExisting.discordMessageId} channelMapId=${channelMap.id} fileCount=${editFiles.length} hasThread=${Boolean(threadId)}`,
    );

    try {
      await webhook.editMessage(messageExisting.discordMessageId, {
        content: editContent,
        attachments,
        ...(threadId ? { threadId } : {}),
      });
    } catch (e) {
      // the owner's messages are sent by the bot, so the bot edits them.
      const ch = await client.channels.fetch(threadId ?? channelMap.discordChannelId).catch(() => null);
      const own = await ch?.messages?.fetch(messageExisting.discordMessageId).catch(() => null);
      const sender = own?.author?.id === client.user?.id ? own : await twinsCopy(own);
      if (!sender) throw e;
      await sender.edit({ content: editContent });
    }
  }
}

/**
 * @param {import("@fluxerjs/core").PartialMessage} message
 * @param {import("discord.js").Client} client
 * @param {import("@fluxerjs/core").Client} fluxerClient
 */
export async function FluxerDeleteMessageHandler(
  message,
  client,
  fluxerClient,
) {
  log("DEBUG", `FluxerDelete received id=${message.id}`);
  const messageExisting = await MessageMap.findOne({
    where: {
      fluxerMessageId: message.id,
    },
    include: ["channelMap"],
  });

  if (messageExisting && !messageExisting.channelMap) {
    log(
      "FLUXER",
      `Message map ${messageExisting.id} for Fluxer message ${message.id} has no channel map`,
    );
    await messageExisting.destroy();
  } else if (messageExisting) {
    const channelMap = messageExisting.channelMap;

    try {
      if (messageExisting.messageSource === "discord") {
        const channel = await client.channels.fetch(
          channelMap.discordChannelId,
        );
        const discordMessage =
          await /** @type {import("discord.js").TextChannel} */ (
            channel
          ).messages.fetch(messageExisting.discordMessageId);
        await discordMessage.delete();
      } else {
        const webhook = await client.fetchWebhook(
          channelMap.discordWebhookId,
          channelMap.discordWebhookToken,
        );
        const threadId = await resolveDiscordThreadId(
          client,
          channelMap.discordChannelId,
        );
        try {
          if (threadId) {
            await webhook.deleteMessage(messageExisting.discordMessageId, threadId);
          } else {
            await webhook.deleteMessage(messageExisting.discordMessageId);
          }
        } catch (e) {
          // the owner's messages are sent by the bot, so the bot deletes them.
          const ch = await client.channels.fetch(threadId ?? channelMap.discordChannelId).catch(() => null);
          const own = await ch?.messages?.fetch(messageExisting.discordMessageId).catch(() => null);
          if (own?.author?.id === client.user?.id) await own.delete();
          else {
            const sender = await twinsCopy(own);
            if (!sender) throw e;
            await sender.delete().catch(async () => own.delete());
          }
        }
      }
    } catch (e) {
      if (!isDiscordUnknownMessageError(e)) {
        log(
          "DISCORD",
          `Failed to delete bridged Discord message ${messageExisting.discordMessageId} for Fluxer message ${message.id}`,
          e,
        );
        return;
      }
    }

    await messageExisting.destroy();
  }

  const replies = await MessageMap.findAll({
    where: {
      [Op.or]: {
        fluxerReplyId: message.id,
        discordReplyId:
          messageExisting?.discordMessageId ?? "THISSHOULDNOTMATCH",
      },
    },
    include: ["channelMap"],
  });

  if (replies.length > 0) {
    for (let reply of replies) {
      const channelMap = reply.channelMap;
      const webhook = await client.fetchWebhook(
        channelMap.discordWebhookId,
        channelMap.discordWebhookToken,
      );
      let replyContent = "";
      if (reply.messageSource === "fluxer") {
        let channel;
        try {
          channel = await fluxerClient.channels.fetch(
            channelMap.fluxerChannelId,
          );
        } catch {
          continue;
        }
        if (!channel || !channel.isTextBased()) continue;
        let message;
        try {
          message = await channel.messages.fetch(reply.fluxerMessageId);
        } catch {
          continue;
        }
        if (!message) continue;
        replyContent = message.content;
      } else {
        // native message
        continue;
      }

      await webhook.editMessage(reply.discordMessageId, {
        content: `-# <:reply_l:${fluxcordBotEmojiCfg.discordReplyEmoji.replyL}><:reply_r:${fluxcordBotEmojiCfg.discordReplyEmoji.replyR}> *Deleted message*
${replyContent}`,
      });
      reply.discordReplyId = null;
      reply.fluxerReplyId = null;
      await reply.save();
    }
  }
}

/**
 * @param {{ channelId: string; guildId?: string | null; ids: string[] }} msgs
 * @param {DiscordClient} client
 */
export async function FluxerBulkDeleteMessageHandler(msgs, client) {
  log(
    "DEBUG",
    `FluxerBulkDelete received channelId=${msgs.channelId} count=${msgs.ids.length}`,
  );
  const messagesExisting = await MessageMap.findAll({
    where: {
      fluxerMessageId: {
        [Op.in]: msgs.ids,
      },
    },
    include: ["channelMap"],
  });

  if (messagesExisting.length > 0) {
    try {
      const channel = /** @type {TextChannel} */ (
        await client.channels.fetch(
          messagesExisting[0]?.channelMap.discordChannelId ?? "",
        )
      );

      const reply = await channel.send({
        content: `Bridging bulk deletes, please wait...`,
      });

      try {
        await channel.bulkDelete(
          messagesExisting.map((x) => x.discordMessageId),
        );
      } catch { }

      await reply.delete();
    } catch { }

    await Promise.all(messagesExisting.map(async (x) => await x.destroy()));
  }
}

/**
 * @param {{ channelId: string }} chnl
 * @param {DiscordClient} client
 * @param {FluxerClient} fluxerClient
 */
export async function FluxerPinsUpdateHandler(chnl, client, fluxerClient) {
  log("DEBUG", `FluxerPinsUpdate received channelId=${chnl.channelId}`);
  const channelMap = await ChannelMap.findOne({
    where: {
      fluxerChannelId: chnl.channelId,
    },
  });

  if (
    channelMap &&
    (await resolveDiscordThreadId(client, channelMap.discordChannelId))
  ) {
    return;
  }

  if (channelMap) {
    const channel = /** @type {FluxerTextChannel} */ (
      await fluxerClient.channels.fetch(chnl.channelId)
    );

    if (channel) {
      const pinned = await channel.fetchPinnedMessages();

      const messages = await MessageMap.findAll({
        where: {
          fluxerMessageId: {
            [Op.in]: pinned.map((x) => x.id),
          },
        },
      });

      const discordChannel = await client.channels.fetch(
        channelMap.discordChannelId,
      );

      if (discordChannel && discordChannel.isTextBased()) {
        const discordPinned = await discordChannel.messages.fetchPins();

        const discordMessageBridgePinned = (
          await Promise.all(
            messages.map(
              async (x) =>
                await discordChannel.messages.fetch(x.discordMessageId),
            ),
          )
        ).filter(
          (x) => !discordPinned.items.find((y) => x.id === y.message.id),
        );

        const discordPinnedBridged = await MessageMap.findAll({
          where: {
            discordMessageId: {
              [Op.in]: discordPinned.items.map((x) => x.message.id),
            },
          },
        });

        const discordPinnedRemove = discordPinned.items
          .filter((x) =>
            discordPinnedBridged.find(
              (y) => y.discordMessageId === x.message.id,
            ),
          )
          .filter(
            (x) => !messages.find((y) => y.discordMessageId === x.message.id),
          );

        await Promise.all(
          discordPinnedRemove.map(async (x) => x.message.unpin()),
        );
        await Promise.all(discordMessageBridgePinned.map(async (x) => x.pin()));
      }
    }
  }
}
