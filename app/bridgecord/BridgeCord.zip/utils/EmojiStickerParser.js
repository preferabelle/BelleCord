import { log } from "./Logger.js";
import Config from "../utils/ConfigHandler.js";
import { ChannelMap, MessageMap } from "../db/index.js";
import { Op } from "sequelize";
import {
  getFluxEmojis,
  getDiscordEmojis,
  getBotEmojis,
  clearFluxEmojiCache,
  clearBotEmojiCache,
} from "./EmojiCache.js";
import { getFluxerMediaBaseUrl, getFluxerWebappUrl } from "./GetFluxerUrls.js";

/**
 * @param {string | null} content Message content
 * @param {FluxerClient} fluxerClient Fluxer client instance
 * @param {string | null} targetFluxerGuildId Target fluxer guild (emoji check)
 */
export async function parseDiscordEmojiToFluxer(
  content,
  fluxerClient,
  targetFluxerGuildId,
  attempt = 0,
) {
  if (!content) return content;

  const regex = /:(a?\d+):/g;
  const emojiIdNameMap = new Map();

  let result = content.replace(
    /<(a?):([\w\-\_]+):(\d+)>/g,
    (_, animated, name, id) => {
      emojiIdNameMap.set(`${animated}${id}`, name);
      return `:${animated}${id}:`;
    },
  );

  /** @type {Array<{ name: string, id: string }> | null} */
  let targetGuildEmojis = null;
  if (targetFluxerGuildId) {
    try {
      targetGuildEmojis = await getFluxEmojis(
        targetFluxerGuildId,
        fluxerClient,
      );
    } catch {
      targetGuildEmojis = null;
    }
  }

  /** @type {string[]} */
  const emojis = [];

  let m;
  while ((m = regex.exec(result)) !== null) {
    if (m.index === regex.lastIndex) {
      regex.lastIndex++;
    }

    if (m[1]) {
      if (!emojis.includes(m[1])) {
        emojis.push(m[1]);
        try {
          const sourceName = emojiIdNameMap.get(m[1]);
          if (sourceName && targetFluxerGuildId && targetGuildEmojis) {
            const byName = targetGuildEmojis.find((x) => x.name === sourceName);
            if (byName) {
              const mapped = await fluxerClient.resolveEmoji(
                `:${sourceName}:`,
                targetFluxerGuildId,
              );
              if (mapped) {
                result = result.replaceAll(`:${m[1]}:`, `<:${mapped}>`);
                continue;
              }
            }
          }

          const animated = m[1].startsWith("a");
          const rawId = animated ? m[1].slice(1) : m[1];

          if (!/^\d{17,19}$/.test(rawId)) continue;

          const emojiName = `e${m[1]}`;

          let existingEmojis = await getFluxEmojis(
            Config.FluxerTempEmojiGuildId,
            fluxerClient,
          );
          let existing = existingEmojis?.find((x) => x.name === emojiName);

          if (!existing) {
            const res = await fetch(
              "https://cdn.discordapp.com/emojis/" +
                rawId +
                (animated ? ".gif" : ".webp"),
            );
            if (!res.ok) continue;
            const buf = await res.arrayBuffer();

            const fluxerGuild = await fluxerClient.guilds.fetch(
              Config.FluxerTempEmojiGuildId,
            );
            await fluxerGuild?.createEmojisBulk([
              {
                image: btoa(
                  new Uint8Array(buf).reduce(
                    (data, byte) => data + String.fromCharCode(byte),
                    "",
                  ),
                ),
                name: emojiName,
              },
            ]);

            clearFluxEmojiCache(Config.FluxerTempEmojiGuildId);
            existingEmojis = await getFluxEmojis(
              Config.FluxerTempEmojiGuildId,
              fluxerClient,
            );
            existing = existingEmojis?.find((x) => x.name === emojiName);
          }

          const fluxerEmoji = await fluxerClient.resolveEmoji(
            `:${emojiName}:`,
            Config.FluxerTempEmojiGuildId,
          );

          result = result.replaceAll(
            `:${m[1]}:`,
            `<${fluxerEmoji.startsWith("a") ? "" : ":"}${fluxerEmoji}>`,
          );
        } catch (e) {
          if (attempt < 5) {
            log(
              "FLUXER",
              "Cannot convert Discord emoji to Fluxer, deleting 25 oldest emojis and trying again...",
              e,
            );
            const err = await deleteOldestEmojisFluxer(fluxerClient);
            if (err) attempt = 67;
            return await parseDiscordEmojiToFluxer(
              content,
              fluxerClient,
              targetFluxerGuildId,
              attempt + 1,
            );
          }
        }
      }
    }
  }

  return result;
}

/**
 * @param {string | null} content
 * @param {DiscordClient} discordClient
 * @param {string | null} targetDiscordGuildId
 */
export async function parseFluxerEmojiToDiscord(
  content,
  discordClient,
  targetDiscordGuildId,
  attempt = 0,
) {
  if (!content) return content;
  const regex = /:(a?\d+):/g;
  const emojiIdNameMap = new Map();

  let result = content.replace(
    /<(a?):([\w\-\_]+):(\d+)>/g,
    (_, animated, name, id) => {
      emojiIdNameMap.set(`${animated}${id}`, name);
      return `:${animated}${id}:`;
    },
  );
  result = result.replace(/:e(a?\d+):/g, ":$1:");

  /** @type {string[]} */
  const emojis = [];

  /** @type {Array<{ name: string, id: string }> | null} */
  let targetGuildEmojis = null;
  if (targetDiscordGuildId) {
    try {
      targetGuildEmojis = await getDiscordEmojis(
        targetDiscordGuildId,
        discordClient,
      );
    } catch {
      targetGuildEmojis = null;
    }
  }

  let cachedEmojis = await getBotEmojis(discordClient);

  let m;
  while ((m = regex.exec(result)) !== null) {
    if (m.index === regex.lastIndex) {
      regex.lastIndex++;
    }

    if (m[1]) {
      if (!emojis.includes(m[1])) {
        emojis.push(m[1]);
        try {
          const sourceName = emojiIdNameMap.get(m[1]);
          if (sourceName && targetGuildEmojis) {
            const byName = targetGuildEmojis.find((x) => x.name === sourceName);
            if (byName) {
              result = result.replaceAll(
                `:${m[1]}:`,
                `<${m[1].startsWith("a") ? "a" : ""}:${sourceName}:${byName.id}>`,
              );
              continue;
            }
          }

          const emojiName = `e${m[1]}`;

          let existingEmoji = [...cachedEmojis.values()].find(
            (x) => x.name === emojiName,
          );

          const mediaUrl = await getFluxerMediaBaseUrl();
          if (!existingEmoji) {
            const res = await fetch(
              mediaUrl +
                "/emojis/" +
                m[1].replace("a", "") +
                ".webp?animated=" +
                (m[1].startsWith("a") ? "true" : "false") +
                "&size=240&quality=lossless",
            );
            const arrBuf = await res.arrayBuffer();
            const buf = Buffer.from(arrBuf);

            const created = await discordClient.application?.emojis.create({
              attachment: buf,
              name: emojiName,
            });

            clearBotEmojiCache();
            if (created)
              existingEmoji = { name: created.name ?? "", id: created.id };
          }

          result = result.replaceAll(
            `:${m[1]}:`,
            `<${m[1].startsWith("a") ? "a" : ""}:${emojiName}:${existingEmoji?.id}>`,
          );
        } catch (e) {
          if (attempt < 5) {
            log(
              "DISCORD",
              "Cannot convert Fluxer emoji to Discord, deleting 25 oldest emojis and trying again...",
              e,
            );
            await deleteOldestEmojisDiscord(discordClient);
            return await parseFluxerEmojiToDiscord(
              content,
              discordClient,
              targetDiscordGuildId,
              attempt + 1,
            );
          }
        }
      }
    }
  }

  return result;
}

/**
 * @param {string} str
 * @returns {string}
 */
export function removeLinkEmbeds(str) {
  const regex =
    /(https?:\/\/(www\.)?[-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b(\([-a-zA-Z0-9@:%_+.~#?&/=]*\)|[-a-zA-Z0-9@:%_+.~#?&/=])*)/g;
  return str.replace(regex, "<$1>");
}

/**
 * @param {string} str
 * @returns {string}
 */
export function sanitizeLinks(str) {
  return str.replace(
    /https?:\/\/[^\s]+/g,
    (url) => `*${new URL(url).hostname}*`,
  );
}

/**
 * @param {string} str
 * @returns {Promise<string>}
 */
export async function traverseMessageLinks(str) {
  let result = str;

  const webAppUrl = await getFluxerWebappUrl();
  const webApp = new URL(webAppUrl);
  const regex = new RegExp(
    `https://(discord\\.com|(?:web.)?(?:canary.)?fluxer.app|${webApp.hostname.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")})/channels/(\\d+)/(\\d+)(?:/(\\d+))?`,
    "g",
  );

  let m;
  while ((m = regex.exec(result)) !== null) {
    if (m.index === regex.lastIndex) {
      regex.lastIndex++;
    }

    try {
      if (m[1] && m[2] && m[3]) {
        if (m[4]) {
          const message = await MessageMap.findOne({
            where: {
              [Op.or]: {
                discordMessageId: m[4],
                fluxerMessageId: m[4],
              },
            },
            include: ["channelMap"],
          });
          if (message) {
            if (!m[1].includes("discord.com")) {
              result = result.replaceAll(
                m[0],
                `https://discord.com/channels/${message.channelMap.discordGuildId}/${message.channelMap.discordChannelId}/${message.discordMessageId}`,
              );
            } else {
              result = result.replaceAll(
                m[0],
                `${webAppUrl}/channels/${message.channelMap.fluxerGuildId}/${message.channelMap.fluxerChannelId}/${message.fluxerMessageId}`,
              );
            }
          }
        } else {
          const channel = await ChannelMap.findOne({
            where: {
              [Op.or]: {
                discordChannelId: m[3],
                fluxerChannelId: m[3],
              },
            },
          });
          if (channel) {
            if (m[1].startsWith("fluxer")) {
              result = result.replaceAll(
                m[0],
                `https://discord.com/channels/${channel.discordGuildId}/${channel.discordChannelId}`,
              );
            } else {
              result = result.replaceAll(
                m[0],
                `${webAppUrl}/channels/${channel.fluxerGuildId}/${channel.fluxerChannelId}`,
              );
            }
          }
        }
      }
    } catch {}
  }

  return result;
}

/**
 * @param {FluxerClient} fluxerClient
 */
async function deleteOldestEmojisFluxer(fluxerClient) {
  const guild = await fluxerClient.guilds.fetch(Config.FluxerTempEmojiGuildId);
  if (guild) {
    try {
      let emojis = await guild.fetchEmojis();
      emojis = emojis.filter(
        (x) => !x.name.startsWith("reply") && x.name !== "loading",
      );
      emojis = emojis.slice(-26, -1);

      await Promise.all(
        emojis.map(async (x) => {
          log("DEBUG", `Attempting to delete emoji ID ${x.id} (${x.name})...`);
          await x.delete();
        }),
      );
    } catch (e) {
      log("FLUXER", "Cannot delete oldest emojis on Fluxer: " + e);
      return true;
    }
    clearFluxEmojiCache(Config.FluxerTempEmojiGuildId);
  }
}

/**
 * @param {import("discord.js").Client} discordClient
 */
async function deleteOldestEmojisDiscord(discordClient) {
  let app = await discordClient.application?.fetch();
  if (app) {
    let emojis = (await app.emojis.fetch()).filter(
      (x) => !x.name.startsWith("reply") && x.name !== "loading",
    );
    let i = 0;
    for (let emoji of emojis.reverse().values()) {
      if (i > 25) break;
      log(
        "DEBUG",
        `Attempting to delete emoji ID ${emoji.id} (${emoji.name})...`,
      );
      await emoji?.delete();
      i++;
    }
    clearBotEmojiCache();
  }
}
