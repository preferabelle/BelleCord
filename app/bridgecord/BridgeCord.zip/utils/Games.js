// games with the bot.
// Rock paper scissors (single player, keeps your record) and trivia (everyone in
// the channel, on Fluxer and Discord). Records live in data/games.json.
import { forPlatform } from "./Output.js";
import { reaction } from "./Output.js";
import { moodify } from "./Output.js";
import fs from "node:fs";
import { randomInt } from "node:crypto";
import path from "node:path";
import { Message as FluxerMessage, Routes as FluxerRoutes } from "@fluxerjs/core";
import { ChannelMap } from "../db/index.js";
import Config from "./ConfigHandler.js";
import { log } from "./Logger.js";
import { keyOf, nameOf } from "./People.js";
import { getMirrorByDiscordId } from "./Mirrors.js";
import { BANK, CATEGORIES } from "./TriviaBank.js";
import { botSend } from "./BotOnDiscord.js";
import { chatGameMessage, chatGameRunning, setChatGameAnnouncer } from "./ChatGames.js";

const FILE = path.join(Config.DataFolderPath, "games.json");
let data = { rps: {}, trivia: {} };
try { data = { ...data, ...JSON.parse(fs.readFileSync(FILE, "utf-8")) }; } catch {}
const save = () => { try { fs.writeFileSync(FILE, JSON.stringify(data)); } catch {} };

let discord = null, fluxer = null;
export function attachGames(discordClient, fluxerClient) {
  discord = discordClient;
  fluxer = fluxerClient;
}

/** One identity per person, whichever side they typed on (matches how Fluxer sees them). */
export function playerOf(message) {
  if (message instanceof FluxerMessage) return { key: keyOf(message), name: nameOf(message) };
  const a = message.author ?? {};
  let member = null;
  try { member = message.member ?? null; } catch {}
  const shown = member?.displayName ?? a.globalName ?? a.username ?? "someone";
  const mirror = getMirrorByDiscordId(a.id);
  return { key: mirror?.fluxerId ?? `wh:${shown}`, name: shown };
}

// ---------------- rock paper scissors ----------------
const MOVES = { rock: "rock", r: "rock", paper: "paper", p: "paper", scissors: "scissors", scissor: "scissors", s: "scissors" };
const BEATS = { rock: "scissors", paper: "rock", scissors: "paper" };
const SAY = {
  win: ["You win!", "Nice one, you win.", "You got me. You win."],
  lose: ["I win.", "I win this round.", "Better luck next time."],
  tie: ["It's a tie.", "Same pick. It's a tie.", "Tie! Go again?"],
};
const any = (a) => a[randomInt(a.length)];
const lastPicks = new Map(); // player -> the bot's last two picks, so it never picks the same thing 3 times in a row

export function playRps(player, word) {
  const you = MOVES[String(word ?? "").toLowerCase()];
  if (!you) return null;
  const recent = lastPicks.get(player.key) ?? [];
  let options = ["rock", "paper", "scissors"];
  if (recent.length === 2 && recent[0] === recent[1]) options = options.filter((m) => m !== recent[0]);
  const me = any(options);
  lastPicks.set(player.key, [recent.at(-1), me].filter(Boolean));
  const result = you === me ? "tie" : BEATS[you] === me ? "win" : "lose";
  const rec = (data.rps[player.key] ??= { name: player.name, w: 0, l: 0, t: 0, streak: 0 });
  rec.name = player.name;
  if (result === "win") { rec.w++; rec.streak = Math.max(1, rec.streak + 1); }
  if (result === "lose") { rec.l++; rec.streak = Math.min(-1, rec.streak - 1); }
  if (result === "tie") rec.t++;
  save();
  const streak = Math.abs(rec.streak) >= 3 ? ` (${Math.abs(rec.streak)} ${rec.streak > 0 ? "wins" : "losses"} in a row)` : "";
  // (a custom reaction line for wins and losses, if there is one; otherwise a stock line)
  const skinSays = result === "win" ? reaction("win", player.name) : result === "lose" ? reaction("fail") : null;
  return `I picked **${me}**. ${skinSays ?? any(SAY[result])}\n-# Your record: ${recordText(rec)}${streak}`;
}

const count = (n, one, many) => `${n} ${n === 1 ? one : many}`;
export const recordText = (r) => `${count(r.w, "win", "wins")}, ${count(r.l, "loss", "losses")}, ${count(r.t, "tie", "ties")}`;

export function recordOf(player) {
  return { rps: data.rps[player.key] ?? null, trivia: data.trivia[player.key] ?? null };
}

export function leaderboard() {
  const rps = Object.values(data.rps).filter((r) => r.w + r.l > 0).sort((a, b) => b.w - a.w || a.l - b.l).slice(0, 5);
  const trivia = Object.values(data.trivia).sort((a, b) => b.pts - a.pts).slice(0, 5);
  return { rps, trivia };
}

// ---------------- trivia ----------------
const NICKNAMES = { ow: "overwatch", ow2: "overwatch", mc: "minecraft", rbx: "roblox", general: "general", web: "online", internet: "online" };
/** Online: Open Trivia DB. Only these categories, so no movie/TV/anime/comic spoilers:
 * 9 general knowledge, 15 video games, 17 science & nature, 22 geography. */
const ONLINE_CATEGORIES = [9, 15, 17, 22];

export function triviaCategory(word) {
  const w = String(word ?? "").toLowerCase();
  if (!w || w === "mix" || w === "all") return "mix";
  if (w === "online") return "online";
  if (CATEGORIES.includes(w)) return w;
  return NICKNAMES[w] ?? null;
}

const shuffle = (a) => { const b = [...a]; for (let i = b.length - 1; i > 0; i--) { const j = randomInt(i + 1); [b[i], b[j]] = [b[j], b[i]]; } return b; };

async function onlineQuestions(n) {
  const cat = ONLINE_CATEGORIES[randomInt(ONLINE_CATEGORIES.length)];
  const res = await fetch(`https://opentdb.com/api.php?amount=${n}&type=multiple&encode=url3986&category=${cat}`, { signal: AbortSignal.timeout(8000) });
  const json = await res.json();
  if (json.response_code !== 0 || !json.results?.length) throw new Error(`Open Trivia DB said ${json.response_code}`);
  return json.results.map((r) => {
    const d = decodeURIComponent;
    const correct = d(r.correct_answer);
    const choices = shuffle([correct, ...r.incorrect_answers.map(d)]);
    const letter = "abcd"[choices.indexOf(correct)];
    return { q: d(r.question), answers: [correct, letter], choices, shown: `${letter.toUpperCase()}) ${correct}` };
  });
}

async function pickQuestions(category, n) {
  if (category === "online") {
    try { return { list: await onlineQuestions(n), note: "" }; }
    catch (e) {
      log("META", "Online trivia failed:", e?.message ?? e);
      category = "mix";
      var note = " (The trivia website isn't answering, so these are mine.)";
    }
  }
  const pool = category === "mix" ? CATEGORIES.flatMap((c) => BANK[c]) : BANK[category];
  const list = shuffle(pool).slice(0, n).map(([q, answers]) => ({ q, answers, shown: answers[0] }));
  return { list, note: note ?? "" };
}

const ROUNDS = 5;
/** Seconds per question and between questions (adjustable for tests). */
export const timing = { answer: 20_000, gap: 4_000 };
const norm = (s) => String(s ?? "").toLowerCase().replace(/[^a-z0-9 ]/g, "").replace(/\s+/g, " ").trim();

/** @type {Map<string, any>} Fluxer channel id -> running game */
const games = new Map();

export async function announce(fluxerChannelId, text) {
  // Each side says it. `text` can be a function, so lines that are picked
  // (like who it cheers for) are picked separately for each side.
  const said = (platform) => forPlatform(platform, () => moodify(typeof text === "function" ? text() : text));
  try {
    const ch = await fluxer.channels.fetch(fluxerChannelId);
    await ch?.send({ content: said("fluxer") });
  } catch (e) { log("META", "Trivia post failed:", e?.message ?? e); }
  if (!discord?.isReady?.()) return;
  try {
    const map = await ChannelMap.findOne({ where: { fluxerChannelId }, raw: true });
    if (!map || map.bridgeType === "discord2fluxer") return;
    const ch = await discord.channels.fetch(map.discordChannelId);
    if (ch) await botSend(ch, said("discord"));
  } catch (e) { log("META", "Trivia post on Discord failed:", e?.message ?? e); }
}

/** Find the Fluxer channel a trivia game should live in. */
export async function triviaChannelFor(message) {
  if (message instanceof FluxerMessage) return message.channelId;
  const map = await ChannelMap.findOne({ where: { discordChannelId: message.channelId }, raw: true });
  return map?.fluxerChannelId ?? null;
}

export function triviaRunning(fluxerChannelId) {
  return games.has(fluxerChannelId) || chatGameRunning(fluxerChannelId);
}

export async function startTrivia(fluxerChannelId, starterName, category = "mix") {
  const game = { pool: [], round: -1, open: false, got: new Set(), first: false, scores: new Map(), timer: null, discordChannelId: null };
  games.set(fluxerChannelId, game); // claim the channel before the (maybe slow) online fetch
  const map = await ChannelMap.findOne({ where: { fluxerChannelId }, raw: true }).catch(() => null);
  game.discordChannelId = map?.discordChannelId ?? null;
  const { list, note } = await pickQuestions(category, ROUNDS);
  if (games.get(fluxerChannelId) !== game) return; // stopped while loading
  game.pool = list;
  const topic = { mix: "", online: " (online questions, pick A, B, C, or D)" }[category] ?? ` (${category})`;
  announce(fluxerChannelId, `**TRIVIA${topic}.** ${starterName} started a game. ${list.length} questions, ${timing.answer / 1000} seconds each. Just type your answer. First right answer gets 2 points, everyone else who gets it gets 1.${note}`);
  game.timer = setTimeout(() => nextQuestion(fluxerChannelId), timing.gap);
}

function nextQuestion(ch) {
  const game = games.get(ch);
  if (!game) return;
  game.round++;
  if (game.round >= game.pool.length) return finish(ch);
  game.got = new Set();
  game.first = false;
  game.open = true;
  const cur = game.pool[game.round];
  const options = cur.choices ? "\n" + cur.choices.map((c, i) => `${"ABCD"[i]}) ${c}`).join("   ") : "";
  announce(ch, `**Question ${game.round + 1}/${game.pool.length}:** ${cur.q}${options}`);
  game.timer = setTimeout(() => closeQuestion(ch), timing.answer);
}

function closeQuestion(ch) {
  const game = games.get(ch);
  if (!game) return;
  game.open = false;
  const cur = game.pool[game.round];
  const winners = [...game.got].map((k) => game.scores.get(k)?.name).filter(Boolean);
  const said = () => (winners.length ? `Got it: ${winners.join(", ")}.` : reaction("fail") ?? "Game over.");
  announce(ch, () => `Time! It was **${cur.shown}**. ${said()}`);
  game.timer = setTimeout(() => nextQuestion(ch), timing.gap);
}

function finish(ch) {
  const game = games.get(ch);
  games.delete(ch);
  const board = [...game.scores.entries()].sort((a, b) => b[1].pts - a[1].pts);
  if (!board.length) return announce(ch, "Game over. Nobody scored this time.");
  board.forEach(([key, s], i) => {
    const life = (data.trivia[key] ??= { name: s.name, pts: 0, wins: 0 });
    life.name = s.name;
    life.pts += s.pts;
    if (i === 0) life.wins++;
  });
  save();
  const lines = board.map(([, s], i) => `${i + 1}. ${s.name}: ${s.pts}`).join("\n");
  announce(ch, () => `**Game over.**\n${lines}\n${board[0][1].name} wins. ${reaction("win", board[0][1].name) ?? "Well played!"}`);
}

export function stopTrivia(fluxerChannelId) {
  const game = games.get(fluxerChannelId);
  if (!game) return false;
  clearTimeout(game.timer);
  games.delete(fluxerChannelId);
  return true;
}

function isRight(game, text) {
  const guess = norm(text);
  return !!guess && game.pool[game.round].answers.some((a) => norm(a) === guess);
}

/** Score a right answer, and say who got it (without the answer) on both sides. */
function award(fluxerChannelId, game, key, name) {
  if (game.got.has(key)) return;
  game.got.add(key);
  const s = game.scores.get(key) ?? { name, pts: 0 };
  const first = !game.first;
  s.pts += first ? 2 : 1;
  game.first = true;
  game.scores.set(key, s);
  announce(fluxerChannelId, `✅ **${name}** got it${first ? " first" : ""}!`);
}

/**
 * Every Fluxer message passes through here. A right answer is deleted and NOT bridged,
 * so nobody can copy it. Returns true when the message was a right answer (skip bridging).
 */
export function noteGameMessage(msg) {
  // Scramble / hangman / would-you-rather guesses (they stay visible, so no need to hide them).
  if (msg.content && msg.author?.id !== fluxer?.user?.id) chatGameMessage(msg.channelId, msg.content, { key: keyOf(msg), name: nameOf(msg) });
  const game = games.get(msg.channelId);
  if (!game?.open || !msg.content || msg.author?.id === fluxer?.user?.id) return false;
  if (!isRight(game, msg.content)) return false;
  fluxer?.rest?.delete(FluxerRoutes.channelMessage(msg.channelId, msg.id), { auth: true }).catch(() => {});
  award(msg.channelId, game, keyOf(msg), nameOf(msg));
  return true;
}

/**
 * Every Discord message in a bridged channel passes through here first. A right answer is
 * deleted on Discord and never reaches Fluxer. Returns true when it was a right answer.
 */
export function noteDiscordGameMessage(msg) {
  if (!msg.content || msg.author?.bot) return false;
  for (const [fluxerChannelId, game] of games) {
    if (game.discordChannelId !== msg.channelId || !game.open) continue;
    if (!isRight(game, msg.content)) return false;
    msg.delete?.().catch(() => {});
    const player = playerOf(msg);
    award(fluxerChannelId, game, player.key, player.name);
    return true;
  }
  return false;
}

// chat games (scramble, hangman, would you rather) announce the same way trivia does.
setChatGameAnnouncer((ch, text) => announce(ch, text));
