// voice bridging between one Fluxer voice channel and one Discord voice channel.
//
//  Fluxer side  (LiveKit room, joined by Hangout.js as the bridge bot):
//     - hears each Fluxer person separately            -> "f2d" mixer -> plays on Discord
//     - publishes one audio track: everyone on Discord <- "d2f" mixer
//  Discord side (the main Discord bot, @discordjs/voice with DAVE encryption):
//     - hears each Discord person separately            -> "d2f" mixer -> plays on Fluxer
//     - plays one stream: everyone on Fluxer            <- "f2d" mixer
//
// Bots are never relayed (so Fluxcord's own voice bot can't create an echo loop).
import { Readable } from "node:stream";
import prism from "prism-media";
import {
  EndBehaviorType,
  NoSubscriberBehavior,
  StreamType,
  VoiceConnectionStatus,
  AudioPlayerStatus,
  createAudioPlayer,
  createAudioResource,
  entersState,
  joinVoiceChannel,
} from "@discordjs/voice";
import { log } from "./Logger.js";
import { CHANNELS, FRAME, FRAME_SAMPLES, Mixer, RATE, toStereo } from "./AudioMixer.js";
import { isMirrorVoice, sendToMirror } from "./VoicePresence.js";
import { applyLevel, getLevel } from "./VoiceLevels.js";
import { isTwinBot, leaveAllTwins, sendToTwin, setTwinVoiceTarget, twinFlags, twinJoin, twinLeave, twinVoiceStatus } from "./TwinVoice.js";

/** Swappable for tests. */
export const deps = {
  livekit: () => import("@livekit/rtc-node"),
};

const FRAME_BYTES = FRAME_SAMPLES * 2;
const SILENT_FRAME = Buffer.alloc(FRAME_BYTES);
const CUSHION_FRAMES = 5; // 100 ms head start, so Discord's player never finds the stream empty mid-sentence
const OUT_HANGOVER_MS = 3000; // keep one steady stream through pauses between sentences (fewer encryption restarts)

export const state = {
  active: false,
  discordClient: null,
  fluxerClient: null,
  /** @type {{guildId: string, channelId: string, name: string} | null} */
  target: null,
  conn: null,
  player: null,
  out: null,
  f2d: null,
  d2f: null,
  lk: null,
  room: null,
  source: null,
  track: null,
  pendingCaptures: 0,
  discordSubs: new Map(),
  fluxerStreams: new Map(),
  botCache: new Map(),
  rejoinTimer: null,
  retries: 0,
  lastDiscordError: null,
  lastFluxerError: null,
  counts: { toDiscord: 0, toFluxer: 0 },
  outQueue: [],
  outPlaying: false,
  lastRealOut: 0,
  discordStarts: 0,
  voiceLog: [],
  sweepTimer: null,
  watchdogTimer: null,
  errorTimes: [],
  speakingAt: new Map(),
  decodedAt: new Map(),
  stuckChecks: 0,
  heals: 0,
};

/** Remember what Discord's voice connection says about encryption, for bb!voice status. */
function note(line) {
  state.voiceLog.push(`${new Date().toLocaleTimeString()} ${line}`.slice(0, 180));
  if (state.voiceLog.length > 8) state.voiceLog.shift();
}

/** Node Buffer -> Int16Array (copying if the memory isn't 2-byte aligned). */
function toInt16(buf) {
  if (buf.byteOffset % 2 === 0) return new Int16Array(buf.buffer, buf.byteOffset, buf.byteLength >> 1);
  const copy = new Int16Array(buf.byteLength >> 1);
  Buffer.from(copy.buffer).set(buf);
  return copy;
}

function ensureMixers() {
  if (state.f2d) return;
  // Fluxer voices -> Discord: push into the stream the Discord audio player reads.
  state.f2d = new Mixer((frame) => {
    if (!state.out) return;
    const buf = Buffer.from(frame.buffer, frame.byteOffset, frame.byteLength);
    state.lastRealOut = Date.now();
    state.counts.toDiscord++;
    if (!state.outPlaying) {
      // Build a small head start before Discord's player begins reading.
      state.outQueue.push(buf);
      if (state.outQueue.length >= CUSHION_FRAMES) {
        wakePlayer(); // the player may have stopped while it was quiet
        state.outPlaying = true;
        state.discordStarts++;
        for (const b of state.outQueue.splice(0)) state.out.push(b);
      }
      return;
    }
    if (state.out.readableLength > FRAME_BYTES * 15) return; // Discord isn't keeping up: drop, don't lag
    state.out.push(buf);
  }, { primeFrames: 3, graceFrames: 2 });
  // Nobody talking this 20 ms: during a short pause keep the stream going with silence,
  // after a longer one let it stop (so the bot doesn't look like it's talking forever).
  state.f2d.onSilence = () => {
    if (!state.out) return;
    if (!state.outPlaying) {
      if (state.outQueue.length) { wakePlayer(); for (const b of state.outQueue.splice(0)) state.out.push(b); state.outPlaying = true; state.discordStarts++; }
      return;
    }
    if (Date.now() - state.lastRealOut < OUT_HANGOVER_MS) {
      if (state.out.readableLength < FRAME_BYTES * 8) state.out.push(SILENT_FRAME);
    } else {
      state.outPlaying = false;
    }
  };
  // Discord voices -> Fluxer: feed the audio track the bridge bot publishes in the room.
  state.d2f = new Mixer((frame) => {
    if (!state.source || !state.lk) return;
    if (state.pendingCaptures > 25) return; // Fluxer isn't keeping up: drop, don't lag
    state.pendingCaptures++;
    state.source
      .captureFrame(new state.lk.AudioFrame(frame, RATE, CHANNELS, FRAME))
      .catch((e) => (state.lastFluxerError = e?.message ?? String(e)))
      .finally(() => state.pendingCaptures--);
    state.counts.toFluxer++;
  }, { primeFrames: 5, graceFrames: 3 }); // Discord voices arrive bumpier over the internet
  state.f2d.start();
  state.d2f.start();
}

// ---------------------------------------------------------------- Discord side

/**
 * Is the Discord audio player still running? After a few seconds with nothing to play it
 * stops for good (that's how the voice library works), so a quiet spell would otherwise leave
 * the next person who speaks unheard on Discord until a restart.
 */
function playerAlive() {
  const st = state.player?.state?.status;
  return st === AudioPlayerStatus.Playing || st === AudioPlayerStatus.Buffering;
}
/** Speech is starting: make sure there's a running player to hear it. */
function wakePlayer() {
  if (playerAlive()) return;
  state.playerRestarts = (state.playerRestarts ?? 0) + 1;
  note("Discord player had stopped during a quiet spell; started a fresh one");
  makePlayer();
}

function makePlayer() {
  state.out?.destroy();
  state.out = new Readable({ read() {} });
  const resource = createAudioResource(state.out, { inputType: StreamType.Raw });
  if (!state.player) {
    state.player = createAudioPlayer({ behaviors: { noSubscriber: NoSubscriberBehavior.Play, maxMissedFrames: 250 } });
    state.player.on("error", (e) => {
      log("META", "Voice bridge: Discord audio player error, restarting it:", e?.message ?? e);
      if (state.active) setTimeout(makePlayer, 1000);
    });
  }
  state.player.play(resource);
}

function isDiscordBot(userId) {
  if (userId === state.discordClient?.user?.id) return true;
  const user = state.discordClient?.users?.cache?.get(userId);
  const member = state.discordClient?.guilds?.cache?.get(state.target?.guildId)?.members?.cache?.get(userId);
  return !!(user?.bot || member?.user?.bot || isTwinBot(userId));
}

export function listenToDiscordUser(userId) {
  if (!state.conn || state.discordSubs.has(userId) || isDiscordBot(userId)) return;
  const opus = state.conn.receiver.subscribe(userId, { end: { behavior: EndBehaviorType.AfterSilence, duration: 1000 } });
  const decoder = new prism.opus.Decoder({ rate: RATE, channels: CHANNELS, frameSize: FRAME });
  const key = `d${userId}`;
  let finished = false;
  const finish = () => {
    if (finished) return;
    finished = true;
    state.discordSubs.delete(userId);
    opus.destroy();
    decoder.destroy();
  };
  opus.on("error", (e) => {
    state.lastDiscordError = `hearing a Discord user: ${e?.message ?? e}`;
    state.errorTimes.push(Date.now());
    finish();
  });
  decoder.on("error", () => {}); // one bad packet: skip it
  opus.once("end", finish);
  opus.once("close", finish);
  opus.pipe(decoder);
  decoder.on("data", (buf) => {
    state.decodedAt.set(userId, Date.now());
    const level = getLevel("discord", userId);
    // Their own mirror speaks for them if it's in the call (and clears itself when muted);
    // otherwise the bridge bot does, and a muted person is simply dropped.
    const samples = level > 0 ? applyLevel(toInt16(buf), level) : toInt16(buf);
    if (sendToMirror(userId, samples, level)) return;
    if (level === 0) return;
    state.d2f?.push(key, samples);
  });
  state.discordSubs.set(userId, { opus, decoder });
}

function scheduleDiscordRejoin(reason) {
  if (!state.active) return;
  clearTimeout(state.rejoinTimer);
  state.retries++;
  const wait = Math.min(60_000, 5000 * state.retries);
  state.lastDiscordError = reason;
  log("META", `Voice bridge: Discord voice dropped (${reason}). Rejoining in ${wait / 1000}s.`);
  state.rejoinTimer = setTimeout(() => joinDiscord().catch((e) => scheduleDiscordRejoin(e?.message ?? String(e))), wait);
}

async function joinDiscord() {
  if (!state.active || !state.target || !state.discordClient?.isReady?.()) return;
  const guild = state.discordClient.guilds.cache.get(state.target.guildId);
  if (!guild) throw new Error("the bot isn't in that Discord server");
  for (const sub of state.discordSubs.values()) sub.opus.destroy();
  state.discordSubs.clear();
  const conn = joinVoiceChannel({
    channelId: state.target.channelId,
    guildId: state.target.guildId,
    adapterCreator: guild.voiceAdapterCreator,
    selfDeaf: false,
    selfMute: false,
    daveEncryption: true,
    decryptionFailureTolerance: 48,
  });
  state.conn = conn;
  conn.on("error", (e) => {
    state.lastDiscordError = e?.message ?? String(e);
    note(`error: ${state.lastDiscordError}`);
  });
  conn.on("debug", (m) => {
    if (/dave|decrypt|encrypt|epoch|transition|mls/i.test(String(m))) note(String(m));
  });
  conn.on("stateChange", (a, b) => {
    if (a.status !== b.status) note(`connection: ${a.status} -> ${b.status}`);
  });
  conn.on(VoiceConnectionStatus.Disconnected, async () => {
    try {
      // Moving channels or a blip: Discord usually reconnects by itself within a few seconds.
      await Promise.race([
        entersState(conn, VoiceConnectionStatus.Signalling, 5000),
        entersState(conn, VoiceConnectionStatus.Connecting, 5000),
      ]);
    } catch {
      if (state.conn === conn) {
        conn.destroy();
        scheduleDiscordRejoin("disconnected");
      }
    }
  });
  conn.on(VoiceConnectionStatus.Destroyed, () => {
    if (state.conn === conn) {
      state.conn = null;
      scheduleDiscordRejoin("connection closed");
    }
  });
  await entersState(conn, VoiceConnectionStatus.Ready, 30_000);
  state.retries = 0;
  state.lastDiscordError = null;
  if (!state.player || !state.out) makePlayer();
  conn.subscribe(state.player);
  conn.receiver.speaking.on("start", (userId) => {
    if (!isDiscordBot(userId)) state.speakingAt.set(userId, Date.now());
    listenToDiscordUser(userId);
  });
  log("META", `Voice bridge: joined ${state.target.name} on Discord.`);
  // If a moderator server-muted the bot, Discord people hear nothing from Fluxer. Undo it.
  setTimeout(() => unmuteSelf(guild).catch(() => {}), 2000);
}

/** Make sure the Discord bot isn't server-muted or suppressed in the Discord call. */
export async function unmuteSelf(guild) {
  const voice = guild?.members?.me?.voice;
  if (!voice?.channelId) return;
  if (voice.serverMute) {
    note("the bot was server-muted on Discord, unmuting it");
    state.lastDiscordError = "the bot was server-muted on Discord (so nobody heard Fluxer). I unmuted it.";
    await voice.setMute(false, "The voice bridge needs to be heard").catch((e) => {
      state.lastDiscordError = `the bot is server-muted on Discord and I couldn't unmute it (${e?.message ?? e}). A Discord moderator has to unmute it.`;
    });
  }
  if (voice.suppress) await voice.setSuppressed(false).catch(() => {});
}

/** A short chime on both sides, so each side can check it hears the bridge. */
export function playTestTone() {
  ensureMixers();
  const notes = [660, 880, 990];
  let k = 0;
  const timer = setInterval(() => {
    if (k >= 60) return clearInterval(timer); // 60 frames = 1.2 s
    const freq = notes[Math.floor(k / 20)];
    const frame = new Int16Array(FRAME_SAMPLES);
    for (let i = 0; i < FRAME; i++) {
      const v = Math.round(6000 * Math.sin((2 * Math.PI * freq * (k * FRAME + i)) / RATE));
      frame[2 * i] = v;
      frame[2 * i + 1] = v;
    }
    state.f2d?.push("test", frame); // -> Discord
    state.d2f?.push("test", frame); // -> Fluxer (through the bridge bot)
    k++;
  }, 20);
}

// ---------------------------------------------------------------- Fluxer side

async function isFluxerBot(participant) {
  const id = String(participant?.identity ?? "").match(/\d{15,21}/)?.[0];
  if (!id) return false;
  if (id === state.fluxerClient?.user?.id) return true;
  if (state.botCache.has(id)) return state.botCache.get(id);
  let bot = false;
  try {
    const u = await state.fluxerClient?.rest?.get(`/users/${id}`, { auth: true });
    bot = !!u?.bot;
  } catch {}
  state.botCache.set(id, bot);
  return bot;
}

/** Loudest sample in a frame. */
function peak(samples) {
  let m = 0;
  for (let i = 0; i < samples.length; i++) {
    const v = samples[i] < 0 ? -samples[i] : samples[i];
    if (v > m) m = v;
  }
  return m;
}
const SILENCE_PEAK = 40; // below this is silence (about -58 dB)
const HANGOVER_MS = 400; // keep sending this long after someone stops, so pauses between words aren't chopped

async function listenToFluxerTrack(track, publication, participant) {
  const lk = state.lk;
  if (!lk || track?.kind !== lk.TrackKind.KIND_AUDIO) return;
  if (isMirrorVoice(participant?.identity)) return; // a mirror speaking a Discord voice: never send it back
  const key = `f${publication?.sid ?? track.sid}`;
  const fluxerUserId = String(participant?.identity ?? "").match(/\d{15,21}/)?.[0] ?? null;
  if (state.fluxerStreams.has(key)) return;
  state.fluxerStreams.set(key, null); // claim it now, so it can't be picked up twice
  if (await isFluxerBot(participant)) {
    return; // stays claimed, so we don't keep re-checking; freed when their track goes away
  }
  if (!state.fluxerStreams.has(key)) return; // their track went away while we checked
  const reader = new lk.AudioStream(track, { sampleRate: RATE, numChannels: CHANNELS }).getReader();
  state.fluxerStreams.set(key, reader);
  (async () => {
    let lastLoud = 0;
    try {
      for (;;) {
        const { value, done } = await reader.read();
        if (done) break;
        // Fluxer sends silence nonstop; only relay actual talking (plus a short tail).
        const now = Date.now();
        if (peak(value.data) >= SILENCE_PEAK) lastLoud = now;
        if (now - lastLoud > HANGOVER_MS) continue;
        const level = fluxerUserId ? getLevel("fluxer", fluxerUserId) : 100;
        if (level === 0) continue; // muted in the bridge
        const samples = applyLevel(toStereo(Int16Array.from(value.data), value.channels), level);
        if (fluxerUserId && sendToTwin(fluxerUserId, samples)) continue; // their own Discord bot speaks it
        state.f2d?.push(key, samples);
      }
    } catch (e) {
      state.lastFluxerError = `hearing a Fluxer user: ${e?.message ?? e}`;
    } finally {
      state.fluxerStreams.delete(key);
      state.f2d?.remove(key);
    }
  })();
}

function stopFluxerTrack(publication) {
  const key = `f${publication?.sid}`;
  state.fluxerStreams.get(key)?.cancel?.().catch?.(() => {});
  state.fluxerStreams.delete(key);
  state.f2d?.remove(key);
}

/** Called by Hangout once the bridge bot is connected to the Fluxer voice room. */
export async function attachFluxerRoom(room, fluxerClient) {
  const lk = (state.lk = await deps.livekit());
  if (fluxerClient) state.fluxerClient = fluxerClient;
  ensureMixers();
  state.room = room;
  state.source = new lk.AudioSource(RATE, CHANNELS);
  state.track = lk.LocalAudioTrack.createAudioTrack("discord", state.source);
  const opts = new lk.TrackPublishOptions();
  opts.source = lk.TrackSource.SOURCE_MICROPHONE;
  await room.localParticipant.publishTrack(state.track, opts);
  room.on(lk.RoomEvent.TrackSubscribed, (track, pub, participant) => listenToFluxerTrack(track, pub, participant));
  room.on(lk.RoomEvent.TrackUnsubscribed, (track, pub) => stopFluxerTrack(pub));
  const sweep = () => {
    if (state.room !== room) return;
    for (const participant of room.remoteParticipants.values()) {
      for (const pub of participant.trackPublications.values()) {
        if (pub.track && !state.fluxerStreams.has(`f${pub.sid}`)) listenToFluxerTrack(pub.track, pub, participant);
      }
    }
  };
  sweep();

  // Personal Discord bots follow their Fluxer person in and out of the call.
  const personId = (p) => String(p?.identity ?? "").match(/\d{15,21}/)?.[0] ?? null;
  const micMuted = (p) => [...(p?.trackPublications?.values?.() ?? [])].some((pub) => pub.kind === lk.TrackKind.KIND_AUDIO && pub.muted);
  const arrive = async (p) => {
    const id = personId(p);
    if (!id || isMirrorVoice(p.identity) || id === state.fluxerClient?.user?.id || (await isFluxerBot(p))) return;
    twinJoin(id, { mute: micMuted(p) }).catch(() => {});
  };
  room.on(lk.RoomEvent.ParticipantConnected, arrive);
  room.on(lk.RoomEvent.ParticipantDisconnected, (p) => { const id = personId(p); if (id) twinLeave(id); });
  room.on(lk.RoomEvent.TrackMuted, (pub, p) => { const id = personId(p); if (id && pub?.kind === lk.TrackKind.KIND_AUDIO) twinFlags(id, { mute: true }); });
  room.on(lk.RoomEvent.TrackUnmuted, (pub, p) => { const id = personId(p); if (id && pub?.kind === lk.TrackKind.KIND_AUDIO) twinFlags(id, { mute: false }); });
  for (const p of room.remoteParticipants.values()) arrive(p);

  // Someone deafened/undeafened, muted, or the connection hiccuped: start hearing them again.
  room.on(lk.RoomEvent.TrackUnmuted, sweep);
  room.on(lk.RoomEvent.Reconnected, sweep);
  clearInterval(state.sweepTimer);
  state.sweepTimer = setInterval(sweep, 4000);
  state.lastFluxerError = null;
  log("META", "Voice bridge: connected on Fluxer, relaying voices.");
}

/** Called by Hangout when the Fluxer voice room goes away. */
export async function detachFluxerRoom() {
  clearInterval(state.sweepTimer);
  leaveAllTwins();
  for (const reader of state.fluxerStreams.values()) reader?.cancel?.().catch?.(() => {});
  state.fluxerStreams.clear();
  const track = state.track;
  state.source = null;
  state.track = null;
  state.room = null;
  await track?.close?.().catch?.(() => {});
}

// ---------------------------------------------------------------- start / stop

/** Rejoin the Discord call from scratch (used when it gets stuck). */
async function healDiscord(reason) {
  if (!state.active) return;
  state.heals++;
  note(`self-heal: ${reason}`);
  log("META", `Voice bridge: ${reason}. Rejoining the Discord call.`);
  state.stuckChecks = 0;
  state.errorTimes = [];
  state.speakingAt.clear();
  const conn = state.conn;
  state.conn = null;
  conn?.destroy();
  await joinDiscord().catch((e) => scheduleDiscordRejoin(e?.message ?? String(e)));
}

/** Every 10 s: is the Discord side actually working? If not, rejoin by itself. */
function watchdog() {
  if (!state.active || !state.discordClient?.isReady?.()) return;
  const now = Date.now();
  state.errorTimes = state.errorTimes.filter((t) => now - t < 30_000);
  if (state.errorTimes.length >= 6) return void healDiscord("too many audio errors from Discord");
  if (state.conn && state.conn.state?.status !== VoiceConnectionStatus.Ready) {
    state.stuckChecks++;
    if (state.stuckChecks >= 3) return void healDiscord(`connection stuck in "${state.conn.state?.status}"`);
    return;
  }
  // Someone on Discord has been talking for a while, but none of it is coming through?
  let silentTalkers = 0;
  for (const [userId, at] of state.speakingAt) {
    if (now - at > 12_000) { state.speakingAt.delete(userId); continue; }
    if (now - at > 5_000 && (state.decodedAt.get(userId) ?? 0) < at) silentTalkers++;
  }
  if (silentTalkers > 0) {
    state.stuckChecks++;
    if (state.stuckChecks >= 2) return void healDiscord("people are talking on Discord but nothing is coming through (encryption stuck?)");
  } else {
    state.stuckChecks = 0;
  }
}

/** Turn the Discord half on (the Fluxer half follows Hangout's room). */
export async function startBridge(discordClient, fluxerClient, target) {
  state.active = true;
  state.discordClient = discordClient;
  state.fluxerClient = fluxerClient ?? state.fluxerClient;
  state.target = target;
  state.retries = 0;
  ensureMixers();
  makePlayer();
  clearInterval(state.watchdogTimer);
  state.watchdogTimer = setInterval(watchdog, 10_000);
  setTwinVoiceTarget(target);
  if (discordClient?.isReady?.()) {
    // Connect in the background: Discord can take several seconds, and the Fluxer side shouldn't wait.
    joinDiscord().catch((e) => scheduleDiscordRejoin(e?.message ?? String(e)));
  }
}

export async function stopBridge() {
  state.active = false;
  setTwinVoiceTarget(null);
  clearTimeout(state.rejoinTimer);
  clearInterval(state.watchdogTimer);
  const conn = state.conn;
  state.conn = null;
  conn?.destroy();
  state.player?.stop(true);
  state.out?.destroy();
  state.out = null;
  for (const sub of state.discordSubs.values()) sub.opus.destroy();
  state.discordSubs.clear();
  state.f2d?.stop();
  state.d2f?.stop();
  state.f2d = null;
  state.d2f = null;
  await detachFluxerRoom();
}

export function bridgeStatus() {
  return {
    active: state.active,
    discord: state.conn?.state?.status ?? "not connected",
    fluxer: state.room ? "connected" : "not connected",
    fluxerSpeakers: [...state.fluxerStreams.values()].filter(Boolean).length,
    discordSpeakers: state.discordSubs.size,
    toDiscordSeconds: Math.round((state.counts.toDiscord * 20) / 1000),
    toFluxerSeconds: Math.round((state.counts.toFluxer * 20) / 1000),
    lastDiscordError: state.lastDiscordError,
    discordMuted: !!state.discordClient?.guilds?.cache?.get(state.target?.guildId)?.members?.me?.voice?.serverMute,
    discordStarts: state.discordStarts,
    heals: state.heals,
    twinsInCall: twinVoiceStatus(),
    voiceLog: [...state.voiceLog],
    lastFluxerError: state.lastFluxerError,
    target: state.target,
  };
}
