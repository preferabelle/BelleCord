import { Message as FluxerMessage } from "@fluxerjs/core";

/** A stable key for whoever sent a message (webhook copies are keyed by their shown name). */
export function keyOf(m) {
  const author = m?.author ?? {};
  const webhook = m?.webhookId ?? m?.webhook_id;
  return webhook ? `wh:${author.username}` : author.id;
}

/** The name to show for whoever sent a message. */
export function nameOf(m) {
  const a = m?.author ?? {};
  let member = null;
  try { member = m?.member ?? null; } catch {}
  return member?.nick ?? member?.displayName ?? a.globalName ?? a.global_name ?? a.username ?? "someone";
}

export const isFluxerMessage = (m) => m instanceof FluxerMessage;
