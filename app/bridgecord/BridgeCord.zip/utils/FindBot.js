// find any of the bridge's bots by a loose name.
//   "fluxer" (or "bridge") = the bridge bot on Fluxer, "discord" = the bridge bot on Discord,
//   otherwise personal Discord bots and mirrors by their name, bot username, or part of it.
import { mirrors } from "./Mirrors.js";
import { twins } from "./Twins.js";

export function findBot(text, fluxerClient, discordClient) {
  const n = String(text ?? "").toLowerCase().replace(/^@/, "").trim();
  if (!n) return { bot: null };
  if (/^(fluxer|bridge|main)$/.test(n)) return { bot: { kind: "fluxer", client: fluxerClient, label: "the bridge bot (Fluxer)", main: true, ready: true } };
  if (/^(discord)$/.test(n)) return { bot: { kind: "discord", client: discordClient, label: "the bridge bot (Discord)", main: true, ready: !!discordClient?.isReady?.() } };
  const score = (names) => {
    const ns = names.filter(Boolean).map((x) => String(x).toLowerCase());
    if (ns.includes(n)) return 2;
    if (ns.some((x) => x.includes(n) || (x.length >= 3 && n.includes(x)))) return 1;
    return 0;
  };
  const found = [];
  for (const t of twins) {
    const s = score([t.name, t.tag?.split("#")[0], t.client?.user?.username]);
    if (s) found.push({ s, kind: "discord", client: t.client, label: `${t.name}'s Discord bot`, twin: t, ready: t.ready });
  }
  for (const m of mirrors) {
    const s = score([m.name, m.tag?.split("#")[0]]);
    if (s) found.push({ s, kind: "fluxer", client: m.client, label: `${m.name}'s mirror`, mirror: m, ready: m.ready });
  }
  if (!found.length) return { bot: null };
  const best = Math.max(...found.map((f) => f.s));
  const top = found.filter((f) => f.s === best);
  if (top.length === 1) return { bot: top[0] };
  return { bot: null, ambiguous: top.map((f) => f.label) };
}
