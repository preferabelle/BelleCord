// Small helpers the extras (utils/extras/) share: posting as the bot on either side, finding the other side of a
// bridged channel, downloading pictures.
import fs from "node:fs";
import { Routes as FluxerRoutes } from "@fluxerjs/core";

export function sniffType(b) {
  if (!b || b.length < 12) return null;
  if (b[0] === 0x89 && b[1] === 0x50) return "image/png";
  if (b[0] === 0xff && b[1] === 0xd8) return "image/jpeg";
  if (b.subarray(0, 3).toString("ascii") === "GIF") return "image/gif";
  if (b.subarray(0, 4).toString("ascii") === "RIFF" && b.subarray(8, 12).toString("ascii") === "WEBP") return "image/webp";
  if (b.subarray(4, 8).toString("ascii") === "ftyp") return "video/mp4";
  if (b[0] === 0x1a && b[1] === 0x45 && b[2] === 0xdf && b[3] === 0xa3) return "video/webm";
  return null;
}
export const extOf = (type) => ({ "image/png": "png", "image/jpeg": "jpg", "image/gif": "gif", "image/webp": "webp", "video/mp4": "mp4", "video/webm": "webm" })[type] ?? "bin";

/** A picture from the internet, or null. */
export async function download(url, maxBytes = 25 * 1024 * 1024) {
  try {
    const r = await fetch(url, { signal: AbortSignal.timeout(30_000) });
    if (!r.ok) return null;
    const data = Buffer.from(await r.arrayBuffer());
    if (!data.length || data.length > maxBytes) return null;
    const type = sniffType(data) ?? (r.headers.get("content-type") ?? "").split(";")[0];
    return { data, type };
  } catch { return null; }
}

/** The bridge row for a channel on either side (or null). */
export async function bridgeOf({ discordChannelId, fluxerChannelId }) {
  try {
    const { ChannelMap } = await import("../db/index.js");
    if (discordChannelId) return await ChannelMap.findOne({ where: { discordChannelId: String(discordChannelId) }, raw: true });
    if (fluxerChannelId) return await ChannelMap.findOne({ where: { fluxerChannelId: String(fluxerChannelId) }, raw: true });
  } catch {}
  return null;
}

/** The copy of a message on the other side, once the bridge has made it (waits up to `ms`). */
export async function copyOf({ discordMessageId, fluxerMessageId }, ms = 5000) {
  try {
    const { MessageMap } = await import("../db/index.js");
    const where = discordMessageId ? { discordMessageId: String(discordMessageId) } : { fluxerMessageId: String(fluxerMessageId) };
    for (let waited = 0; waited <= ms; waited += 500) {
      const row = await MessageMap.findOne({ where, raw: true }).catch(() => null);
      if (row) return row;
      await new Promise((r) => setTimeout(r, 500));
    }
  } catch {}
  return null;
}

/** The bot posts in a Fluxer channel. files: [{ name, data }] */
export async function fluxerPost(fluxer, channelId, { content, embeds, files = [], replyTo } = {}) {
  if (!fluxer?.rest || !fluxer?.isReady?.()) return null;
  const body = { allowed_mentions: { parse: [] } };
  if (content) body.content = String(content).slice(0, 2000);
  if (embeds?.length) body.embeds = embeds;
  if (replyTo) body.message_reference = { message_id: String(replyTo), channel_id: String(channelId), fail_if_not_exists: false };
  const real = files.map((f) => ({ name: f.name, filename: f.name, data: f.data }));
  if (real.length) body.attachments = real.map((f, i) => ({ id: i, filename: f.name }));
  return await fluxer.rest.post(FluxerRoutes.channelMessages(String(channelId)), { body, files: real.length ? real : undefined, auth: true });
}
export async function fluxerEdit(fluxer, channelId, messageId, body) {
  if (!fluxer?.rest || !fluxer?.isReady?.()) return null;
  return await fluxer.rest.patch(FluxerRoutes.channelMessage(String(channelId), String(messageId)), { body, auth: true });
}
export async function fluxerReact(fluxer, channelId, messageId, emoji) {
  return await fluxer.rest.put(FluxerRoutes.channelMessageReactionMe(String(channelId), String(messageId), emoji), { auth: true });
}

/** The bot posts in a Discord channel. files: [{ name, data }]. replyTo: a Discord message (or its id). */
export async function discordPost(discord, channelId, { content, embeds, files = [], poll, replyTo } = {}) {
  const ch = await discord?.channels?.fetch(String(channelId)).catch(() => null);
  if (!ch?.send) return null;
  const payload = { allowedMentions: { parse: [] } };
  if (content) payload.content = String(content).slice(0, 2000);
  if (embeds?.length) payload.embeds = embeds;
  if (files.length) payload.files = files.map((f) => ({ attachment: f.data, name: f.name }));
  if (poll) payload.poll = poll;
  const ref = typeof replyTo === "string" ? replyTo : replyTo?.id;
  if (ref) payload.reply = { messageReference: ref, failIfNotExists: false };
  return await ch.send(payload).catch(() => null);
}
/** The bot edits one of its own Discord messages. */
export async function discordEdit(discord, channelId, messageId, content) {
  const ch = await discord?.channels?.fetch(String(channelId)).catch(() => null);
  return !!(await ch?.messages?.edit?.(String(messageId), typeof content === "string" ? { content } : content).catch(() => null));
}

/** Is this Fluxer account one of the mirror bots (they post copies of Discord people)? */
export async function isMirrorOnFluxer(id) {
  try { return (await import("./Mirrors.js")).isMirrorFluxerId(String(id)); } catch { return false; }
}

/** A person's name on a message from either side. */
export function nameOn(m) {
  return m?.member?.displayName ?? m?.member?.nick ?? m?.member?.nickname ?? m?.author?.globalName ?? m?.author?.global_name ?? m?.author?.username ?? "someone";
}

export function readJson(file, fallback) {
  try { return JSON.parse(fs.readFileSync(file, "utf-8")); } catch { return fallback; }
}
export function writeJson(file, value) {
  try { fs.writeFileSync(file + ".tmp", JSON.stringify(value, null, 1)); fs.renameSync(file + ".tmp", file); } catch {}
}

/** The files attached to a command message (Discord or Fluxer). */
export function attachmentsOf(message) {
  const a = message?.attachments;
  const list = a?.values ? [...a.values()] : Array.isArray(a) ? a : [];
  return list.map((x) => ({ url: x.url ?? x.proxyURL ?? x.proxy_url, name: x.name ?? x.filename ?? "picture" })).filter((x) => x.url);
}
