/**
 * @typedef {Object} FileOptions
 * @property {{name: string, url: string, flags?: number}[] | undefined} files
 */

import { log } from "./Logger.js";

function toAttachmentPayload(file, id) {
  const attachment = {
    id,
    filename: file.name,
  };

  if (file.flags !== undefined) attachment.flags = file.flags;
  if (file.description != null) attachment.description = file.description;

  return attachment;
}

/**
 * @param {string} webhookId
 * @param {string} webhookToken
 * @param {import("@fluxerjs/core").Client} fluxerClient
 * @param {import("@fluxerjs/core").WebhookSendOptions & FileOptions} params
 */
export async function sendFluxerWebhook(
  webhookId,
  webhookToken,
  fluxerClient,
  params,
) {
  const attachments = [];
  const resolvedFiles = [];
  const { files, ...jsonPayload } = params;

  log("DEBUG", `[FluxerWebhookSend] Preparing to send webhook with ${files?.length ?? 0} files.`);

  if (files) {
    for (let i = 0; i < files.length; i++) {
      try {
        const file = files[i];
        let data = file.data ?? file.attachment;

        if (!data) {
          if (!file.url) {
            log("DEBUG", `File at index ${i} has no data or URL, skipping.`);
            continue;
          }

          const res = await fetch(file.url);
          data = await res.arrayBuffer();
        }

        resolvedFiles.push({
          name: file.name,
          filename: file.name,
          data,
        });

        attachments.push(toAttachmentPayload(file, i));
      } catch (e) {
        log("FLUXER", `Failed to fetch: ${e}`);
      }
    }
  }

  jsonPayload.attachments = attachments;

  const result = await fluxerClient.rest.post(
    `/webhooks/${webhookId}/${webhookToken}?wait=true`,
    {
      body: jsonPayload,
      files: resolvedFiles,
      auth: false,
    },
  );

  return result;
}

/**
 * download bridge files once, so the same data can be sent through
 * a mirror bot or (if that fails) the webhook, without downloading twice.
 * @param {{name: string, url?: string, data?: any, attachment?: any, flags?: number, description?: string}[] | undefined} files
 */
export async function resolveBridgeFiles(files) {
  const out = [];
  for (const file of files ?? []) {
    try {
      let data = file.data ?? file.attachment;
      if (!data) {
        if (!file.url) continue;
        const res = await fetch(file.url);
        if (!res.ok) {
          log("FLUXER", `Couldn't download ${file.name} (${res.status}), skipping it.`);
          continue;
        }
        data = Buffer.from(await res.arrayBuffer());
      }
      out.push({
        name: file.name,
        data,
        flags: file.flags,
        description: file.description,
      });
    } catch (e) {
      log("FLUXER", `Failed to fetch ${file?.name}: ${e}`);
    }
  }
  return out;
}
