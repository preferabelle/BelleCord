// Linked servers stay the same on both sides. For every Fluxer community and Discord server that are
// bridged to each other (each pair on its own):
//   * a new text channel, voice channel or category on one side is made on the other too (and the two channels get
//     bridged). If the other side already has one with the same name that isn't linked, that one is used instead.
//   * renaming one, or changing its topic, age-restricted setting, slowmode or category, changes the other one
//   * deleting a linked channel deletes the one it's linked to. Unlink a channel first (bb!unlink) and
//     deleting it leaves the other side alone.
//   * the server's name and icon: change them on one side and the other side changes too
//   * anything made while the bot was off is caught up a minute after it starts (and every 5 minutes)
// Off until the owner turns it on for a pair with bb!keepsync on. Saved in data/server-link.json.
// Channel permissions and roles aren't copied here (bb!syncserver does those).
import fs from "node:fs";
import path from "node:path";
import { ChannelType } from "discord.js";
import { Routes as FluxerRoutes } from "@fluxerjs/core";
import { ChannelMap } from "../db/index.js";
import Config from "./ConfigHandler.js";
import { log } from "./Logger.js";

const FILE = path.join(Config.DataFolderPath, "server-link.json");
let cfg = { off: [], cats: {} }; // off: "fluxerGuild|discordGuild" pairs not kept in sync; cats: Fluxer category -> Discord category
try { cfg = { ...cfg, ...JSON.parse(fs.readFileSync(FILE, "utf-8")) }; } catch {}
cfg.off ??= []; cfg.cats ??= {};
const save = () => { try { fs.writeFileSync(FILE, JSON.stringify(cfg, null, 1)); } catch {} };

const F_TEXT = 0, F_VOICE = 2, F_CAT = 4, F_NEWS = 5;
const fKind = (t) => (t === F_CAT ? "category" : t === F_VOICE ? "voice" : t === F_TEXT || t === F_NEWS ? "text" : null);
const dKind = (c) => (c?.type === ChannelType.GuildCategory ? "category" : c?.type === ChannelType.GuildVoice ? "voice" : c?.type === ChannelType.GuildText || c?.type === ChannelType.GuildAnnouncement ? "text" : null);
const norm = (n) => String(n ?? "").toLowerCase().trim().replace(/\s+/g, "-").replace(/[^\p{L}\p{N}_-]/gu, "").replace(/-+/g, "-").replace(/^-+|-+$/g, "");
const dName = (kind, name) => (kind === "text" ? String(name).toLowerCase().replace(/\s+/g, "-") : String(name)).slice(0, 100);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

let D = null, F = null;
// channels this file made or deleted itself (their own create/delete events are its echo, not something to copy)
const mine = new Map();
const markMine = (id) => { if (id) mine.set(String(id), Date.now()); for (const [k, t] of mine) if (Date.now() - t > 10 * 60_000) mine.delete(k); };
const isMine = (id) => mine.has(String(id));

// ---------------- which servers go together ----------------
async function topOther(where, field) {
  const rows = await ChannelMap.findAll({ where, raw: true }).catch(() => []);
  const n = new Map();
  for (const r of rows) if (r[field]) n.set(String(r[field]), (n.get(String(r[field])) ?? 0) + 1);
  return [...n.entries()].sort((a, b) => b[1] - a[1])[0]?.[0] ?? null;
}
const fluxerOf = (dg) => topOther({ discordGuildId: String(dg) }, "fluxerGuildId");
const discordOf = (fg) => topOther({ fluxerGuildId: String(fg) }, "discordGuildId");
// (off until the owner turns it on with bb!keepsync on, because it also deletes channels on the other side)
cfg.on ??= [];
export const pairOn = (fg, dg) => cfg.on.includes(`${fg}|${dg}`);
export function setPairOn(fg, dg, on) {
  const k = `${fg}|${dg}`;
  cfg.on = cfg.on.filter((x) => x !== k);
  cfg.off = cfg.off.filter((x) => x !== k);
  if (on) { cfg.on.push(k); cfg.since ??= {}; cfg.since[k] = Date.now(); }
  save();
  return { ok: true, on: !!on };
}
async function busy(dg) { try { return (await import("./ServerSync.js")).syncing.has(String(dg)); } catch { return false; } }

// ---------------- reading each side ----------------
const fGet = (id) => F?.rest?.get(FluxerRoutes.channel(String(id)), { auth: true }).catch(() => null);
const fList = async (fg) => { const r = await F?.rest?.get(FluxerRoutes.guildChannels(String(fg)), { auth: true }).catch(() => null); return Array.isArray(r) ? r : []; };
const dGet = async (id) => D?.channels?.cache?.get(String(id)) ?? (await D?.channels?.fetch(String(id)).catch(() => null));
const linkOfD = (id) => ChannelMap.findOne({ where: { discordChannelId: String(id) }, raw: true }).catch(() => null);
const linkOfF = (id) => ChannelMap.findOne({ where: { fluxerChannelId: String(id) }, raw: true }).catch(() => null);

// the category on the other side (remembered, else the one with the same name, else made)
async function dCatFor(fCatId, dGuild, make = true) {
  if (!fCatId) return null;
  const had = cfg.cats[String(fCatId)];
  if (had && dGuild.channels.cache.has(had)) return had;
  const fc = await fGet(fCatId);
  if (!fc) return null;
  let d = [...dGuild.channels.cache.values()].find((x) => x.type === ChannelType.GuildCategory && norm(x.name) === norm(fc.name) && !Object.values(cfg.cats).includes(x.id));
  if (!d && make) { d = await dGuild.channels.create({ name: dName("category", fc.name), type: ChannelType.GuildCategory, reason: "Made on Fluxer" }).catch(() => null); if (d) markMine(d.id); }
  if (!d) return null;
  cfg.cats[String(fCatId)] = d.id; save();
  return d.id;
}
async function fCatFor(dCatId, fg, make = true) {
  if (!dCatId) return null;
  const had = Object.entries(cfg.cats).find(([, d]) => d === String(dCatId))?.[0];
  const list = await fList(fg);
  if (had && list.some((x) => String(x.id) === had)) return had;
  const dc = await dGet(dCatId);
  if (!dc) return null;
  let f = list.find((x) => x.type === F_CAT && norm(x.name) === norm(dc.name) && !cfg.cats[String(x.id)]);
  if (!f && make) { f = await F.rest.post(FluxerRoutes.guildChannels(String(fg)), { body: { name: dc.name, type: F_CAT }, auth: true }).catch(() => null); if (f?.id) markMine(f.id); }
  if (!f?.id) return null;
  cfg.cats[String(f.id)] = dc.id; save();
  return String(f.id);
}

// ---------------- made on one side ----------------
async function madeOnDiscord(ch, now = false) {
  const kind = dKind(ch);
  if (!kind || !ch.guildId) return;
  if (now !== true) await sleep(4000); // (a channel the bridge makes and links itself is linked by then)
  if (isMine(ch.id) || (await linkOfD(ch.id)) || Object.values(cfg.cats).includes(ch.id)) return;
  const fg = await fluxerOf(ch.guildId);
  if (!fg || !pairOn(fg, ch.guildId) || (await busy(ch.guildId))) return;
  const list = await fList(fg);
  const fType = kind === "category" ? F_CAT : kind === "voice" ? F_VOICE : F_TEXT;
  const parent = kind !== "category" && ch.parentId ? await fCatFor(ch.parentId, fg) : null;
  // the same name already there and not linked: use it
  const linked = new Set((await ChannelMap.findAll({ where: { fluxerGuildId: fg }, raw: true }).catch(() => [])).map((r) => String(r.fluxerChannelId)));
  let f = list.find((x) => x.type === fType && norm(x.name) === norm(ch.name) && !linked.has(String(x.id)) && !(kind === "category" && cfg.cats[String(x.id)]));
  if (!f) {
    f = await F.rest.post(FluxerRoutes.guildChannels(fg), { body: { name: ch.name, type: fType, ...(parent ? { parent_id: parent } : {}), ...(kind === "text" && ch.topic ? { topic: ch.topic } : {}), ...(kind !== "category" ? { nsfw: !!ch.nsfw } : {}), ...(kind === "voice" && ch.userLimit ? { user_limit: ch.userLimit } : {}) }, auth: true }).catch((e) => { log("LINK", `Couldn't make #${ch.name} on Fluxer: ${e?.message ?? e}`); return null; });
    if (!f?.id) return;
    markMine(f.id);
    if (kind !== "category" && ch.rateLimitPerUser) await F.rest.patch(FluxerRoutes.channel(f.id), { body: { rate_limit_per_user: ch.rateLimitPerUser }, auth: true }).catch(() => {});
  }
  if (kind === "category") { cfg.cats[String(f.id)] = ch.id; save(); }
  else await link(ch.guild, fg, String(f.id), ch.id, kind);
  log("LINK", `Made on Discord, now on Fluxer too: ${kind === "category" ? "category " : "#"}${ch.name}`);
}
async function madeOnFluxer(raw, now = false) {
  if (now !== true) await sleep(4000);
  const c = await fGet(raw.id);
  const kind = fKind(c?.type);
  if (!c || !kind || !c.guild_id) return;
  if (isMine(c.id) || (await linkOfF(c.id)) || cfg.cats[String(c.id)]) return;
  const dg = await discordOf(c.guild_id);
  const dGuild = dg ? D?.guilds?.cache?.get(dg) : null;
  if (!dGuild || !pairOn(c.guild_id, dg) || (await busy(dg))) return;
  const dType = kind === "category" ? ChannelType.GuildCategory : kind === "voice" ? ChannelType.GuildVoice : ChannelType.GuildText;
  const parent = kind !== "category" && c.parent_id ? await dCatFor(c.parent_id, dGuild) : null;
  const linked = new Set((await ChannelMap.findAll({ where: { discordGuildId: dg }, raw: true }).catch(() => [])).map((r) => String(r.discordChannelId)));
  let d = [...dGuild.channels.cache.values()].find((x) => dKind(x) === kind && norm(x.name) === norm(c.name) && !linked.has(x.id) && !(kind === "category" && Object.values(cfg.cats).includes(x.id)));
  if (!d) {
    d = await dGuild.channels.create({ name: dName(kind, c.name), type: dType, reason: "Made on Fluxer", ...(parent ? { parent } : {}), ...(kind === "text" && c.topic ? { topic: c.topic } : {}), ...(kind !== "category" ? { nsfw: !!c.nsfw, rateLimitPerUser: Number(c.rate_limit_per_user ?? 0) } : {}), ...(kind === "voice" && c.user_limit ? { userLimit: Math.min(99, c.user_limit) } : {}) }).catch((e) => { log("LINK", `Couldn't make #${c.name} on Discord: ${e?.message ?? e}`); return null; });
    if (!d) return;
    markMine(d.id);
  }
  if (kind === "category") { cfg.cats[String(c.id)] = d.id; save(); }
  else await link(dGuild, String(c.guild_id), String(c.id), d.id, kind);
  log("LINK", `Made on Fluxer, now on Discord too: ${kind === "category" ? "category " : "#"}${c.name}`);
}
async function link(dGuild, fg, fluxerId, discordId, kind) {
  try {
    const { bridgeOne } = await import("./ServerSync.js");
    await bridgeOne(dGuild, F, fg, { ref: { id: discordId }, fluxerId, kind });
  } catch (e) { log("LINK", `Couldn't link the new channel: ${e?.message ?? e}`); }
}

// ---------------- changed on one side ----------------
async function changedOnDiscord(ch) {
  const kind = dKind(ch);
  if (!kind || !ch.guildId) return;
  const row = kind === "category" ? null : await linkOfD(ch.id);
  const fid = kind === "category" ? Object.entries(cfg.cats).find(([, d]) => d === ch.id)?.[0] : row?.fluxerChannelId;
  if (!fid) return;
  const fg = row?.fluxerGuildId ?? (await fluxerOf(ch.guildId));
  if (!fg || !pairOn(fg, ch.guildId) || (await busy(ch.guildId))) return; // (bb!syncserver is copying onto it right now)
  const f = await fGet(fid);
  if (!f) return;
  const body = {};
  if (norm(f.name) !== norm(ch.name)) body.name = ch.name;
  if (kind === "text" && (f.topic ?? "") !== (ch.topic ?? "")) body.topic = ch.topic ?? "";
  if (kind !== "category" && !!f.nsfw !== !!ch.nsfw) body.nsfw = !!ch.nsfw;
  if (kind !== "category" && Number(f.rate_limit_per_user ?? 0) !== Number(ch.rateLimitPerUser ?? 0)) body.rate_limit_per_user = Number(ch.rateLimitPerUser ?? 0);
  if (kind === "voice" && Number(f.user_limit ?? 0) !== Number(ch.userLimit ?? 0)) body.user_limit = Number(ch.userLimit ?? 0);
  if (kind !== "category") {
    const want = ch.parentId ? await fCatFor(ch.parentId, fg) : null;
    if (String(f.parent_id ?? "") !== String(want ?? "")) body.parent_id = want;
  }
  if (!Object.keys(body).length) return; // (the same already: this is the echo of a change made from here)
  await F.rest.patch(FluxerRoutes.channel(String(fid)), { body, auth: true }).catch((e) => log("LINK", `Couldn't change #${f.name} on Fluxer: ${e?.message ?? e}`));
}
async function changedOnFluxer(raw) {
  const c = await fGet(raw.id);
  const kind = fKind(c?.type);
  if (!c || !kind) return;
  const row = kind === "category" ? null : await linkOfF(c.id);
  const did = kind === "category" ? cfg.cats[String(c.id)] : row?.discordChannelId;
  if (!did) return;
  const d = await dGet(did);
  if (!d?.guild) return;
  if (!pairOn(String(c.guild_id), d.guildId) || (await busy(d.guildId))) return;
  const edit = {};
  if (norm(d.name) !== norm(c.name)) edit.name = dName(kind, c.name);
  if (kind === "text" && (d.topic ?? "") !== (c.topic ?? "")) edit.topic = c.topic || null;
  if (kind !== "category" && !!d.nsfw !== !!c.nsfw) edit.nsfw = !!c.nsfw;
  if (kind !== "category" && Number(d.rateLimitPerUser ?? 0) !== Number(c.rate_limit_per_user ?? 0)) edit.rateLimitPerUser = Math.min(21600, Number(c.rate_limit_per_user ?? 0));
  if (kind === "voice" && Number(d.userLimit ?? 0) !== Number(c.user_limit ?? 0)) edit.userLimit = Math.min(99, Number(c.user_limit ?? 0));
  if (kind !== "category") {
    const want = c.parent_id ? await dCatFor(c.parent_id, d.guild) : null;
    if (String(d.parentId ?? "") !== String(want ?? "")) edit.parent = want;
  }
  if (!Object.keys(edit).length) return;
  await d.edit({ ...edit, reason: "Changed on Fluxer" }).catch((e) => log("LINK", `Couldn't change #${d.name} on Discord: ${e?.message ?? e}`));
}

// ---------------- deleted on one side ----------------
// (index.js calls these BEFORE it forgets the channel's bridge, so the other side is still known)
export async function goneOnDiscord(ch) {
  try {
    if (!ch?.id || isMine(ch.id)) return;
    if (ch.guildId && (await busy(ch.guildId))) return; // (bb!syncserver clean only deletes what isn't linked)
    const kind = dKind(ch);
    if (kind === "category") {
      const fid = Object.entries(cfg.cats).find(([, d]) => d === ch.id)?.[0];
      if (!fid) return;
      delete cfg.cats[fid]; save();
      const fg = await fluxerOf(ch.guildId);
      if (!fg || !pairOn(fg, ch.guildId)) return;
      markMine(fid);
      await F?.rest?.delete(FluxerRoutes.channel(fid), { auth: true }).catch(() => {});
      return;
    }
    const rows = await ChannelMap.findAll({ where: { discordChannelId: String(ch.id) }, raw: true }).catch(() => []);
    for (const r of rows) {
      if (!pairOn(r.fluxerGuildId, r.discordGuildId)) continue;
      markMine(r.fluxerChannelId);
      await F?.rest?.delete(FluxerRoutes.channel(String(r.fluxerChannelId)), { auth: true }).then(() => log("LINK", `#${ch.name} was deleted on Discord, so its Fluxer channel was too.`)).catch((e) => log("LINK", `Couldn't delete the Fluxer side of #${ch.name}: ${e?.message ?? e}`));
    }
  } catch (e) { log("LINK", `Deleting the other side didn't work: ${e?.message ?? e}`); }
}
export async function goneOnFluxer(ch) {
  try {
    if (!ch?.id || isMine(ch.id)) return;
    const catD = cfg.cats[String(ch.id)];
    if (catD) {
      delete cfg.cats[String(ch.id)]; save();
      const d = await dGet(catD);
      if (d?.guildId && (await busy(d.guildId))) return; // (bb!syncserver to fluxer clean only deletes what isn't linked)
      if (!d || !pairOn(String(ch.guildId ?? ch.guild_id ?? (await fluxerOf(d.guildId))), d.guildId)) return;
      markMine(d.id);
      await d.delete("Deleted on Fluxer").catch(() => {});
      return;
    }
    const rows = await ChannelMap.findAll({ where: { fluxerChannelId: String(ch.id) }, raw: true }).catch(() => []);
    for (const r of rows) {
      if (!pairOn(r.fluxerGuildId, r.discordGuildId) || (await busy(r.discordGuildId))) continue;
      const d = await dGet(r.discordChannelId);
      if (!d) continue;
      markMine(d.id);
      await d.delete("Deleted on Fluxer").then(() => log("LINK", `#${d.name} was deleted on Fluxer, so its Discord channel was too.`)).catch((e) => log("LINK", `Couldn't delete #${d.name} on Discord: ${e?.message ?? e}`));
    }
  } catch (e) { log("LINK", `Deleting the other side didn't work: ${e?.message ?? e}`); }
}

// ---------------- the server itself: its name and icon ----------------
// (a change made from here is held off on the side it was made to for half a minute, so it doesn't bounce back)
cfg.guilds ??= {}; // Fluxer server -> { icon, name } last seen
const held = new Map();
const hold = (k) => held.set(k, Date.now() + 30_000);
const isHeld = (k) => (held.get(k) ?? 0) > Date.now();
const fIconUrl = (fg, h) => `https://fluxerusercontent.com/icons/${fg}/${h}.${String(h).startsWith("a_") ? "gif" : "png"}?size=512`;
async function dataUri(url) {
  const r = await fetch(url);
  if (!r.ok) throw new Error(`couldn't download the icon (${r.status})`);
  const type = r.headers.get("content-type") || "image/png";
  return `data:${type};base64,${Buffer.from(await r.arrayBuffer()).toString("base64")}`;
}
async function guildChangedOnDiscord(old, g) {
  if (!g?.id || isHeld("d:" + g.id)) return;
  const fg = await fluxerOf(g.id);
  if (!fg || !pairOn(fg, g.id)) return;
  const body = {};
  if (old?.name !== g.name && g.name) body.name = g.name;
  if (old?.icon !== g.icon) body.icon = g.icon ? await dataUri(g.iconURL({ extension: String(g.icon).startsWith("a_") ? "gif" : "png", size: 512 })) : null;
  if (!Object.keys(body).length) return;
  hold("f:" + fg);
  await F.rest.patch(FluxerRoutes.guild(fg), { body, auth: true }).then(() => log("LINK", `"${g.name}" changed its ${Object.keys(body).join(" and ")} on Discord, so its Fluxer server did too.`)).catch((e) => log("LINK", `Couldn't change the Fluxer server: ${e?.message ?? e}`));
  const now = await F.rest.get(FluxerRoutes.guild(fg), { auth: true }).catch(() => null);
  if (now) { cfg.guilds[fg] = { icon: now.icon ?? null, name: now.name ?? null }; save(); }
}
async function guildChangedOnFluxer(raw) {
  const fg = String(raw?.id ?? "");
  if (!fg) return;
  const now = await F.rest.get(FluxerRoutes.guild(fg), { auth: true }).catch(() => null);
  if (!now) return;
  const was = cfg.guilds[fg];
  cfg.guilds[fg] = { icon: now.icon ?? null, name: now.name ?? null }; save();
  if (!was || isHeld("f:" + fg)) return; // (the first look only remembers it)
  const dg = await discordOf(fg);
  const g = dg ? D?.guilds?.cache?.get(dg) : null;
  if (!g || !pairOn(fg, dg)) return;
  const did = [];
  hold("d:" + dg);
  if (now.name && now.name !== was.name && now.name !== g.name) { await g.setName(now.name, "Changed on Fluxer").then(() => did.push("name")).catch((e) => log("LINK", `Couldn't rename the Discord server: ${e?.message ?? e}`)); }
  if ((now.icon ?? null) !== (was.icon ?? null)) { await g.setIcon(now.icon ? fIconUrl(fg, now.icon) : null, "Changed on Fluxer").then(() => did.push("icon")).catch((e) => log("LINK", `Couldn't change the Discord server's icon: ${e?.message ?? e}`)); }
  if (did.length) log("LINK", `"${now.name}" changed its ${did.join(" and ")} on Fluxer, so its Discord server did too.`);
}

// ---------------- anything made while the bot was off ----------------
// Every few minutes, a channel on either side of a synced pair that isn't linked yet and was made after the pair
// started syncing gets its other half, as if it had just been made. (Older channels nobody linked are left alone.)
const snowAt = (id) => { try { return Number((BigInt(id) >> 22n) + 1420070400000n); } catch { return 0; } };
async function pairsNow() {
  const rows = await ChannelMap.findAll({ raw: true }).catch(() => []);
  const out = new Map();
  for (const r of rows) if (r.fluxerGuildId && r.discordGuildId) out.set(`${r.fluxerGuildId}|${r.discordGuildId}`, { fg: String(r.fluxerGuildId), dg: String(r.discordGuildId) });
  return [...out.values()];
}
async function catchUp() {
  cfg.since ??= {};
  for (const { fg, dg } of await pairsNow()) {
    const k = `${fg}|${dg}`;
    // the server's name and icon, remembered the first time (so a later change can be told apart)
    if (!cfg.guilds[fg]) { const now = await F.rest.get(FluxerRoutes.guild(fg), { auth: true }).catch(() => null); if (now) { cfg.guilds[fg] = { icon: now.icon ?? null, name: now.name ?? null }; save(); } }
    if (!cfg.since[k]) { cfg.since[k] = Date.now(); save(); continue; }
    if (!pairOn(fg, dg) || (await busy(dg))) continue;
    // (each server's own favorite pairing wins: a server bridged to two others only syncs with its main one)
    if ((await fluxerOf(dg)) !== fg || (await discordOf(fg)) !== dg) continue;
    const g = D?.guilds?.cache?.get(dg);
    if (!g) continue;
    const linkedD = new Set((await ChannelMap.findAll({ where: { discordGuildId: dg }, raw: true }).catch(() => [])).map((r) => String(r.discordChannelId)));
    const linkedF = new Set((await ChannelMap.findAll({ where: { fluxerGuildId: fg }, raw: true }).catch(() => [])).map((r) => String(r.fluxerChannelId)));
    const cats = Object.entries(cfg.cats);
    for (const ch of [...g.channels.cache.values()]) {
      const kind = dKind(ch);
      if (!kind || isMine(ch.id) || linkedD.has(ch.id) || (ch.createdTimestamp ?? 0) < cfg.since[k]) continue;
      if (kind === "category" && cats.some(([, d]) => d === ch.id)) continue;
      await madeOnDiscord(ch, true).catch(() => {});
    }
    for (const c of await fList(fg)) {
      const kind = fKind(c.type);
      if (!kind || isMine(c.id) || linkedF.has(String(c.id)) || snowAt(c.id) < cfg.since[k]) continue;
      if (kind === "category" && cfg.cats[String(c.id)]) continue;
      await madeOnFluxer(c, true).catch(() => {});
    }
  }
}

// what a channel looks like, for the parts this copies (works for both sites' channel objects)
const look = (c) => [c?.name, c?.topic ?? "", !!c?.nsfw, c?.parentId ?? c?.parent_id ?? "", c?.rateLimitPerUser ?? c?.rate_limit_per_user ?? 0, c?.userLimit ?? c?.user_limit ?? 0].join("|");
const same = (a, b) => look(a) === look(b);

/** bb!syncserver matched these categories up: remember it, so later changes go to the right one. */
export function rememberCats(pairs) {
  for (const [f, d] of pairs) {
    for (const [k, v] of Object.entries(cfg.cats)) if (v === String(d) && k !== String(f)) delete cfg.cats[k];
    cfg.cats[String(f)] = String(d);
  }
  save();
}

/** Start listening (index.js, once both bots exist). */
export function startServerLink(discordClient, fluxerClient) {
  D = discordClient; F = fluxerClient;
  const safe = (fn) => (...a) => { Promise.resolve().then(() => fn(...a)).catch((e) => log("LINK", e?.message ?? e)); };
  D.on("channelCreate", safe(madeOnDiscord));
  // (only when something this copies really changed: the sites report lots of other changes, and asking Fluxer
  //  about every one of them got the bot rate limited)
  D.on("channelUpdate", safe((old, ch) => { if (old && same(old, ch)) return; return changedOnDiscord(ch); }));
  D.on("guildUpdate", safe(guildChangedOnDiscord));
  F.on("channelCreate", safe((ch) => madeOnFluxer(ch)));
  F.on("channelUpdate", safe(async (old, ch) => {
    if (old && old !== ch && same(old, ch)) return;
    // (and only for channels that are linked: nothing to ask Fluxer otherwise)
    const id = String(ch?.id ?? "");
    if (!id || (!cfg.cats[id] && !(await linkOfF(id)))) return;
    return changedOnFluxer(ch);
  }));
  F.on("guildUpdate", safe((old, g) => {
    if (old && old !== g && (old.name ?? null) === (g?.name ?? null) && (old.icon ?? null) === (g?.icon ?? null)) return;
    return guildChangedOnFluxer(g);
  }));
  // (a minute after starting, then every 5 minutes)
  const tick = () => { if (D?.isReady?.() && F?.isReady?.()) catchUp().catch((e) => log("LINK", `Catch-up: ${e?.message ?? e}`)); };
  setTimeout(tick, 60_000);
  setInterval(tick, 5 * 60_000).unref?.();
}
