// audio mixer for voice bridging.
// Everything is 48 kHz, stereo, 16-bit, in 20 ms frames (960 samples per channel),
// which is what both Discord and LiveKit (Fluxer voice) use natively.
// Each speaker gets a small buffer (so bumpy connections don't stutter), and every
// 20 ms everyone who's talking is added together into one frame.

export const RATE = 48000;
export const CHANNELS = 2;
export const FRAME = 960; // samples per channel in 20 ms
export const FRAME_SAMPLES = FRAME * CHANNELS; // interleaved samples in one frame

const PRIME_FRAMES = 3; // wait for 60 ms of audio before playing a speaker (jitter buffer)
const MAX_FRAMES = 12; // never let a speaker fall more than 240 ms behind
const IDLE_DROP_MS = 10_000; // forget a speaker after 10 s of silence

export class Mixer {
  /**
   * @param {(frame: Int16Array) => void} onFrame called with each mixed frame (only when someone is talking)
   * @param {{ now?: () => number }} [opts]
   */
  constructor(onFrame, opts = {}) {
    this.onFrame = onFrame;
    this.now = opts.now ?? (() => performance.now());
    this.tickMs = opts.tickMs ?? 5;
    this.primeFrames = opts.primeFrames ?? PRIME_FRAMES; // how much to buffer before playing someone
    this.graceFrames = opts.graceFrames ?? 0; // tiny gaps to ride out before re-buffering
    /** @type {Map<string, {chunks: Int16Array[], offset: number, length: number, primed: boolean, last: number}>} */
    this.sources = new Map();
    this.timer = null;
    this.startedAt = 0;
    this.framesDone = 0;
    this.gain = 1;
  }

  /** Add audio from one speaker: interleaved stereo 48 kHz Int16 samples. */
  push(id, samples) {
    if (!samples?.length) return;
    let s = this.sources.get(id);
    if (!s) {
      s = { chunks: [], offset: 0, length: 0, primed: false, last: 0, misses: 0 };
      this.sources.set(id, s);
    }
    s.chunks.push(samples);
    s.length += samples.length;
    s.last = this.now();
    // Too far behind (e.g. the computer hiccuped): drop the oldest audio to stay in sync.
    while (s.length > FRAME_SAMPLES * MAX_FRAMES && s.chunks.length > 1) {
      const dropped = s.chunks.shift();
      s.length -= dropped.length - s.offset;
      s.offset = 0;
    }
  }

  remove(id) {
    this.sources.delete(id);
  }

  /** Drop everything buffered right now (used when someone is muted mid-sentence). */
  clear() {
    this.sources.clear();
  }

  get speakers() {
    return this.sources.size;
  }

  /** Take exactly n samples from a source into `into` (adding), returns false if not enough. */
  #addFrom(s, into) {
    if (s.length < FRAME_SAMPLES) return false;
    let need = FRAME_SAMPLES;
    let pos = 0;
    while (need > 0) {
      const chunk = s.chunks[0];
      const available = chunk.length - s.offset;
      const n = Math.min(available, need);
      for (let i = 0; i < n; i++) into[pos + i] += chunk[s.offset + i];
      pos += n;
      need -= n;
      s.offset += n;
      if (s.offset >= chunk.length) {
        s.chunks.shift();
        s.offset = 0;
      }
    }
    s.length -= FRAME_SAMPLES;
    return true;
  }

  /** Mix one 20 ms frame. Returns the frame, or null if nobody is talking. */
  mixOne() {
    const acc = new Int32Array(FRAME_SAMPLES);
    let talking = 0;
    const now = this.now();
    for (const [id, s] of this.sources) {
      if (!s.primed) {
        if (s.length >= FRAME_SAMPLES * this.primeFrames) s.primed = true;
        else {
          if (s.length === 0 && now - s.last > IDLE_DROP_MS) this.sources.delete(id);
          continue;
        }
      }
      if (this.#addFrom(s, acc)) {
        talking++;
        s.misses = 0;
      } else if (++s.misses > this.graceFrames) {
        s.primed = false; // really ran dry: build the buffer back up before playing again
        s.misses = 0;
      }
    }
    if (!talking) return null;
    const out = new Int16Array(FRAME_SAMPLES);
    const g = this.gain;
    for (let i = 0; i < FRAME_SAMPLES; i++) {
      const v = acc[i] * g;
      out[i] = v > 32767 ? 32767 : v < -32768 ? -32768 : v;
    }
    return out;
  }

  /** Run on a steady 20 ms clock (catching up if the timer ran late). */
  start() {
    if (this.timer) return;
    this.startedAt = this.now();
    this.framesDone = 0;
    this.timer = setInterval(() => {
      const due = Math.floor((this.now() - this.startedAt) / 20) - this.framesDone;
      // After a long stall, skip ahead instead of blasting a burst of old frames.
      const n = due > 10 ? 1 : due;
      if (due > 10) this.framesDone += due - 1;
      for (let i = 0; i < n; i++) {
        this.framesDone++;
        const frame = this.mixOne();
        try {
          if (frame) this.onFrame(frame);
          else this.onSilence?.();
        } catch {}
      }
    }, this.tickMs);
  }

  stop() {
    clearInterval(this.timer);
    this.timer = null;
    this.sources.clear();
  }
}

/** Mono -> stereo, or pass stereo through. */
export function toStereo(samples, channels) {
  if (channels === 2) return samples;
  const out = new Int16Array(samples.length * 2);
  for (let i = 0; i < samples.length; i++) {
    out[2 * i] = samples[i];
    out[2 * i + 1] = samples[i];
  }
  return out;
}
