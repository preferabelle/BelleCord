/**
 * @param {Date} start
 * @param {Date} end
 */
export function getDuration(start, end) {
  let diffMs = end.getTime() - start.getTime();
  const days = Math.floor(diffMs / (1000 * 60 * 60 * 24));
  diffMs -= days * 1000 * 60 * 60 * 24;
  const hours = Math.floor(diffMs / (1000 * 60 * 60));
  diffMs -= hours * 1000 * 60 * 60;
  const minutes = Math.floor(diffMs / (1000 * 60));
  diffMs -= minutes * 1000 * 60;
  const seconds = Math.floor(diffMs / 1000);
  const unit = (n, word) => `${n} ${word}${n === 1 ? "" : "s"}`;
  return (
    (days > 0 ? unit(days, "day") + ", " : "") +
    (hours > 0 ? unit(hours, "hour") + ", " : "") +
    (minutes > 0 ? unit(minutes, "minute") + ", " : "") +
    unit(seconds, "second")
  ).trim();
}
