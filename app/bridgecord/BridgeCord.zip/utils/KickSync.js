// kick a mirror on Fluxer -> kick its person on Discord.
// A real person gets kicked from a server the owner doesn't run, so there's a safety window:
// the bridge bot DMs the owner first, and `bb!kick-cancel` within 60 seconds calls it off.
import { moodify } from "./Output.js";
import { Routes as FluxerRoutes } from "@fluxerjs/core";
import { ChannelMap } from "../db/index.js";
import Config from "./ConfigHandler.js";
import { log } from "./Logger.js";
import { setMirrorRemovedHandler } from "./Mirrors.js";

/** Adjustable for tests. */
export const timing = { waitMs: 60_000 };
/** @type {Map<string, {timer: any, name: string, discordName: string}>} discordId -> pending kick */
export const pending = new Map();
let discord = null;
let fluxer = null;

const ownerId = () => Config.OwnerId ?? null;

/** DM the owner from the bridge bot. */
export async function tellOwner(text) {
  const owner = ownerId();
  if (!owner || !fluxer) return log("MIRROR", text);
  try {
    const dm = await fluxer.rest.post(FluxerRoutes.userMeChannels(), { body: { recipient_id: owner }, auth: true });
    await fluxer.rest.post(FluxerRoutes.channelMessages(dm.id), { body: { content: moodify(text) }, auth: true });
  } catch {
    log("MIRROR", text);
  }
}

async function discordServersFor(fluxerGuildId) {
  const maps = await ChannelMap.findAll({ where: { fluxerGuildId }, raw: true }).catch(() => []);
  return [...new Set(maps.map((m) => m.discordGuildId))].map((id) => discord?.guilds?.cache?.get(id)).filter(Boolean);
}

export async function onMirrorRemoved(mirror, guild) {
  if (!mirror.discordId || !discord?.isReady?.()) return;
  const servers = await discordServersFor(guild?.id);
  if (!servers.length) return; // not a bridged community
  const user = await discord.users.fetch(mirror.discordId).catch(() => null);
  const who = user ? `@${user.username}` : mirror.name;
  clearTimeout(pending.get(mirror.discordId)?.timer);
  const timer = setTimeout(() => doKick(mirror, servers, who), timing.waitMs);
  pending.set(mirror.discordId, { timer, name: mirror.name, discordName: who });
  await tellOwner(
    `${mirror.name} got kicked from ${guild?.name ?? "your community"}, so in 60 seconds I'm kicking ${who} from ${servers.map((s) => s.name).join(", ")} on Discord too.\n` +
      "-# Type `bb!kick-cancel` to call it off.",
  );
}

async function doKick(mirror, servers, who) {
  pending.delete(mirror.discordId);
  for (const server of servers) {
    const member = await server.members.fetch(mirror.discordId).catch(() => null);
    if (!member) continue;
    if (!member.kickable) {
      await tellOwner(
        `I couldn't kick ${who} from ${server.name}. A Discord admin has to give me **Kick Members**, and my role has to be above theirs. ` +
          "Easiest fix: open the Discord link from `bb!invite` again; re-authorizing updates the bot's permissions.",
      );
      continue;
    }
    try {
      await member.kick("Their mirror was kicked on Fluxer");
      await tellOwner(`Done. ${who} is kicked from ${server.name}. `);
    } catch (e) {
      await tellOwner(`Discord wouldn't let me kick ${who} from ${server.name}: ${e?.message ?? e}`);
    }
  }
}

/** Call off pending kicks: all of them, or just one by name. Returns what was spared. */
export function spare(name) {
  const spared = [];
  for (const [id, p] of pending) {
    if (name && ![p.name, p.discordName.replace(/^@/, "")].some((n) => n.toLowerCase() === name.toLowerCase())) continue;
    clearTimeout(p.timer);
    pending.delete(id);
    spared.push(p.discordName);
  }
  return spared;
}

export function attachKickSync(discordClient, fluxerClient) {
  discord = discordClient;
  fluxer = fluxerClient;
  setMirrorRemovedHandler((mirror, guild) => onMirrorRemoved(mirror, guild).catch((e) => log("MIRROR", "Kick sync error:", e?.message ?? e)));
}
