import { execSync } from "child_process";

/**
 * the version line, shown by bb!about.
 * Upstream runs `git`, which isn't installed on a normal home PC, so fall back
 * to the fork version instead of throwing.
 */
export default function getCommitHash() {
  try {
    return execSync("git rev-parse --short HEAD", { stdio: ["ignore", "pipe", "ignore"] })
      .toString()
      .trim();
  } catch {
    return "local";
  }
}
