// If you fork Fluxcord, fill up this thing!
// It's not required, but its encouraged!

const ForkDetails = {
  isFork: true,
  forkName: "bridgecord",
  forkVersion: "1.0.0",
  forkDescription:
    "BridgeCord, a Fluxer and Discord bridge built on Fluxcord: mirror bots, linked bots, voice bridging, DM bridging, catch-up after downtime, and Discord moderation tools.",
  // BridgeCord's own page (bb!about links to it). It's built on Fluxcord: github.com/Fluxcord-Bot/core
  forkRepo: "https://github.com/preferabelle/BridgeCord",
  forkVoiceRepo: "",
  forkEnableSupport: false,
};

export default ForkDetails;
