// Becoming the owner without looking up any IDs.
// While the bot has no owner, the start window shows a claim code. Typing  b!claim <code>  in
// Fluxer makes you the owner (only whoever runs the bot can see that window). The owner can then
// type  b!claim  on Fluxer to get a fresh code by DM, and type it on Discord to be the owner there too.
import fs from "node:fs";
import { randomInt } from "node:crypto";
import Config from "./ConfigHandler.js";
import { renderBox } from "./GenAuthLink.js";

const newCode = () => String(randomInt(100000, 1000000));
// The code from the start window: valid until it's used.
let startCode = newCode();
// Codes the owner asks for (to claim Discord): valid for 10 minutes.
const dmCodes = new Map();

export const hasFluxerOwner = () => !!Config.OwnerId && !/^0+$/.test(Config.OwnerId);
export const hasDiscordOwner = () => !!Config.OwnerDiscordId;

/** Shown in the start window while there's no owner. */
export function printClaimBox() {
  if (hasFluxerOwner()) return;
  renderBox([
    "Make yourself the bot's owner:",
    "",
    `  In Fluxer, type:   ${Config.BotPrefix}claim ${startCode}`,
    "",
    "This code only appears here, so only you can use it. After that, the",
    "owner can use every command and add admins. Nothing to look up or edit.",
  ]);
}

/** The owner asks for a code to also claim Discord. */
export function codeForDiscord(ownerId) {
  const code = newCode();
  dmCodes.set(code, { by: ownerId, until: Date.now() + 10 * 60_000 });
  return code;
}

/** Save "key: value" into settings.txt, on its existing line if there is one. */
function saveSetting(key, value) {
  let text = "";
  try { text = fs.readFileSync(Config.SettingsFile, "utf-8"); } catch {}
  const lines = text.split(/\r?\n/);
  const at = lines.findIndex((l) => !l.trim().startsWith("#") && l.slice(0, l.indexOf(":")).trim().toLowerCase() === key);
  if (at >= 0) lines[at] = `${key}: ${value}`;
  else lines.push(`${key}: ${value}`);
  fs.writeFileSync(Config.SettingsFile, lines.join("\r\n").replace(/(\r\n)+$/, "") + "\r\n");
}

/**
 * Someone typed  b!claim <code>  on `side` ("fluxer" or "discord").
 * Returns { ok, message }.
 */
export function claim(side, userId, code) {
  if (side === "fluxer") {
    if (hasFluxerOwner()) return { ok: false, message: "This bot already has an owner." };
    if (code !== startCode) return { ok: false, message: "That code isn't right. The code is shown in the window where the bot is running." };
    Config.OwnerId = userId;
    if (!Config.AdminAccountIds.includes(userId)) Config.AdminAccountIds.unshift(userId);
    saveSetting("owner fluxer id", userId);
    startCode = newCode(); // used up
    return { ok: true, message: `You're the owner now. You can use every command, and add admins with \`${Config.BotPrefix}admins add <name>\`.\nWant to be the owner on Discord too? Type \`${Config.BotPrefix}claim\` here and I'll DM you a code to type there.` };
  }
  // Discord: needs a code the owner got by DM (or the start-window code, if nobody owns the bot yet).
  if (hasDiscordOwner() && Config.OwnerDiscordId !== userId) return { ok: false, message: "This bot already has an owner on Discord." };
  const dm = dmCodes.get(code);
  const valid = (dm && dm.until > Date.now()) || (!hasFluxerOwner() && code === startCode);
  if (!valid) return { ok: false, message: "That code isn't right, or it expired. The owner can type `b!claim` on Fluxer to get a new one." };
  dmCodes.delete(code);
  Config.OwnerDiscordId = userId;
  if (!Config.AdminAccountIds.includes(userId)) Config.AdminAccountIds.push(userId);
  saveSetting("owner discord id", userId);
  return { ok: true, message: "You're the owner on Discord now too." };
}
