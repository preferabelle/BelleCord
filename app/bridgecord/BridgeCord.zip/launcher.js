// Launcher: this is what the START files run.
// It checks settings.txt, prepares the database, starts the bridge,
// and restarts it automatically if it ever crashes.

import { spawn, spawnSync } from "node:child_process";
import fs from "node:fs";
import path from "node:path";
import { createRequire } from "node:module";
import { fileURLToPath } from "node:url";

const appDir = path.dirname(fileURLToPath(import.meta.url));
process.chdir(appDir);
const require = createRequire(import.meta.url);

function box(lines) {
  const width = Math.max(...lines.map((l) => l.length));
  console.log(`┏━${"━".repeat(width)}━┓`);
  for (const l of lines) console.log(`┃ ${l.padEnd(width)} ┃`);
  console.log(`┗━${"━".repeat(width)}━┛`);
}

const [major, minor] = process.versions.node.split(".").map(Number);
if (major < 20 || (major === 20 && minor < 10)) {
  box([
    `This computer has Node.js ${process.versions.node}, which is too old.`,
    "Install the LTS version from https://nodejs.org, then start again.",
  ]);
  process.exit(0);
}

// settings.txt lives next to the program, unless BRIDGE_SETTINGS_FILE says otherwise (Docker).
const settingsFile = process.env.BRIDGE_SETTINGS_FILE || path.join(appDir, "settings.txt");
if (!fs.existsSync(settingsFile)) {
  // No settings yet: make one from the template, right where it's needed, and say where.
  const inDocker = !!process.env.BRIDGE_SETTINGS_FILE;
  let made = false;
  try {
    fs.mkdirSync(path.dirname(settingsFile), { recursive: true });
    fs.copyFileSync(path.join(appDir, "settings.example.txt"), settingsFile);
    made = true;
  } catch {}
  box(
    made
      ? [
          "First start: I created your settings file here:",
          "",
          inDocker ? "  config/settings.txt   (in the folder with docker-compose.yml)" : `  ${settingsFile}`,
          "",
          "Open it, paste your two bot tokens after the colons, and save it.",
          inDocker ? "Then run:   docker compose restart" : "Then start the bridge again.",
          ...(inDocker ? ["", "(On Linux, if it won't save, edit it with:  sudo nano config/settings.txt)"] : []),
        ]
      : [
          "settings.txt is missing, and I couldn't create it.",
          inDocker ? "Put settings.txt in the config folder next to docker-compose.yml," : `It should be here: ${settingsFile}`,
          inDocker ? "then run:   docker compose restart" : "Copy settings.example.txt to settings.txt, fill it in, and start again.",
        ],
  );
  // In Docker, wait a minute before stopping so the log isn't flooded by quick restarts.
  if (inDocker) setTimeout(() => process.exit(0), 60_000);
  else process.exit(0);
  await new Promise(() => {});
}

const { parseSettings } = await import("./utils/Settings.js");
const settings = parseSettings(fs.readFileSync(settingsFile, "utf-8"));
if (settings.problems.length) {
  box(["Notes about settings.txt:", "", ...settings.problems.map((p) => "• " + p)]);
}
if (!settings.fluxerToken) {
  const file = settingsFile;
  const saved = fs.statSync(file).mtime.toLocaleString();
  const line = fs.readFileSync(file, "utf-8").split(/\r?\n/).find((l) => /^\s*fluxer\s*token\s*:/i.test(l.replace(/^\uFEFF/, "")));
  let shown = "(there is no fluxer token line in this file)";
  if (line) {
    const v = line.slice(line.indexOf(":") + 1).trim();
    shown = v ? (v.length > 24 ? v.slice(0, 12) + "..." + v.slice(-4) : v) : "(nothing after the colon)";
  }
  box([
    "The bridge can't find its Fluxer token. Here's what it sees:",
    "",
    "File:        " + file,
    "Last saved:  " + saved,
    "Token line:  " + shown,
    "",
    "If this isn't what your settings.txt shows, the save didn't reach",
    "this file. Open settings.txt from this exact folder, paste the token",
    "after  fluxer token:  press Ctrl+S, and start again.",
  ]);
  process.exit(0);
}

fs.mkdirSync(path.join(appDir, "data"), { recursive: true });

function run(args) {
  return new Promise((resolve) => {
    const child = spawn(process.execPath, args, { cwd: appDir, stdio: "inherit" });
    child.on("exit", (code) => resolve(code ?? 1));
  });
}

console.log("Preparing the database…");
// After an update, fetch any new parts (like the voice part) before starting.
const pkg = JSON.parse(fs.readFileSync(path.join(appDir, "package.json"), "utf-8"));
const missing = Object.keys(pkg.dependencies ?? {}).filter(
  (d) => !fs.existsSync(path.join(appDir, "node_modules", d, "package.json")),
);
if (missing.length) {
  console.log("Downloading new parts from the update. This only happens once...");
  const win = process.platform === "win32";
  const r = spawnSync(win ? "npm.cmd" : "npm", ["install", "--omit=dev", "--no-audit", "--no-fund"], {
    cwd: appDir,
    stdio: "inherit",
    shell: win,
  });
  if (r.status !== 0) {
    box([
      "The new parts didn't finish downloading.",
      "Check your internet connection, then close this window and start again.",
    ]);
    process.exit(1);
  }
}

const tsxCli = require.resolve("tsx/cli");
const migrateCode = await run([tsxCli, "migrate.ts"]);
if (migrateCode !== 0) {
  box([
    "The database setup step failed (see the messages above).",
    "Close this window and start again. If it keeps happening,",
    "copy this window's text and ask for help.",
  ]);
  process.exit(1);
}

let delay = 5;
for (;;) {
  const startedAt = Date.now();
  console.log("Starting the bridge… (keep this window open; minimize it if you like)");
  const code = await run(["index.js"]);

  if (code === 0) {
    console.log("\nThe bridge stopped. You can close this window.");
    process.exit(0);
  }
  if (code === 67) {
    console.log("\nRestarting…");
    delay = 5;
    continue;
  }
  if (Date.now() - startedAt > 5 * 60 * 1000) delay = 5; // it ran fine for a while
  console.log(`\nThe bridge hit a problem. Trying again in ${delay} seconds…`);
  await new Promise((r) => setTimeout(r, delay * 1000));
  delay = Math.min(delay * 2, 120);
}
