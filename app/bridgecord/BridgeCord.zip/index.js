//@ts-check
import { ensureCertificates } from "./utils/Certs.js";
import { printClaimBox } from "./utils/Claim.js";
import { Events as FluxerEvents, Client as FluxerClient } from "@fluxerjs/core";
import {
  Client as DiscordClient,
  Events as DiscordEvents,
  GatewayIntentBits,
  Partials,
} from "discord.js";
import Config from "./utils/ConfigHandler.js";
import {
  FluxerBulkDeleteMessageHandler,
  FluxerCreateMessageHandler,
  FluxerDeleteMessageHandler,
  FluxerPinsUpdateHandler,
  FluxerUpdateMessageHandler,
} from "./utils/FluxerHandler.js";
import {
  DiscordBulkDeleteMessageHandler,
  DiscordCreateMessageHandler,
  DiscordDeleteMessageHandler,
  DiscordPinsUpdateHandler,
  DiscordUpdateMessageHandler,
} from "./utils/DiscordHandler.js";
import { log } from "./utils/Logger.js";
import fs from "node:fs";
import { Op } from "sequelize";
import { ChannelMap, GuildMap, MessageMap } from "./db/index.js";
import { sendErrorMessage } from "./utils/SendErrorMessage.js";
import { genAuthLink, renderBox } from "./utils/GenAuthLink.js";
import { setupReactionHandling } from "./utils/ReactionHandler.js";
import { setupHealthcheck } from "./utils/HealthCheck.js";
import { ensureLoadingEmojis } from "./utils/LoadingEmojiSetup.js";
import path from "node:path";
import { CommandHandler } from "./utils/CommandHandler.js";
import { getGuildPrefix } from "./utils/GetGuildPrefix.js";
import { getFluxerWebappUrl } from "./utils/GetFluxerUrls.js";
import {
  getMirrorByDiscordId,
  getReadyMirrorForDiscordUser,
  isMirrorFluxerId,
  mirrors,
  presenceFromDiscord,
  resolveMirrorNames,
  startMirrors,
  syncAllPresences,
  noteFluxerPresence,
} from "./utils/Mirrors.js";
import { runCatchUp } from "./utils/CatchUp.js";
import { attachHangout, currentVc, resumeVoiceBridge } from "./utils/Hangout.js";
import { attachStreamBridge } from "./utils/StreamBridge.js";
import { startStreamServer } from "./utils/StreamServer.js";
import { refreshAllBios } from "./utils/ChangeBotBio.js";
import { isBotHook, setBotAvatar } from "./utils/BotOnDiscord.js";
import { unmuteSelf } from "./utils/VoiceBridge.js";
import { isTwinBot } from "./utils/TwinVoice.js";
import { announce } from "./utils/Games.js";
import { onDiscordVoiceState } from "./utils/VoicePresence.js";
import { attachDmBridge, onDiscordDM } from "./utils/DmBridge.js";
import { attachKickSync } from "./utils/KickSync.js";
import { attachGames, noteDiscordGameMessage, noteGameMessage } from "./utils/Games.js";
import { startTwins } from "./utils/Twins.js";
import { startServerLink, goneOnDiscord, goneOnFluxer } from "./utils/ServerLink.js";
import { startExtras } from "./utils/Extras.js";
import { attachWordFilter, filterOnDiscord, filterOnFluxer } from "./utils/WordFilter.js";
import {
  buildDiscordUserAgentSuffix,
  buildExtHttpUserAgent,
  buildFluxerUserAgent,
} from "./utils/UserAgent.js";

const discordClient = new DiscordClient({
  rest: {
    timeout: 30_000,
    userAgentAppendix: buildDiscordUserAgentSuffix(),
  },
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildVoiceStates,
    GatewayIntentBits.GuildMessageReactions,
    GatewayIntentBits.GuildMessageTyping,
    GatewayIntentBits.DirectMessages, // DM bridging
    // needed to copy Discord online status onto mirror bots.
    ...(Config.MirrorStatuses
      ? [GatewayIntentBits.GuildPresences, GatewayIntentBits.GuildMembers]
      : []),
  ],
  partials: [Partials.Message, Partials.Channel, Partials.Reaction],
});

export const botStartingTime = new Date();

const maps = await ChannelMap.findAll();

ensureCertificates(); // voice needs security certificates; some systems don't have them

const fluxerClient = new FluxerClient({
  rest: {
    api: Config.FluxerAPIBaseURL,
    userAgent: buildFluxerUserAgent(),
  },
  presence: {
    status: "online",
    customStatus: {
      text: `${Config.BotPrefix}help | bridging ${maps.length} channel${maps.length > 1 ? "s" : ""}`,
    },
  },
  cache: {
    guilds: Infinity,
  },
});

fluxerClient.on(FluxerEvents.Error, (error) => {
  log("FLUXER", error);
});
startServerLink(discordClient, fluxerClient); // bridged servers stay the same on both sides (bb!keepsync)
startExtras(discordClient, fluxerClient); // polls, auto-replies... (utils/extras/)
attachWordFilter(discordClient, fluxerClient); // edits that add a filtered word (bb!filter)
// (a bb!filter command itself has the words in it, so it isn't filtered)
const isFilterCommand = (t) => new RegExp(`^\\s*${Config.BotPrefix.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\s*(filter|filters|wordfilter)\\b`, "i").test(t ?? "");

/**
 * @param {{ discordChannelId?: string, fluxerChannelId?: string, discordGuildId?: string }} where
 */
async function destroyChannelMaps(where) {
  const channelMaps = await ChannelMap.findAll({
    where,
    attributes: ["id"],
  });
  if (channelMaps.length > 0) {
    await MessageMap.destroy({
      where: {
        channelMapId: channelMaps.map((c) => c.get("id")),
      },
    });
  }
  await ChannelMap.destroy({ where });
}

/** @param {import("sequelize").Model} channelMap */
async function isTypingEnabled(channelMap) {
  const guildMaps = await GuildMap.findAll({
    where: {
      [Op.or]: [
        {
          guildId: channelMap.get("discordGuildId"),
          guildType: "discord",
        },
        {
          guildId: channelMap.get("fluxerGuildId"),
          guildType: "fluxer",
        },
      ],
    },
  });
  return !guildMaps.some((g) => g.get("typingEnabled") === false);
}

discordClient.on(DiscordEvents.GuildDelete, async (guild) => {
  if (!guild.available) return;

  try {
    await destroyChannelMaps({ discordGuildId: guild.id });
    await GuildMap.destroy({
      where: {
        guildId: guild.id,
      },
    });
  } catch (e) {
    log("DB", `GuildDelete cleanup failed for guild ${guild.id}`, e);
  }
});

discordClient.on(DiscordEvents.ChannelDelete, async (chnl) => {
  try {
    await goneOnDiscord(chnl); // its bridged Fluxer channel goes too (bb!keepsync)
    await destroyChannelMaps({ discordChannelId: chnl.id });
  } catch (e) {
    log("DB", `ChannelDelete cleanup failed for discord channel ${chnl.id}`, e);
  }
});

discordClient.on(DiscordEvents.ThreadDelete, async (thread) => {
  try {
    await destroyChannelMaps({ discordChannelId: thread.id });
  } catch (e) {
    log("DB", `ThreadDelete cleanup failed for discord thread ${thread.id}`, e);
  }
});

discordClient.on(DiscordEvents.TypingStart, async (type) => {
  if (type.user.id === discordClient.user?.id) return;

  try {
    const channelMap = await ChannelMap.findOne({
      where: {
        discordChannelId: type.channel.id,
      },
    });

    if (!channelMap || !(await isTypingEnabled(channelMap))) return;

    // mirrored people show as typing under their own name.
    const typingMirror = getReadyMirrorForDiscordUser(type.user.id);
    if (typingMirror) {
      try {
        await typingMirror.typing(channelMap.get("fluxerChannelId"));
        return;
      } catch {}
    }

    const channel = await fluxerClient.channels.fetch(
      //@ts-expect-error
      channelMap.fluxerChannelId,
    );
    await channel.sendTyping();
  } catch (e) {
    log("DISCORD", "Failed to relay typing indicator:", e);
  }
});

// mirrors follow their Discord person in and out of the bridged voice channel.
discordClient.on(DiscordEvents.VoiceStateUpdate, (oldState, newState) => {
  try {
    // if someone server-mutes the bot mid-call, unmute it (it's how Fluxer gets heard).
    if (newState?.id === discordClient.user?.id && newState.serverMute && !oldState?.serverMute && currentVc()?.discord) {
      unmuteSelf(newState.guild).catch(() => {});
    }
    onDiscordVoiceState(oldState, newState, currentVc());
  } catch (e) {
    log("MIRROR", "Voice presence error:", e?.message ?? e);
  }
});

discordClient.on(DiscordEvents.MessageCreate, async (msg) => {
  if (msg.author.id === discordClient.user?.id) return;
  if (isTwinBot(msg.author.id)) return; // a personal bot speaking for a Fluxer person (already on Fluxer)
  if (msg.webhookId && isBotHook(msg.webhookId)) return; // the bot's own posts are already on Fluxer
  // DMs to the Discord bot:
  if (!msg.guildId) {
    const prefix = Config.BotPrefix.toLowerCase();
    const text = (msg.content ?? "").trim();
    // a command (like b!help): answer it right here
    if (text.toLowerCase().replace(/\s+/, "").startsWith(prefix.replace(/\s+/g, ""))) {
      await CommandHandler(msg, discordClient, fluxerClient).catch((e) => log("META", "DM command error:", e?.message ?? e));
      return;
    }
    // the owner messaging their own bot: don't send it back to themselves
    if (Config.OwnerDiscordId && msg.author.id === Config.OwnerDiscordId) {
      await msg.reply(`This is your bot's DM. Commands work here, like \`${Config.BotPrefix}help\`. To message someone on Fluxer, DM their linked bot (or reply to a message they sent you here).`).catch(() => {});
      return;
    }
    // anyone else: it goes to the owner on Fluxer (through the sender's mirror, if they have one)
    await onDiscordDM(msg).catch((e) => log("MIRROR", "DM bridge error:", e?.message ?? e));
    return;
  }
  if (!isFilterCommand(msg.content) && (await filterOnDiscord(msg, discordClient).catch(() => false))) return; // a filtered word (bb!filter)
  if (noteDiscordGameMessage(msg)) return; // a right trivia answer is deleted, not bridged
  try {
    await DiscordCreateMessageHandler(msg, discordClient, fluxerClient);
  } catch (e) {
    await sendErrorMessage(msg, discordClient, fluxerClient, e, true);
  }
});

discordClient.on(DiscordEvents.MessageUpdate, async (oldMsg, newMsg) => {
  if (newMsg?.author && isTwinBot(newMsg.author.id)) return; // personal bots' edits came from Fluxer
  try {
    await DiscordUpdateMessageHandler(oldMsg, newMsg, fluxerClient);
  } catch (e) {
    await sendErrorMessage(newMsg, discordClient, fluxerClient, e);
  }
});

discordClient.on(DiscordEvents.MessageDelete, async (msg) => {
  try {
    await DiscordDeleteMessageHandler(msg, fluxerClient);
  } catch (e) {
    log("FLUXER", e);
  }
});

discordClient.on(DiscordEvents.MessageBulkDelete, async (msgs) => {
  try {
    await DiscordBulkDeleteMessageHandler(msgs, fluxerClient);
  } catch (e) {
    log("FLUXER", e);
  }
});

// copy Discord status (online/idle/dnd/offline + status text) onto mirrors.
discordClient.on(DiscordEvents.PresenceUpdate, (_oldPresence, presence) => {
  if (!Config.MirrorStatuses) return;
  const mirror = getMirrorByDiscordId(presence?.userId);
  if (mirror) mirror.setPresence(presenceFromDiscord(presence));
});

// watch what Fluxer shows for each mirror, so status changes can be double-checked.
fluxerClient.on(FluxerEvents.PresenceUpdate, (p) => noteFluxerPresence(p));
fluxerClient.on(FluxerEvents.PresenceUpdateBulk, (bulk) => {
  for (const p of bulk?.presences ?? []) noteFluxerPresence(p);
});

discordClient.on(DiscordEvents.ChannelPinsUpdate, async (channel) => {
  try {
    await DiscordPinsUpdateHandler(channel, fluxerClient);
  } catch (e) {
    log("FLUXER", e);
  }
});

// prob contributed on the sudden deletions, will comment this for now
// fluxerClient.on(FluxerEvents.GuildDelete, async (guild) => {
//   if (guild.unavailable) return;

//   await GuildMap.destroy({
//     where: {
//       guildId: guild.id
//     }
//   })
// })

fluxerClient.on(FluxerEvents.ChannelDelete, async (chnl) => {
  try {
    await goneOnFluxer(chnl); // its bridged Discord channel goes too (bb!keepsync)
    await destroyChannelMaps({ fluxerChannelId: chnl.id });
  } catch (e) {
    log("DB", `ChannelDelete cleanup failed for fluxer channel ${chnl.id}`, e);
  }
});

fluxerClient.on(FluxerEvents.MessageCreate, async (msg) => {
  try {
    if (msg.author.id === fluxerClient.user?.id) return;
    // DMs to the bridge bot itself only run commands (like bb!bridge with a token).
    if (!msg.guildId) {
      if (!msg.author.bot && msg.content?.trim().toLowerCase().startsWith(Config.BotPrefix.toLowerCase())) {
        await CommandHandler(msg, discordClient, fluxerClient);
      }
      return;
    }
    if (!isFilterCommand(msg.content) && (await filterOnFluxer(msg, fluxerClient).catch(() => false))) return; // a filtered word (bb!filter)
    if (noteGameMessage(msg)) return; // a right trivia answer is deleted, not bridged
    // mirror bots only ever post things that came from Discord.
    if (isMirrorFluxerId(msg.author.id)) return;
    if (Config.PracticeMode) {
      // No Discord yet: only commands (like practice) run.
      if (msg.guildId && msg.content?.startsWith(await getGuildPrefix(msg.guildId))) {
        await CommandHandler(msg, discordClient, fluxerClient);
      }
      return;
    }
    await FluxerCreateMessageHandler(msg, fluxerClient, discordClient);
  } catch (e) {
    await sendErrorMessage(msg, discordClient, fluxerClient, e, true);
  }
});
fluxerClient.on(FluxerEvents.MessageUpdate, async (oldMsg, newMsg) => {
  try {
    await FluxerUpdateMessageHandler(oldMsg, newMsg, discordClient);
  } catch (e) {
    if (newMsg.partial) {
      log("FLUXER", "An error occurred", e);
    } else {
      await sendErrorMessage(newMsg, discordClient, fluxerClient, e);
    }
  }
});
fluxerClient.on(FluxerEvents.MessageDelete, async (msg) => {
  try {
    await FluxerDeleteMessageHandler(msg, discordClient, fluxerClient);
  } catch (e) {
    log("DISCORD", e);
  }
});

fluxerClient.on(FluxerEvents.MessageDeleteBulk, async (msgs) => {
  try {
    await FluxerBulkDeleteMessageHandler(msgs, discordClient);
  } catch (e) {
    log("DISCORD", e);
  }
});

fluxerClient.on(FluxerEvents.ChannelPinsUpdate, async (chnl) => {
  try {
    await FluxerPinsUpdateHandler(chnl, discordClient, fluxerClient);
  } catch (e) {
    log("DISCORD", e);
  }
});

fluxerClient.on(FluxerEvents.TypingStart, async (type) => {
  if (type.userId === fluxerClient.user?.id) return;
  if (Config.PracticeMode || isMirrorFluxerId(type.userId)) return;

  try {
    const channelMap = await ChannelMap.findOne({
      where: {
        fluxerChannelId: type.channelId,
      },
    });

    if (!channelMap || !(await isTypingEnabled(channelMap))) return;

    const channel = await discordClient.channels.fetch(
      //@ts-expect-error
      channelMap.discordChannelId,
    );
    if (channel && channel.isSendable()) await channel.sendTyping();
  } catch (e) {
    log("FLUXER", "Failed to relay typing indicator:", e);
  }
});

let discordReady = false;
let fluxerReady = false;
/** @type {null | (() => void)} */
let startVoiceRecovery = null;

/** @param {unknown} error */
function isRecoverableRuntimeError(error) {
  const message = error instanceof Error ? error.message : String(error);

  if (!message) return false;

  if (message.includes("Used disallowed intents")) {
    renderBox([
      "Discord refused the bridge's permission switches.",
      "Open your bot in the Discord Developer Portal, go to the Bot page,",
      "and turn ON all three:",
      "  Presence Intent, Server Members Intent, Message Content Intent",
      "then click Save Changes.",
      "",
      "(Or put   mirror statuses: no   in settings.txt, so only",
      " Message Content Intent is needed. Mirrors then won't copy status.)",
      "",
      "The bridge has stopped. Start it again once that's done.",
    ]);
    process.exit(0);
  }

  return [
    "WebSocket error",
    "ECONNRESET",
    "ECONNREFUSED",
    "ETIMEDOUT",
    "EPIPE",
    "UND_ERR_CONNECT_TIMEOUT",
    "Connect Timeout Error",
    "Rate limited",
    "Missing Permissions",
    "Missing Access",
    "You don't have the permissions",
    "_RateLimitError",
  ].some((needle) => message.includes(needle));
}

async function onBothReady() {
  if (!/^\d{15,21}$/.test(Config.FluxerTempEmojiGuildId) || /^0+$/.test(Config.FluxerTempEmojiGuildId)) {
    renderBox([
      "One more setting is needed before bridging starts:",
      "the emoji storage community.",
      "",
      "1. Make a small Fluxer community just for the bridge's emoji.",
      "2. Invite the bridge bot to it (the invite link is printed above).",
      `3. Type ${Config.BotPrefix}id in that community and copy the community number`,
      "   into settings.txt after   emoji community id:",
      "4. Start the bridge again.",
    ]);
    process.exit(0);
  }
  if (!fs.existsSync(Config.DataFolderPath + "/fluxcord.json")) {
    log("META", "Welcome! Doing first-time setup...");
    try {
      // the reply arrows ship in the data folder; download only if missing.
      const readAsset = async (name) => {
        const local = path.join(Config.DataFolderPath, name);
        if (fs.existsSync(local)) return fs.readFileSync(local);
        const res = await fetch(Config.InternalAssetsPrefixUrl + "/" + name, {
          headers: { "User-Agent": buildExtHttpUserAgent() },
        });
        return Buffer.from(await res.arrayBuffer());
      };
      const replyL = await readAsset("reply-l.webp");
      const replyR = await readAsset("reply-r.webp");

      const fluxerGuild = await fluxerClient.guilds.fetch(
        Config.FluxerTempEmojiGuildId,
      );
      try {
        await fluxerGuild?.createEmojisBulk([
          {
            // @ts-ignore
            image: replyL.toString("base64"),
            name: "reply_l",
          },
          {
            // @ts-ignore
            image: replyR.toString("base64"),
            name: "reply_r",
          },
        ]);
      } catch {}

      const fluxerEmojiReplyL = await fluxerClient.resolveEmoji(
        ":reply_l:",
        Config.FluxerTempEmojiGuildId,
      );
      const fluxerEmojiReplyR = await fluxerClient.resolveEmoji(
        ":reply_r:",
        Config.FluxerTempEmojiGuildId,
      );

      let discordEmojiReplyL;
      try {
        discordEmojiReplyL = await discordClient.application?.emojis.create({
          attachment: replyL,
          name: "reply_l",
        });
      } catch {}

      let discordEmojiReplyR;
      try {
        discordEmojiReplyR = await discordClient.application?.emojis.create({
          attachment: replyR,
          name: "reply_r",
        });
      } catch {}

      if (!discordEmojiReplyL || !discordEmojiReplyR) {
        const existing = await discordClient.application?.emojis.fetch();
        discordEmojiReplyL ??= existing?.find((e) => e.name === "reply_l");
        discordEmojiReplyR ??= existing?.find((e) => e.name === "reply_r");
      }

      fs.writeFileSync(
        Config.DataFolderPath + "/fluxcord.json",
        JSON.stringify({
          autoGenerated:
            "This file is made by the bridge. Please do not touch it!",
          fluxerReplyEmoji: {
            replyL: fluxerEmojiReplyL,
            replyR: fluxerEmojiReplyR,
          },
          discordReplyEmoji: {
            replyL: discordEmojiReplyL?.id,
            replyR: discordEmojiReplyR?.id,
          },
        }),
      );
      log("META", "First time setup done! Enjoy using the bot!");
    } catch (e) {
      log("META", "The error was:", e);
      renderBox([
        "First time setup failed!",
        "",
        "The bridge stopped itself so nothing breaks.",
        "Fix that, then start the bridge again.",
        "",
        "If you're stuck, copy this window's text and ask for help.",
              ]);
      process.exit(0);
    }
  } else {
    try {
      const r = fs.readFileSync(
        Config.DataFolderPath + "/fluxcord.json",
        "utf-8",
      );
      const t = JSON.parse(r);
      if (
        !t.fluxerReplyEmoji ||
        !t.fluxerReplyEmoji.replyL ||
        !t.fluxerReplyEmoji.replyR ||
        !t.discordReplyEmoji ||
        !t.discordReplyEmoji.replyL ||
        !t.discordReplyEmoji.replyR
      ) {
        throw new Error(`Corrupted field on fluxcord.json, full file: ${r}`);
      }
    } catch (e) {
      log("META", "The error was:", e);
      renderBox([
        "Corrupted fluxcord.json found!",
        "",
        "The bridge stopped itself so nothing breaks.",
        "Fix that, then start the bridge again.",
        "",
        "If you're stuck, copy this window's text and ask for help.",
              ]);
      process.exit(0);
    }
  }

  try {
    await ensureLoadingEmojis(discordClient, fluxerClient);
  } catch (e) {
    log(
      "META",
      "Loading emoji setup failed, early bridge placeholders will use fallback markers.",
      e,
    );
  }

  if (
    Config.Motds &&
    Config.Motds.length > 0 &&
    // @ts-ignore
    Config.Motds.every((x) => !!x)
  ) {
    setInterval(
      () => {
        motdLoop();
      },
      10 * 60 * 1000,
    );
    motdLoop();
  }

  await printInviteBox();
  printClaimBox();
  // replace the old bot bio everywhere right away.
  refreshAllBios(fluxerClient, discordClient).catch(() => {});

  // re-apply the owner's saved Discord nickname and bot role.

  // resume a saved voice bridge on the Discord side.
  resumeVoiceBridge(discordClient).catch(() => {});

  // link mirrors given by username, copy statuses, then catch up.
  try {
    await resolveMirrorNames(discordClient);
  } catch (e) {
    log("MIRROR", "Couldn't look up mirror names:", e);
  }
  if (Config.MirrorStatuses) {
    syncAllPresences(discordClient);
    // Safety net: re-check every mirror's status every 5 minutes, in case Discord skipped telling us.
    clearInterval(globalThis.__bbStatusSync);
    globalThis.__bbStatusSync = setInterval(() => syncAllPresences(discordClient), 5 * 60 * 1000);
  }
  runCatchUp(discordClient, fluxerClient).catch((e) =>
    log("CATCHUP", "Catch-up stopped early:", e),
  );

  startVoiceRecovery?.();
}


fluxerClient.on(FluxerEvents.Ready, async () => {
  try { setBotAvatar(fluxerClient.user?.avatarURL?.({ size: 256 }) ?? fluxerClient.user?.displayAvatarURL?.()); } catch {} // the bot's Discord picture
  setTimeout(() => refreshAllBios(fluxerClient, null).catch(() => {}), 5000); // new bio
  log(
    "FLUXER",
    `${fluxerClient.user?.username}#${fluxerClient.user?.discriminator} is ready!`,
  );

  fluxerClient.user?.setPresence({
    status: "online",
    customStatus: {
      text: `${Config.BotPrefix}help | bridging ${maps.length} channel${maps.length > 1 ? "s" : ""}`,
    },
  });

  fluxerReady = true;
  if (Config.PracticeMode) {
    printInviteBox().then(() => printClaimBox()).catch(() => {});
    return;
  }
  if (discordReady) onBothReady();
});

discordClient.on(DiscordEvents.ClientReady, async () => {
  log("DISCORD", `${discordClient.user?.tag} is ready!`);
  Config.DiscordClientId =
    discordClient.application?.id ?? discordClient.user?.id ?? Config.DiscordClientId;

  discordClient.user?.setActivity(
    `${Config.BotPrefix}help | bridging ${maps.length} channel${maps.length > 1 ? "s" : ""}`,
  );

  discordReady = true;
  if (fluxerReady) onBothReady();
});

process.on("uncaughtException", (error) => {
  log("META", "A uncaught exception occurred.", error);

  if (isRecoverableRuntimeError(error)) {
    log(
      "META",
      "Ignoring recoverable runtime error and keeping the process alive.",
    );
    return;
  }

  try {
    discordClient.destroy();
  } catch {}

  try {
    fluxerClient.destroy();
  } catch {}

  process.exit(1);
});

// @ts-ignore
process.on(
  "unhandledRejection",
  /** @param {unknown} reason */
  (reason, promise) => {
    log("META", "A unhandled rejection occurred.", reason);

    if (isRecoverableRuntimeError(reason)) {
      log(
        "META",
        "Ignoring recoverable runtime rejection and keeping the process alive.",
      );
      return;
    }

    try {
      discordClient.destroy();
    } catch {}

    try {
      fluxerClient.destroy();
    } catch {}

    process.exit(1);
  },
);

/** @type {string[]} */
const discordVoiceTokens = Array.isArray(Config.DiscordVoiceTokens)
  ? Config.DiscordVoiceTokens.filter(Boolean)
  : [];
/** @type {import("discord.js").Client[]} */
export const discordVoiceClients = [];
for (const [i, token] of discordVoiceTokens.entries()) {
  const voiceClient = new DiscordClient({
    rest: { timeout: 30_000 },
    intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildVoiceStates],
  });
  voiceClient.on(DiscordEvents.ClientReady, () => {
    log(
      "DISCORD",
      `Voice client ${i + 1}/${discordVoiceTokens.length} ready as ${voiceClient.user?.tag}`,
    );
  });
  voiceClient.login(token).catch((e) => {
    log("DISCORD", `Voice client ${i + 1} failed to login`, e);
  });
  discordVoiceClients.push(voiceClient);
}

if (Config.VoiceBridgingEnabled) {
  const voiceHandler = await import("./utils/VoiceHandler.js");
  const { setupVoiceHandling } = voiceHandler;
  startVoiceRecovery = voiceHandler.startVoiceRecovery;
  await setupVoiceHandling(discordClient, fluxerClient, discordVoiceClients);
}

setupReactionHandling(discordClient, fluxerClient);

setupHealthcheck(discordClient, fluxerClient);

/** the invite links, printed where they're needed. */
async function printInviteBox() {
  const webapp = await getFluxerWebappUrl().catch(() => "https://web.fluxer.app");
  const lines = ["Invite links (each one only needs using once):", ""];
  if (!Config.PracticeMode) {
    lines.push(`Discord bot: open this link to add it to your Discord server (or type ${Config.BotPrefix}invite on Fluxer):`);
    lines.push(await genAuthLink(Config.DiscordClientId));
    lines.push("");
  }
  lines.push("Fluxer bot: open this link to add it to your Fluxer community (and your emoji community, if you set one):");
  lines.push(await genAuthLink(fluxerClient.user?.id, true));
  for (const m of mirrors) {
    lines.push("", `Mirror "${m.name}" on Fluxer (skip if it's already in your community):`);
    lines.push(m.inviteLink(webapp));
  }
  renderBox(lines);
}

if (!Config.FluxerBotToken) {
  renderBox([
    "settings.txt doesn't have the bridge's Fluxer token yet.",
    "Paste it after   fluxer token:   and start the bridge again.",
  ]);
  process.exit(0);
}

if (Config.PracticeMode) {
  renderBox([
    "PRACTICE MODE: there's no Discord token in settings.txt yet,",
    "so nothing is bridged. Mirrors still sign in, so you can test them:",
    "",
    `  ${Config.BotPrefix}practice Max hello           (Max's mirror posts "hello")`,
    `  ${Config.BotPrefix}practice status Max dnd art   (changes Max's mirror status)`,
    `  ${Config.BotPrefix}mirrors                       (checks every mirror)`,
    `  ${Config.BotPrefix}id                            (shows IDs for settings.txt)`,
  ]);
} else {
  discordClient.login(Config.DiscordBotToken).catch((e) => handleLoginError("Discord", e));
}
attachHangout(fluxerClient);
attachStreamBridge(fluxerClient);
if (!Config.PracticeMode) startStreamServer(); // streams with BelleCord (needs the Discord side)
attachDmBridge(discordClient);
attachKickSync(discordClient, fluxerClient);
attachGames(discordClient, fluxerClient);
startTwins();
fluxerClient.login(Config.FluxerBotToken).catch((e) => handleLoginError("Fluxer", e));

/**
 * a wrong token stops with a plain explanation instead of
 * restarting forever; network hiccups still restart after a short wait.
 * @param {"Discord" | "Fluxer"} platform
 * @param {any} e
 */
function handleLoginError(platform, e) {
  const text = `${e?.message ?? e} ${e?.code ?? ""} ${e?.statusCode ?? e?.status ?? ""}`;
  if (text.includes("disallowed intents")) {
    isRecoverableRuntimeError(e); // shows the intents box and stops
    return;
  }
  const badToken =
    platform === "Discord"
      ? /TokenInvalid|invalid token/i.test(text)
      : /\b401\b|INVALID_TOKEN|Unauthorized/i.test(text);
  if (badToken) {
    renderBox(
      platform === "Discord"
        ? [
            "Discord rejected the Discord token in settings.txt.",
            "Press Reset Token on your bot's page in the Discord Developer Portal,",
            "paste the new token after   discord token:   and start again.",
          ]
        : [
            "Fluxer rejected the bridge's token in settings.txt.",
            "Copy the bridge bot's token again (or reset it), paste it after",
            "fluxer token:   and start again.",
          ],
    );
    process.exit(0);
  }
  log("META", `Couldn't connect to ${platform} yet: ${e?.message ?? e}`);
  process.exit(1);
}
startMirrors().catch((e) => log("MIRROR", "Mirror start failed:", e));

function checkIfFluxerConnected() {
  if (!fluxerClient.isReady()) {
    log("META", "Fluxer didn't connect after 30 seconds, restarting...");
    process.exit(1);
  }
}

function motdLoop() {
  /**
   * @type {{ text: string, emoji?: string | { fluxer: { name: string, id: string }, discord: string } }[]}
   */
  const motds = Config.Motds;
  const motd = motds[Math.floor(Math.random() * motds.length)];

  //@ts-ignore
  if (motd) updateBotStatus(motd);
}

/**
 * @param {{ text: string, emoji: string | { fluxer: { name: string, id: string }, discord: string } | undefined }} status
 */
function updateBotStatus(status) {
  let emoji = undefined;

  if (status.emoji)
    if (status.emoji instanceof Object) {
      emoji = {
        discord: status.emoji.discord,
        fluxer: {
          emoji_id: status.emoji.fluxer.id,
          emoji_name: status.emoji.fluxer.name,
        },
      };
    } else {
      emoji = {
        discord: status.emoji,
        fluxer: {
          emoji_name: status.emoji,
        },
      };
    }

  fluxerClient.user?.setPresence({
    status: "online",
    customStatus: {
      text: `${Config.BotPrefix}help | ${status.text}`,
      ...(emoji
        ? {
            emojiName: emoji.fluxer.emoji_name,
            emojiId: emoji.fluxer.emoji_id,
          }
        : {}),
    },
  });

  discordClient.user?.setActivity(
    `${emoji?.discord ? `${emoji.discord} ` : ""}${Config.BotPrefix}help | ${status.text}`,
  );
}

setInterval(() => checkIfFluxerConnected(), 30000);
