// bb!keepsync: keep a bridged Fluxer community and Discord server the same as channels change (off until turned on).
//   bb!keepsync        is it on for this pair?
//   bb!keepsync on|off
import { Message as FluxerMessage } from "@fluxerjs/core";
import { linkedFluxerServer, linkedDiscordServer } from "../utils/ServerSync.js";
import { pairOn, setPairOn } from "../utils/ServerLink.js";

/** @type {import('../utils/CommandSchema.d.ts').CommandSchema} */
const command = {
  name: "keepsync",
  aliases: ["serverlink", "livesync"],
  description: "Keep both servers the same when channels are made, renamed, moved or deleted",
  params: "[on | off]",
  access: "owner",
  category: "server",
  additionalInfo: "When it's on, a channel or category made on one side is made on the other and bridged, and renaming, moving or deleting one does the same on the other side. The server's name and icon follow too. Unlink a channel first (bb!unlink) if you want to delete it on one side only.",
  async run(params, message) {
    const onFluxer = message instanceof FluxerMessage;
    const here = String(message.guildId ?? "");
    if (!here) return void (await message.reply("Use this in a server."));
    const fg = onFluxer ? here : await linkedFluxerServer(here);
    const dg = onFluxer ? await linkedDiscordServer(here) : here;
    if (!fg || !dg) return void (await message.reply("This server isn't bridged to anything yet. Bridge some channels first (bb!link)."));
    const want = String(params[0] ?? "").toLowerCase();
    if (want === "on" || want === "off") {
      setPairOn(fg, dg, want === "on");
      return void (await message.reply(want === "on" ? "✓ Keeping both servers the same from now on." : "✓ Stopped. Changes to channels stay on the side they were made on."));
    }
    await message.reply(pairOn(fg, dg) ? "Both servers are kept the same (channels, categories, names and the icon). `bb!keepsync off` stops it." : "Off: changes stay on the side they were made on. `bb!keepsync on` turns it on.");
  },
};
export default command;
