import Config from "../utils/ConfigHandler.js";
import { findFluxerPerson } from "../utils/FindFluxerPerson.js";
import { replaceSetting } from "../utils/SettingsWriter.js";
import { repliedTo } from "../utils/ReplyTarget.js";

/**
 * give someone the owner's command powers (the owner only).
 * @type {import('../utils/CommandSchema.d.ts').CommandSchema}
 */
const command = {
  name: "admins",
  aliases: ["admin"],
  description: "Add or remove admins",
  params: "add <name> | remove <name> | list",
  access: "owner",
  category: "owner",
  async run(params, message, discordClient, fluxerClient) {
    // Understand it however it's typed: "bb!admin someone", "bb!admin @someone", a reply,
    // "bb!admin add someone", "bb!admin give someone", "bb!admin remove someone", "bb!admin list".
    const first = (params[0] ?? "").toLowerCase();
    let kind = "add";
    let nameWords = params;
    if (["add", "give", "make", "grant"].includes(first)) nameWords = params.slice(1);
    else if (["remove", "take", "revoke", "del", "delete", "unadmin"].includes(first)) { kind = "remove"; nameWords = params.slice(1); }
    else if (first === "list") kind = "list";

    const mentioned = [...(message.mentions?.values?.() ?? message.mentions ?? [])].find((u) => u?.id && u.id !== fluxerClient?.user?.id);
    const replied = message.guildId ? await repliedTo(message, fluxerClient).catch(() => null) : null;
    if (kind === "add" && !nameWords.length && !mentioned && !replied?.author) kind = "list";

    if (kind === "list") {
      const extra = Config.ExtraAdmins ?? [];
      return void (await message.reply(`**Admins:** you${extra.length ? ", " + extra.map((a) => a.name).join(", ") : " (nobody else yet)"}.\n-# Add one with \`bb!admins @name\` (or @mention them, or reply to them).`));
    }
    if (message.author.id !== Config.OwnerId) return void (await message.reply("Only the owner can add or remove admins."));

    // Who: an @mention, a reply, or a name.
    let user = null;
    if (mentioned) user = { id: mentioned.id, username: mentioned.username, globalName: mentioned.globalName ?? mentioned.global_name };
    else if (replied?.author && !(replied.webhookId ?? replied.webhook_id)) user = { id: replied.author.id, username: replied.author.username, globalName: replied.author.globalName ?? replied.author.global_name };
    else {
      const text = nameWords.join(" ").trim();
      if (!text) return void (await message.reply("Who? `bb!admins @name`, or @mention them, or reply to their message."));
      const found = await findFluxerPerson(fluxerClient, text);
      user = found.user;
      if (!user) return void (await message.reply(`I can't find "${text}" on Fluxer.${found.maybe?.length ? ` Did you mean: ${found.maybe.join(", ")}?` : " Try @mentioning them instead."}`));
    }
    if (user.id === Config.OwnerId) return void (await message.reply("You're already in charge."));
    if (user.id === fluxerClient?.user?.id) return void (await message.reply("I'm already in charge of myself, thanks."));
    const name = user.username ?? user.globalName ?? user.id;
    Config.ExtraAdmins = Config.ExtraAdmins ?? [];
    if (kind === "add") {
      if (!Config.AdminAccountIds.includes(user.id)) Config.AdminAccountIds.push(user.id);
      if (!Config.ExtraAdmins.some((a) => a.id === user.id)) Config.ExtraAdmins.push({ name, id: user.id });
      replaceSetting("admin", (p) => p.join(" ").includes(user.id), `admin: ${name} | ${user.id}`);
      return void (await message.reply(`Done. **${name}** has your powers now. Every command, no spam limit.`));
    }
    const i = Config.AdminAccountIds.indexOf(user.id);
    if (i >= 0) Config.AdminAccountIds.splice(i, 1);
    Config.ExtraAdmins = Config.ExtraAdmins.filter((a) => a.id !== user.id);
    replaceSetting("admin", (p) => p.join(" ").includes(user.id), null);
    await message.reply(`Done. **${name}** is back to being a regular. `);
  },
};
export default command;
