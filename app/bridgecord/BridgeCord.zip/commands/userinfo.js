import { EmbedBuilder } from "@fluxerjs/core";
import { resolvePerson, discordMembers } from "../utils/WhoIs.js";
const RED = 0xe0301e;
const when = (d) => (d ? `<t:${Math.floor(new Date(d).getTime() / 1000)}:D>` : "unknown");
/** @type {import('../utils/CommandSchema.d.ts').CommandSchema} */
const command = {
  name: "user-info",
  aliases: ["userinfo", "whois"],
  description: "Details about a Discord member",
  params: "<name>",
  access: "admin",
  category: "members",
  async run(params, message, discordClient, fluxerClient) {
    const who = await resolvePerson(message, params, discordClient, fluxerClient);
    if (!who || who.side !== "discord") return void (await message.reply("Who on Discord? `bb!user-info alex`"));
    const user = await discordClient.users.fetch(who.id, { force: true }).catch(() => null);
    const m = (await discordMembers(discordClient, who.id))[0];
    const lines = [
      `**Username:** ${user?.username ?? who.id}${user?.bot ? " (bot)" : ""} · ID ${who.id}`,
      `**Account made:** ${when(user?.createdAt)}`,
      m ? `**Joined ${m.guild.name}:** ${when(m.joinedAt)}` : "Not in a server with me.",
      m ? `**Nickname:** ${m.nickname ?? "none"} · **Top role:** ${m.roles.highest.name}` : null,
      m ? `**Roles:** ${m.roles.cache.filter((r) => r.id !== m.guild.id).map((r) => r.name).join(", ") || "none"}` : null,
      m?.communicationDisabledUntil && m.communicationDisabledUntil > new Date() ? `**Timed out until:** <t:${Math.floor(m.communicationDisabledUntil.getTime() / 1000)}:t>` : null,
      m?.voice?.channel ? `**In voice:** ${m.voice.channel.name}${m.voice.serverMute ? " (server-muted)" : ""}` : null,
      who.mirror ? `**Mirror on Fluxer:** ${who.mirror.name}` : null,
    ].filter(Boolean);
    //@ts-expect-error both apps accept this embed
    await message.reply({ embeds: [new EmbedBuilder().setColor(RED).setTitle(user?.globalName ?? user?.username ?? who.name).setDescription(lines.join("\n")).setImage(user?.displayAvatarURL?.({ size: 256, extension: "png" }) ?? null)] });
  },
};
export default command;
