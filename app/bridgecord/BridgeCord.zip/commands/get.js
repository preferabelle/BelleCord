import { leaveVc } from "../utils/Hangout.js";

/**
 * "bb!voice-leave" - leave the voice channel.
 * @type {import('../utils/CommandSchema.d.ts').CommandSchema}
 */
const command = {
  name: "voice-leave",
  aliases: ["get"],
  description: "Have the bot leave the Fluxer voice channel",
  params: "",
  access: "admin",
  category: "voice",
  async run(params, message) {
    const was = await leaveVc();
    await message.reply(was ? `I was leaving ${was.name} anyway.` : "I'm not even in a voice channel.");
  },
};

export default command;
