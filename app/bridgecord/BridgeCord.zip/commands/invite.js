import Config from "../utils/ConfigHandler.js";
import { genAuthLink } from "../utils/GenAuthLink.js";
import { getFluxerWebappUrl } from "../utils/GetFluxerUrls.js";
import { mirrors } from "../utils/Mirrors.js";

/**
 * every invite link in one place, ready to copy or forward.
 * @type {import('../utils/CommandSchema.d.ts').CommandSchema}
 */
const command = {
  name: "invite",
  aliases: ["invites", "links"],
  description: "Invite links for the bot itself",
  params: "",
  access: "admin",
  category: "bridge",
  async run(params, message, discordClient, fluxerClient) {
    const lines = [];
    if (Config.PracticeMode || !discordClient?.isReady?.()) {
      lines.push(
        "**Discord:** not connected yet. Once the Discord token is in settings.txt and the bridge restarts, type this again to get the Discord invite link.",
      );
    } else {
      lines.push(
        "**Discord:** open this, pick your server, and click Authorize:",
        `<${await genAuthLink(Config.DiscordClientId)}>`,
      );
    }
    lines.push("", "**The bridge bot on Fluxer** (your community and your emoji community):", `<${await genAuthLink(fluxerClient.user?.id, true)}>`);
    const webapp = await getFluxerWebappUrl().catch(() => "https://web.fluxer.app");
    for (const m of mirrors) lines.push("", `**${m.name}'s mirror on Fluxer:**`, `<${m.inviteLink(webapp)}>`);
    await message.reply(lines.join("\n"));
  },
};

export default command;
