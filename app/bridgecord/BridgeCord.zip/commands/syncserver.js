// bb!syncserver: make one side of a bridged pair match the other (owner only). Works from either side.
//   bb!syncserver to discord        the Discord server copies the Fluxer server (also the default)
//   bb!syncserver to fluxer         the Fluxer server copies the Discord server
//   (add "go" to do it, without it it only shows what would change)
//   bb!syncserver to fluxer go      does it (never deletes anything: channels the other side doesn't have go to the bottom)
//   bb!syncserver to fluxer clean   also deletes roles and channels the other side doesn't have (add go to do it)
//   bb!syncserver layout            both sides' channels, the way the bot sees them
//   bb!syncserver <server ID> ...   for a pair that isn't bridged yet (on Discord: the Fluxer server's ID;
//                                   on Fluxer: the Discord server's ID)
// Existing channels are reused and renamed when they're for the same thing; new ones only when nothing matches.
import { Message as FluxerMessage } from "@fluxerjs/core";
import { linkedFluxerServer, linkedDiscordServer, planSync, applySync } from "../utils/ServerSync.js";
import { planSyncToFluxer, applySyncToFluxer } from "../utils/ServerSyncToFluxer.js";

const busy = new Set();

/** @type {import('../utils/CommandSchema.d.ts').CommandSchema} */
const command = {
  name: "syncserver",
  aliases: ["copyfluxer", "mirrorserver", "matchfluxer"],
  description: "Make a Discord server match its Fluxer server, or the other way round (to fluxer / to discord), and bridge it all",
  params: "[to fluxer | to discord] [clean] [go] [layout] [server ID]",
  access: "owner",
  category: "server",
  additionalInfo: "`bb!syncserver to discord` makes the Discord server copy the Fluxer one, `bb!syncserver to fluxer` the other way round. It shows what would change first; add `go` to do it. `clean` also deletes roles and channels the other side doesn't have (bridged channels are never deleted). `bb!syncserver layout` shows both sides as the bot sees them.",
  async run(params, message, discordClient, fluxerClient) {
    const onFluxer = message instanceof FluxerMessage;
    const idParam = params.find((p) => /^\d{15,21}$/.test(p));
    let guild, fid;
    if (onFluxer) {
      fid = String(message.guildId ?? "");
      if (!fid) return void (await message.reply("Do this in a Fluxer server, or in the Discord server it's bridged to."));
      const did = idParam ?? (await linkedDiscordServer(fid));
      if (!did) return void (await message.reply("This Fluxer server isn't bridged to a Discord server yet. Add the Discord server's ID: `bb!syncserver <Discord server ID>`"));
      guild = discordClient.guilds.cache.get(String(did));
      if (!guild) return void (await message.reply("The bot isn't in that Discord server."));
    } else {
      guild = message.guild ?? discordClient.guilds.cache.get(message.guildId);
      if (!guild) return void (await message.reply("Do this in a Discord server, or in the Fluxer server it's bridged to."));
      fid = idParam ?? (await linkedFluxerServer(guild.id));
      if (!fid) return void (await message.reply("This server isn't bridged to a Fluxer server yet. Add the Fluxer server's ID: `bb!syncserver <Fluxer server ID>`"));
    }
    const words = params.map((p) => String(p).toLowerCase());
    const said = " " + words.join(" ") + " ";
    // which side gets changed: "to fluxer" / "from discord" / "fluxer copies discord" -> Fluxer; otherwise Discord
    const toFluxer = /\s(to|onto|into)\s+fluxer\s|\sfrom\s+discord\s|\sfluxer\s+(copies|matches|copy|match)\s|\stofluxer\s/.test(said);
    const clean = words.includes("clean"), go = words.includes("go") || words.includes("yes");
    const disc = onFluxer ? `"${guild.name}" on Discord` : "this Discord server";
    const flux = (name) => (onFluxer ? "this Fluxer server" : `"${name}" on Fluxer`);
    const how = (c, g) => `bb!syncserver to ${toFluxer ? "fluxer" : "discord"}${c ? " clean" : ""}${g ? " go" : ""}`;
    if (busy.has(guild.id)) return void (await message.reply("Already on it. Give me a minute."));
    busy.add(guild.id);
    try {
      const keep = [String(message.channelId ?? message.channel?.id ?? "")]; // (never the channel this was typed in)
      const plan = toFluxer ? await planSyncToFluxer(guild, fluxerClient, fid, { clean, keep }) : await planSync(guild, fluxerClient, fid, { clean, keep });
      // bb!syncserver layout: how both sides look to the bot, side by side
      if (words.includes("layout")) {
        const p = toFluxer ? await planSync(guild, fluxerClient, fid, {}) : plan;
        return void (await message.reply(`**On Fluxer** (what Fluxer tells the bot):\n${p.layout.fluxer}\n\n**On Discord:**\n${p.layout.discord}`.slice(0, 1990)));
      }
      const what = toFluxer ? `**Making ${flux(plan.fluxerName)} copy ${disc}**` : `**Making ${disc} copy ${flux(plan.fluxerName)}**`;
      const list = plan.lines.length ? plan.lines : ["Nothing: it already matches."];
      const shown = list.slice(0, 40).map((l) => "- " + l).join("\n") + (list.length > 40 ? `\n...and ${list.length - 40} more` : "");
      const skip = plan.skipped.length ? `\n\nI can't copy these: ${plan.skipped.slice(0, 10).join(", ")}${plan.skipped.length > 10 ? "..." : ""}` : "";
      const other = `\n-# The other way round: \`bb!syncserver to ${toFluxer ? "discord" : "fluxer"}\``;
      if (!go) {
        return void (await message.reply(`${what} would:\n${shown}${skip}\n\n${plan.lines.length ? `Type \`${how(clean, true)}\` to do it.${clean ? "" : ` (Nothing gets deleted. \`${how(true, false)}\` also deletes roles and channels the other side doesn't have.)`}` : ""}${other}`.slice(0, 1990)));
      }
      if (!plan.lines.length) return void (await message.reply(`It already matches, going by what each side tells the bot. If it doesn't look that way, \`bb!syncserver layout\` shows both sides as the bot sees them.${other}`));
      await message.reply(`On it: ${plan.lines.length} change(s). This can take a few minutes on a big server.`);
      let last = 0;
      const progress = (t) => { if (Date.now() - last > 30000) { last = Date.now(); (message.channel?.send?.(`-# ${t}`) ?? message.reply(`-# ${t}`)).catch?.(() => {}); } };
      const res = toFluxer ? await applySyncToFluxer(guild, fluxerClient, plan, progress) : await applySync(guild, fluxerClient, plan, progress);
      const fails = res.failed.length ? `\n\nThese didn't work:\n${res.failed.slice(0, 12).map((f) => "- " + f).join("\n")}${res.failed.length > 12 ? `\n...and ${res.failed.length - 12} more` : ""}` : "";
      const changed = toFluxer ? flux(plan.fluxerName) : disc, source = toFluxer ? `"${guild.name}"` : `"${plan.fluxerName}"`;
      const send = message.channel?.send ? message.channel.send.bind(message.channel) : message.reply.bind(message);
      await send(`Done: ${changed} now matches ${source}. ${plan.counts.roles} role(s), ${plan.counts.channels} channel(s) and ${plan.counts.bridges} new bridge(s)${plan.counts.removed ? `, ${plan.counts.removed} removed` : ""}.${fails}`.slice(0, 1990)).catch(() => {});
    } catch (e) {
      await message.reply(`That didn't work: ${e?.message ?? e}`);
    } finally { busy.delete(guild.id); }
  },
};
export default command;
