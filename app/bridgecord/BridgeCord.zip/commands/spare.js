import { spare } from "../utils/KickSync.js";

/** @type {import('../utils/CommandSchema.d.ts').CommandSchema} */
const command = {
  name: "kick-cancel",
  aliases: ["spare"],
  description: "Cancel a pending Discord kick",
  params: "[name]",
  access: "admin",
  category: "members",
  async run(params, message) {
    const spared = spare(params.join(" ").trim() || null);
    await message.reply(spared.length ? `${spared.join(", ")} ${spared.length === 1 ? "lives" : "live"}. This time.` : "Nobody's about to get kicked.");
  },
};
export default command;
