/** @type {import('../utils/CommandSchema.d.ts').CommandSchema} */
const command = {
  name: "roles",
  aliases: [],
  description: "List the Discord server's roles",
  params: "",
  access: "admin",
  category: "server",
  async run(params, message, discordClient) {
    const g = discordClient?.guilds?.cache?.first?.();
    if (!g) return void (await message.reply("I'm not even in a Discord server yet. Somebody invite me."));
    const mine = g.members.me?.roles?.highest;
    const list = [...g.roles.cache.values()].filter((r) => r.id !== g.id).sort((a, b) => b.position - a.position)
      .map((r) => `${mine && r.comparePositionTo(mine) < 0 && !r.managed ? "✓" : "·"} ${r.name} (${r.members.size})`);
    let out = `**Roles in ${g.name}** (✓ = I can give it out)\n`;
    for (const l of list) { if ((out + l).length > 1900) break; out += l + "\n"; }
    await message.reply(out);
  },
};
export default command;
