import { playerOf } from "../utils/Games.js";
import { reaction } from "../utils/Output.js";
import { randomInt } from "node:crypto";
/** @type {import('../utils/CommandSchema.d.ts').CommandSchema} */
const command = {
  name: "roll",
  aliases: ["dice"],
  description: "Roll dice, like 1d20 or 2d6+3",
  params: "[dice]",
  access: "everyone",
  category: "games",
  async run(params, message) {
    const text = (params.join(" ") || "1d20").toLowerCase().replace(/\s+/g, "");
    const terms = text.match(/[+-]?[^+-]+/g) ?? [];
    let total = 0, shown = [], dice = 0, singleD20 = null;
    for (const term of terms) {
      const sign = term.startsWith("-") ? -1 : 1;
      const t = term.replace(/^[+-]/, "");
      const m = t.match(/^(\d*)d(\d+)$/);
      if (m) {
        const n = Math.max(1, Number(m[1] || 1)), sides = Number(m[2]);
        if (n > 50 || sides < 2 || sides > 1000) return void (await message.reply("Up to 50 dice, 2 to 1000 sides. Be reasonable."));
        dice += n;
        const rolls = Array.from({ length: n }, () => 1 + randomInt(sides));
        if (n === 1 && sides === 20 && terms.length <= 2) singleD20 = rolls[0];
        total += sign * rolls.reduce((a, b) => a + b, 0);
        shown.push(`${sign < 0 ? "-" : ""}[${rolls.join(", ")}]`);
      } else if (/^\d+$/.test(t)) {
        total += sign * Number(t);
        shown.push(`${sign < 0 ? "-" : "+"}${t}`);
      } else return void (await message.reply("That's not dice. Like this: `bb!roll 2d6+3`"));
    }
    if (!dice) return void (await message.reply("Roll *what*? `bb!roll 1d20`"));
    const flavor = singleD20 === 20 ? ` NATURAL 20! ${reaction("win", playerOf(message).name) ?? "Nice!"}` : singleD20 === 1 ? ` Natural 1. ${reaction("fail") ?? "Ouch."}` : "";
    await message.reply(`🎲 \`${text}\`: ${shown.join(" ")} = **${total}**${flavor}`);
  },
};
export default command;
