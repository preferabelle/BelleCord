import Config from "../utils/ConfigHandler.js";
import { fluxerGuildFor } from "../utils/DiscordControl.js";
import { ChannelMap } from "../db/index.js";
import { Message as FluxerMessage, Routes as FluxerRoutes } from "@fluxerjs/core";
import { ChannelType } from "discord.js";
import { currentVc, joinVc, leaveVc } from "../utils/Hangout.js";
import { bridgeStatus, playTestTone } from "../utils/VoiceBridge.js";
import { presenceStatus } from "../utils/VoicePresence.js";

const squash = (s) => String(s ?? "").toLowerCase().replace(/[^a-z0-9]/g, "");

/**
 * voice bridging.
 *   bb!voice on <voice channel>              (same name on both sides; or set "default voice channel" in settings.txt)
 *   bb!voice on <Fluxer voice> | <Discord voice>
 *   bb!voice off
 *   bb!voice status
 * @type {import('../utils/CommandSchema.d.ts').CommandSchema}
 */
const command = {
  name: "voice",
  aliases: ["vc"],
  description: "Bridge a voice channel between Fluxer and Discord",
  params: "<on [channel] | off | status | test>",
  access: "admin",
  category: "voice",
  async run(params, message, discordClient, fluxerClient) {
    const [sub, ...rest] = params;
    const word = (sub ?? "status").toLowerCase();

    if (word === "off" || word === "stop") {
      const was = await leaveVc();
      await message.reply(was ? `Voice bridge off. I left ${was.name}.` : "I wasn't bridging voice.");
      return;
    }

    if (word === "test") {
      const want = currentVc();
      if (!want?.discord) return void (await message.reply("Voice bridge is off. `bb!voice on` first."));
      playTestTone();
      await message.reply("Playing a chime on both sides. If the Discord people can't hear it, the problem's over there, not with me. `bb!voice status` will prove it.");
      return;
    }

    if (word === "status") {
      const want = currentVc();
      const s = bridgeStatus();
      if (!want?.discord) {
        await message.reply(want ? `I'm only sitting in ${want.name}, not bridging. \`bb!voice on\` to bridge it.` : "Voice bridge is off. `bb!voice on` to start it.");
        return;
      }
      const lines = [
        `**Voice bridge:** ${want.name} (Fluxer) ⇄ ${want.discord.name} (Discord)`,
        `Fluxer side: ${s.fluxer}, hearing ${s.fluxerSpeakers} ${s.fluxerSpeakers === 1 ? "person" : "people"}`,
        `Discord side: ${s.discord}, hearing ${s.discordSpeakers} ${s.discordSpeakers === 1 ? "person" : "people"}`,
        `Relayed so far: ${s.toDiscordSeconds}s to Discord, ${s.toFluxerSeconds}s to Fluxer` +
          (s.heals ? ` · fixed itself ${s.heals} time${s.heals === 1 ? "" : "s"}` : ""),
      ];
      const inVoice = presenceStatus();
      if (inVoice.length) lines.push(`Mirrors in the Fluxer call: ${inVoice.join(", ")}`);
      if (s.twinsInCall?.length) lines.push(`Personal bots in the Discord call: ${s.twinsInCall.join(", ")}`);
      if (s.discordMuted) lines.push("⚠️ My Discord bot is **server-muted**, so Discord people can't hear Fluxer. I'll try to unmute it; if that fails, a Discord moderator has to.");
      if (s.lastDiscordError) lines.push(`-# Last Discord problem: ${s.lastDiscordError}`);
      if (params[1] === "details" && s.voiceLog.length) lines.push("```\n" + s.voiceLog.join("\n") + "\n```");
      if (s.lastFluxerError) lines.push(`-# Last Fluxer problem: ${s.lastFluxerError}`);
      await message.reply(lines.join("\n"));
      return;
    }

    if (word !== "on" && word !== "start") {
      await message.reply("Like this: `bb!voice on`, `bb!voice off`, `bb!voice status`, or `bb!voice test`.");
      return;
    }
    // From Fluxer, or from a bridged Discord channel (then it's that channel's Fluxer community).
    const home = await fluxerGuildFor(message, ChannelMap, FluxerMessage);
    if (!home) {
      await message.reply("Nothing's bridged yet. Bridge a channel first.");
      return;
    }
    if (!discordClient?.isReady?.()) {
      await message.reply("Discord isn't connected, so there's nothing to bridge voice with.");
      return;
    }
    let fChannels = [];
    try { fChannels = await fluxerClient.rest.get(FluxerRoutes.guildChannels(home.guildId)); } catch {}
    const fVoice = (Array.isArray(fChannels) ? fChannels : []).filter((c) => c.type === 2);

    let asked = rest.join(" ") || Config.DefaultVoiceChannel;
    if (!asked) {
      // No channel named: pick it when the answer is obvious.
      const homeIds = new Set((await ChannelMap.findAll({ raw: true }).catch(() => [])).map((m) => m.discordGuildId));
      const dAll = [...discordClient.guilds.cache.values()]
        .filter((g) => !homeIds.size || homeIds.has(g.id))
        .flatMap((g) => [...g.channels.cache.values()].filter((c) => c.type === ChannelType.GuildVoice || c.type === ChannelType.GuildStageVoice));
      const both = fVoice.filter((f) => dAll.some((d) => squash(d.name) === squash(f.name)));
      if (both.length === 1) asked = both[0].name;
      else if (!both.length && fVoice.length === 1 && dAll.length === 1) asked = `${fVoice[0].name} | ${dAll[0].name}`;
      else {
        await message.reply(
          both.length
            ? `Which one? These voice channels are on both sides: ${both.map((c) => `**${c.name}**`).join(", ")}.\nLike this: \`bb!voice on ${both[0].name}\``
            : `Which ones? No voice channel has the same name on both sides, so name both, Fluxer first:\n\`bb!voice on <Fluxer voice channel> | <Discord voice channel>\`\nFluxer: ${fVoice.map((c) => c.name).join(", ") || "none"}\nDiscord: ${dAll.map((c) => c.name).join(", ") || "none"}`,
        );
        return;
      }
    }
    const [fluxerWanted, discordWanted] = asked.split("|").map((x) => x.trim());
    const fKey = squash(fluxerWanted);
    const dKey = squash(discordWanted || fluxerWanted);
    const fSpot = fVoice.find((c) => squash(c.name) === fKey) ?? fVoice.find((c) => squash(c.name).includes(fKey));
    if (!fSpot) {
      await message.reply(`There's no voice channel called "${fluxerWanted}" here on Fluxer.`);
      return;
    }

    let dSpot = null;
    // The server your channels are bridged to comes first (matters while moving servers).
    const bridgedServers = new Set((await ChannelMap.findAll({ raw: true }).catch(() => [])).map((m) => m.discordGuildId));
    const guilds = [...discordClient.guilds.cache.values()].sort((a, b) => Number(bridgedServers.has(b.id)) - Number(bridgedServers.has(a.id)));
    for (const guild of guilds) {
      const voice = [...guild.channels.cache.values()].filter((c) => c.type === ChannelType.GuildVoice || c.type === ChannelType.GuildStageVoice);
      dSpot = voice.find((c) => squash(c.name) === dKey) ?? voice.find((c) => squash(c.name).includes(dKey));
      if (dSpot) break;
    }
    if (!dSpot) {
      await message.reply(`I can't find a Discord voice channel called "${discordWanted || fluxerWanted}". \`bb!channels\` lists them.`);
      return;
    }

    // Updates go where it was asked for (on Discord, the bot also echoes them to Fluxer).
    const notify = message instanceof FluxerMessage
      ? (text) => fluxerClient.channels.fetch(message.channelId).then((c) => c?.send({ content: text })).catch(() => {})
      : (text) => message.reply(text).catch(() => {});
    await joinVc(
      home.guildId,
      fSpot.id,
      fSpot.name,
      notify,
      { guildId: dSpot.guild.id, channelId: dSpot.id, name: dSpot.name },
      discordClient,
    );
    await message.reply(
      `Bridging voice: **${fSpot.name}** (Fluxer) ⇄ **${dSpot.name}** (Discord). Give me a few seconds to get into both.\n` +
        "-# Voices come through me on both sides. Mirrors of Discord people show up in the Fluxer call too.",
    );
  },
};

export default command;
