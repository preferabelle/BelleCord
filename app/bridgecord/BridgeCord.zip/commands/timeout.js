import { onMember } from "../utils/MemberCommand.js";
import { parseDuration } from "../utils/DiscordControl.js";
/** @type {import('../utils/CommandSchema.d.ts').CommandSchema} */
const command = {
  name: "timeout",
  aliases: ["shush"],
  description: "Time someone out on Discord",
  params: "<name> <10m | 2h | 1d> [reason]",
  access: "admin",
  category: "members",
  async run(params, message, discordClient, fluxerClient) {
    const words = [...params];
    const at = words.findIndex((w) => parseDuration(w) !== null);
    const ms = at >= 0 ? parseDuration(words[at]) : 10 * 60_000;
    const reason = at >= 0 ? words.slice(at + 1).join(" ") || "Timed out via the bridge bot" : "Timed out via the bridge bot";
    const target = at >= 0 ? words.slice(0, at) : words;
    const capped = Math.min(ms, 28 * 86_400_000);
    const label = capped >= 86_400_000 ? `${Math.round(capped / 86_400_000)} day(s)` : capped >= 3600_000 ? `${Math.round(capped / 3600_000)} hour(s)` : `${Math.round(capped / 60_000)} minute(s)`;
    await onMember(message, target, discordClient, fluxerClient, (m) => m.timeout(capped, reason).then(() => label), { verb: "timed out", failVerb: "time them out" });
  },
};
export default command;
