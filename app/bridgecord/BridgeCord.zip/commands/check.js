import { GatewayIntentBits, Routes as DiscordRoutes } from "discord.js";
import { Message as FluxerMessage } from "@fluxerjs/core";
import Config from "../utils/ConfigHandler.js";
import { findDiscordPresence, mirrors } from "../utils/Mirrors.js";
import { twinInviteLink, twins } from "../utils/Twins.js";
import { currentVc } from "../utils/Hangout.js";
import { bridgeStatus } from "../utils/VoiceBridge.js";

const ok = (t) => `✓ ${t}`;
const bad = (t) => `✗ ${t}`;

/**
 * one command that tests every piece and says what's wrong in plain words.
 * @type {import('../utils/CommandSchema.d.ts').CommandSchema}
 */
const command = {
  name: "health",
  aliases: ["check", "doctor"],
  description: "Full health check of the bridge",
  params: "",
  access: "admin",
  category: "bridge",
  async run(params, message, discordClient, fluxerClient) {
    const out = ["**Checkup.** Try not to break anything while I look."];

    // ---- Fluxer + settings ----
    out.push(ok(`Fluxer: signed in as ${fluxerClient.user?.username ?? "me"}`));
    if (!Config.AdminAccountIds.some((x) => !/^0+$/.test(x))) out.push(bad("Nobody has claimed this bot yet. The window where it's running shows a code: type `bb!claim <code>` to become the owner."));
    if (!Config.FluxerTempEmojiGuildId || /^0+$/.test(Config.FluxerTempEmojiGuildId)) out.push(bad("`emoji community id:` isn't set, so Discord's custom emoji won't show on Fluxer."));

    // ---- Discord ----
    const discordUp = discordClient?.isReady?.();
    let mainGuildIds = new Set();
    if (!discordUp) {
      out.push(bad("Discord: not connected. Check `discord token:` in settings.txt, then restart me."));
    } else {
      mainGuildIds = new Set(discordClient.guilds.cache.keys());
      out.push(ok(`Discord: connected as ${discordClient.user.tag}, in ${mainGuildIds.size} server${mainGuildIds.size === 1 ? "" : "s"}`));
      const intents = discordClient.options.intents;
      out.push(intents.has(GatewayIntentBits.DirectMessages) ? ok("Discord DMs: listening") : bad("Discord DMs: not listening. Restart me."));
      if (Config.MirrorStatuses) {
        let seen = 0;
        for (const g of discordClient.guilds.cache.values()) seen += g.presences?.cache?.size ?? 0;
        out.push(seen > 0
          ? ok(`Statuses: I can see ${seen} people's Discord status`)
          : bad("Statuses: I can't see anyone's Discord status. Turn on **Presence Intent** on your bot's page in the Discord Developer Portal, then restart the bot. (Or everyone's just offline.)"));
      }
      let members = 0;
      for (const g of discordClient.guilds.cache.values()) members += g.members?.cache?.size ?? 0;
      out.push(members > 1 ? ok(`Members: I can see ${members} people on Discord`) : bad("Members: I can barely see anyone on Discord. Turn on **Server Members Intent** on your bot's page in the Discord Developer Portal."));
    }

    // ---- Mirrors ----
    out.push("", "**Mirrors** (Fluxer bots for Discord people):");
    if (!mirrors.length) out.push("None yet. Add one: DM me `bb!account <Fluxer bot token> <their Discord username>`.");
    for (const m of mirrors) {
      const bits = [];
      let fine = true;
      if (m.ready) bits.push(`signed in as ${m.tag}`);
      else { fine = false; bits.push(m.signInError ? `can't sign in (${m.signInError}). Reset its token and \`bb!account\` it again` : "still signing in"); }
      if (m.ready && message instanceof FluxerMessage && message.guildId) {
        const here = m.inCommunity(message.guildId);
        if (here === false) { fine = false; bits.push(`not in this community, invite it: <${m.inviteLink()}>`); }
      }
      if (!m.discordId) {
        fine = false;
        bits.push(`not linked to anyone on Discord. Fix: \`bb!account link ${m.name} <their Discord username>\``);
      } else if (discordUp) {
        const user = await discordClient.users.fetch(m.discordId).catch(() => null);
        if (!user) { fine = false; bits.push(`linked to Discord ID ${m.discordId}, but that account doesn't exist`); }
        else {
          let shares = false;
          for (const g of discordClient.guilds.cache.values()) {
            if (await g.members.fetch(m.discordId).catch(() => null)) { shares = true; break; }
          }
          bits.push(`is @${user.username} on Discord`);
          if (!shares) { fine = false; bits.push("but they're not in any Discord server with me, so no status and no DMs"); }
          else if (Config.MirrorStatuses) {
            const p = findDiscordPresence(discordClient, m.discordId);
            const wanted = m.presence?.status === "invisible" ? "offline" : m.presence?.status;
            const shows = m.fluxerShows?.status === "invisible" ? "offline" : m.fluxerShows?.status;
            bits.push(`Discord: ${p?.status ?? "offline"} · sent to Fluxer: ${wanted ?? "nothing yet"} · Fluxer shows: ${shows ?? "unknown"}`);
            if (shows && wanted && shows !== wanted) { fine = false; bits.push("(Fluxer hasn't applied it; I retry by signing the mirror in again)"); }
          }
        }
      }
      out.push(`${fine ? "✓" : "✗"} **${m.name}**: ${bits.join(" · ")}`);
    }

    // ---- Twins ----
    out.push("", "**Personal Discord bots** (for Fluxer people's DMs):");
    if (!twins.length) out.push("None yet. Anyone can add theirs: DM me `bb!account <Discord bot token>`.");
    for (const t of twins) {
      const bits = [];
      let fine = true;
      if (!t.ready) { fine = false; bits.push(t.error ? `can't sign in (${t.error}). They need to reset the token and \`bb!account\` it again` : "still signing in"); }
      else {
        bits.push(`signed in as ${t.tag}`);
        const guilds = await t.client.rest.get(DiscordRoutes.userGuilds()).catch(() => null);
        const shared = (guilds ?? []).filter((g) => mainGuildIds.has(g.id)).length;
        if (!shared) { fine = false; bits.push(`not in the Discord server yet, so it can't DM anyone. A Discord admin opens: <${twinInviteLink(t.botId ?? t.client.user.id)}>`); }
        else bits.push("in the Discord server");
      }
      out.push(`${fine ? "✓" : "✗"} **${t.name}**: ${bits.join(" · ")}`);
    }

    // ---- Voice ----
    const want = currentVc();
    out.push("", "**Voice:**");
    if (!want) out.push("Not in a voice channel. `bb!voice on <channel>` starts the voice bridge.");
    else if (!want.discord) out.push(`Just sitting in ${want.name} (muted, deafened), not bridging.`);
    else {
      const v = bridgeStatus();
      const good = v.fluxer === "connected" && v.discord === "ready";
      out.push(`${good ? "✓" : "✗"} Bridging ${want.name} ⇄ ${want.discord.name}: Fluxer side ${v.fluxer}, Discord side ${v.discord}`);
      if (v.lastDiscordError) out.push(`-# Last Discord problem: ${v.lastDiscordError}`);
      if (v.lastFluxerError) out.push(`-# Last Fluxer problem: ${v.lastFluxerError}`);
    }

    // Send in pieces under the 2000-character limit.
    let chunk = "";
    for (const line of out) {
      if ((chunk + "\n" + line).length > 1900) { await message.reply(chunk); chunk = ""; }
      chunk += (chunk ? "\n" : "") + line;
    }
    if (chunk) await message.reply(chunk);
  },
};

export default command;
