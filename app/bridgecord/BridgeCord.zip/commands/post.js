import { findDiscordChannel } from "../utils/DiscordControl.js";
/** @type {import('../utils/CommandSchema.d.ts').CommandSchema} */
const command = {
  name: "post",
  aliases: [],
  description: "Post a message in any Discord channel",
  params: "<channel> <message>",
  access: "admin",
  category: "server",
  async run(params, message, discordClient) {
    if (!discordClient?.isReady?.()) return void (await message.reply("I'm not connected to Discord right now."));
    const [where, ...rest] = params;
    const text = rest.join(" ").trim();
    const files = [...(message.attachments?.values?.() ?? [])].map((a) => ({ attachment: a.url ?? a.proxy_url, name: a.filename ?? a.name ?? "file" })).filter((f) => f.attachment);
    if (!where || (!text && !files.length)) return void (await message.reply("Like this: `bb!post general hey everyone`"));
    const ch = findDiscordChannel(discordClient, where);
    if (!ch) return void (await message.reply(`There's no Discord channel called "${where}". \`bb!channels\` lists them.`));
    await ch.send({ content: text || undefined, files }).then(() => message.reply(`Posted in #${ch.name}.`)).catch((e) => message.reply(`Discord wouldn't let me post there (${e?.message ?? e}).`));
  },
};
export default command;
