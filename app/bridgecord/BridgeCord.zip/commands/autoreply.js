// bb!autoreply: key phrases the bot answers with a picture or GIF.
import { attachmentsOf } from "../utils/AddonTools.js";
import * as AR from "../utils/extras/AutoReplies.js";

/** @type {import('../utils/CommandSchema.d.ts').CommandSchema} */
const command = {
  name: "autoreply",
  aliases: ["autoreplies", "ar"],
  description: "Key phrases I answer with a picture or GIF (random if there's more than one)",
  params: "[add <phrase> (attach pictures or paste GIF links) | remove <phrase or number> | off/on <phrase>]",
  access: "admin",
  category: "server",
  async run(params, message) {
    const sub = String(params[0] ?? "").toLowerCase();
    const rest = params.slice(1).join(" ").trim();

    if (!sub || sub === "list") {
      const list = AR.list();
      if (!list.length) return void (await message.reply("No auto replies yet. `bb!autoreply add send spaghetti` with pictures attached,."));
      return void (await message.reply(
        "**Auto replies**\n" + list.map((e, i) => `${i + 1}. "${e.phrase}"${e.match === "whole" ? " (whole message)" : ""} - ${e.pics?.length ?? 0} picture${e.pics?.length === 1 ? "" : "s"}${e.text ? ", says something" : ""}${e.on === false ? " - **off**" : ""}`).join("\n").slice(0, 1900) +
        "\n-# `bb!autoreply add <phrase>` with pictures attached adds more. `bb!autoreply remove <phrase>` deletes one.",
      ));
    }

    if (sub === "add") {
      // links pasted after the phrase are pictures too
      const words = rest.split(/\s+/).filter(Boolean);
      const links = words.filter((w) => /^<?https?:\/\//i.test(w)).map((w) => w.replace(/^<|>$/g, ""));
      const phrase = words.filter((w) => !/^<?https?:\/\//i.test(w)).join(" ").replace(/\|\s*$/, "").trim();
      if (!phrase) return void (await message.reply("What should someone say? `bb!autoreply add send spaghetti` with the pictures attached."));
      const files = attachmentsOf(message);
      if (!files.length && !links.length) return void (await message.reply("Attach the pictures or GIFs to the message (or paste GIF links after the phrase)."));
      const e = AR.upsert({ phrase });
      let added = 0;
      const problems = [];
      for (const f of files) await AR.addPicture(e.id, { url: f.url, name: f.name, from: "upload" }).then(() => added++).catch((err) => problems.push(err.message));
      for (const l of links) await AR.addPicture(e.id, { url: l, from: "link" }).then(() => added++).catch((err) => problems.push(err.message));
      const total = AR.find(e.id)?.pics?.length ?? 0;
      return void (await message.reply(`${added ? `Added ${added}.` : "Nothing added."} When someone says "${e.phrase}" I'll post ${total > 1 ? `one of its ${total} pictures at random` : total ? "its picture" : "nothing yet"}.${problems.length ? `\n-# ${[...new Set(problems)].join(" ")}` : ""}`));
    }

    if (sub === "remove" || sub === "delete") {
      const e = AR.find(rest);
      if (!e) return void (await message.reply(`There's no auto reply for "${rest}". \`bb!autoreply\` lists them.`));
      AR.remove(e.id);
      return void (await message.reply(`Removed the auto reply for "${e.phrase}".`));
    }

    if (sub === "off" || sub === "on") {
      const e = AR.find(rest);
      if (!e) return void (await message.reply(`There's no auto reply for "${rest}".`));
      AR.upsert({ id: e.id, on: sub === "on" });
      return void (await message.reply(`"${e.phrase}" is ${sub}.`));
    }

    await message.reply("`bb!autoreply` lists them. `bb!autoreply add send spaghetti` (attach pictures), `bb!autoreply remove send spaghetti`, `bb!autoreply off send spaghetti`.");
  },
};
export default command;
