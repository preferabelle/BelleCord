import { onMember } from "../utils/MemberCommand.js";
/** @type {import('../utils/CommandSchema.d.ts').CommandSchema} */
const command = {
  name: "disconnect",
  aliases: ["vckick"],
  description: "Disconnect someone from Discord voice",
  params: "<name>",
  access: "admin",
  category: "members",
  async run(params, message, discordClient, fluxerClient) {
    await onMember(message, params, discordClient, fluxerClient, async (m) => { if (!m.voice?.channelId) throw new Error("they're not in a voice channel"); await m.voice.disconnect("Bridge bot"); }, { verb: "disconnected", failVerb: "disconnect them", check: false });
  },
};
export default command;
