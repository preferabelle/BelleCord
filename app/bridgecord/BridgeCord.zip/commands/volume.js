import { resolvePerson } from "../utils/WhoIs.js";
import { getLevel, setLevel } from "../utils/VoiceLevels.js";

/** @type {import('../utils/CommandSchema.d.ts').CommandSchema} */
const command = {
  name: "volume",
  aliases: ["vol"],
  description: "Set someone's volume in the voice bridge (0 to 200)",
  params: "<name> [0-200]",
  access: "admin",
  category: "voice",
  async run(params, message, discordClient, fluxerClient) {
    const words = [...params];
    const pct = /^\d{1,3}%?$/.test(words.at(-1) ?? "") ? Number.parseInt(words.pop(), 10) : null;
    const who = await resolvePerson(message, words, discordClient, fluxerClient);
    if (!who) return void (await message.reply("Who? `bb!volume Max 50`, or @mention them, or reply to them."));
    if (pct === null) return void (await message.reply(`${who.name} is at ${getLevel(who.side, who.id)}%. Want me to fix that?`));
    const v = setLevel(who.side, who.id, pct);
    const where = who.side === "discord" ? "on Fluxer" : "on Discord";
    await message.reply(
      v === 0 ? `${who.name} is silent ${where} now. Finally.` : v < 100 ? `${who.name} is turned down to ${v}% ${where}.` : v > 100 ? `${who.name} is turned up to ${v}% ${where}. Your ears, not mine.` : `${who.name} is back to normal ${where}.`,
    );
  },
};
export default command;
