import { Message as FluxerMessage, Routes as FluxerRoutes } from "@fluxerjs/core";
import Config from "../utils/ConfigHandler.js";
import { claim, codeForDiscord, hasFluxerOwner } from "../utils/Claim.js";
import { isOwner } from "../utils/Access.js";

/** @type {import('../utils/CommandSchema.d.ts').CommandSchema} */
const command = {
  name: "claim",
  aliases: [],
  description: "Become the bot's owner with the code from the start window (or, as the owner, get a code for Discord)",
  params: "[code]",
  access: "everyone",
  category: "owner",
  async run(params, message, discordClient, fluxerClient) {
    const side = message instanceof FluxerMessage ? "fluxer" : "discord";
    const code = (params[0] ?? "").trim();

    // The owner, on Fluxer, with no code: DM them a fresh code to type on Discord.
    if (!code && side === "fluxer" && isOwner(message.author.id)) {
      const fresh = codeForDiscord(message.author.id);
      const text = `To be the owner on Discord too, type this in any Discord channel the bot can see (it works for 10 minutes):\n\`${Config.BotPrefix}claim ${fresh}\``;
      const dm = await fluxerClient.rest.post(FluxerRoutes.userMeChannels(), { body: { recipient_id: message.author.id }, auth: true }).catch(() => null);
      const sent = dm?.id && (await fluxerClient.rest.post(FluxerRoutes.channelMessages(dm.id), { body: { content: text }, auth: true }).then(() => true).catch(() => false));
      return void (await message.reply(sent ? "I've sent you a code by DM. Type it on Discord." : "I couldn't DM you. Open your DMs to the bot and try again."));
    }
    if (!code) {
      return void (await message.reply(hasFluxerOwner()
        ? "This bot already has an owner."
        : "Type the code from the window where the bot is running, like `b!claim 123456`."));
    }
    // Don't leave a code sitting in a channel.
    if (message.guildId) {
      if (side === "fluxer") await fluxerClient.rest.delete(FluxerRoutes.channelMessage(message.channelId, message.id), { auth: true }).catch(() => {});
      else await message.delete?.().catch(() => {});
    }
    const result = claim(side, message.author.id, code);
    await message.reply(result.message);
  },
};

export default command;
