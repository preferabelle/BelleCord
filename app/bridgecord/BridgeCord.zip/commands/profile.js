import { checkManageServerPerms } from "../utils/CheckManageServerPerms.js";
import { findBot } from "../utils/FindBot.js";
import { Message as FluxerMessage, Routes as FluxerRoutes } from "@fluxerjs/core";
import Config from "../utils/ConfigHandler.js";
import { getMirrorByDiscordId, getMirrorByName, mirrors } from "../utils/Mirrors.js";
import { getTwinByFluxerId, getTwinByName, twins } from "../utils/Twins.js";
import { setBotAvatar } from "../utils/BotOnDiscord.js";

/** Everything someone is called: username, display name, nickname. */
function namesOf(message) {
  const a = message.author ?? {};
  let member = null;
  try { member = message.member ?? null; } catch {}
  return [a.username, a.globalName, a.global_name, member?.displayName, member?.nick, member?.nickname]
    .filter((n) => n && n.length >= 3)
    .map((n) => n.toLowerCase());
}

/** Find someone's bot by their name when it isn't linked to their account (e.g. "alex-bot" for alex). */
function byName(bots, names, botNames) {
  const match = (bot) => {
    const theirs = botNames(bot).filter(Boolean).map((n) => n.toLowerCase());
    return theirs.some((t) => names.some((n) => t === n || t.includes(n) || (t.length >= 3 && n.includes(t))));
  };
  const hits = bots.filter(match);
  if (hits.length > 1) byName.ambiguous = hits.map((b) => b.tag?.split("#")[0] ?? b.name);
  return hits.length === 1 ? hits[0] : null; // only when it's clearly one bot
}

const MAX_BYTES = 8 * 1024 * 1024;
const USAGE =
  "Change your own bot's look. Attach an image (or paste a link):\n" +
  "`bb!profile picture` · `bb!profile banner` · `bb!profile picture reset`\n" +
  "-# On Discord this changes your Fluxer mirror. On Fluxer it changes your personal Discord bot.";

function sniffImage(b) {
  if (b.length > 8 && b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4e && b[3] === 0x47) return "image/png";
  if (b.length > 3 && b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return "image/jpeg";
  if (b.length > 6 && b.subarray(0, 3).toString("ascii") === "GIF") return "image/gif";
  if (b.length > 12 && b.subarray(0, 4).toString("ascii") === "RIFF" && b.subarray(8, 12).toString("ascii") === "WEBP") return "image/webp";
  return null;
}

/** Download the attached image (or the link) as a Buffer. */
export async function getImage(message, words) {
  const att = [...(message.attachments?.values?.() ?? [])][0];
  const url = att?.url ?? att?.proxy_url ?? words.find((w) => /^https?:\/\//i.test(w));
  if (!url) return { error: "Attach an image, or paste a link to one." };
  const res = await fetch(url, { signal: AbortSignal.timeout(15000) }).catch(() => null);
  if (!res?.ok) return { error: "I couldn't download that image." };
  const data = Buffer.from(await res.arrayBuffer());
  if (data.length > MAX_BYTES) return { error: "That image is too big (8 MB max)." };
  // Look at the actual file, not the label (uploads are often labeled as plain "files").
  const type = sniffImage(data) ?? (/^image\/(png|jpe?g|gif|webp)/i.test(res.headers.get("content-type") ?? "") ? res.headers.get("content-type").split(";")[0] : null);
  if (!type) return { error: "That isn't a PNG, JPG, GIF, or WebP image." };
  return { data, type };
}

/** Change a Fluxer bot (a mirror, or the bridge bot). */
export async function setFluxerLook(client, field, img) {
  const value = img ? `data:${img.type};base64,${img.data.toString("base64")}` : null;
  await client.rest.patch(FluxerRoutes.currentUser(), { body: { [field === "picture" ? "avatar" : "banner"]: value }, auth: true });
}

/** Change a Discord bot (a personal bot, or the Discord bot). Returns the new picture's link. */
export async function setDiscordLook(client, field, img) {
  const before = field === "picture" ? client.user.avatar : client.user.banner;
  const value = img ? `data:${img.type};base64,${img.data.toString("base64")}` : null;
  const user = field === "picture" ? await client.user.setAvatar(value) : await client.user.setBanner(value);
  const after = field === "picture" ? user?.avatar : user?.banner;
  if (img && after && after === before) throw new Error("Discord accepted it but kept the old one");
  return field === "picture" ? user?.displayAvatarURL?.({ size: 256 }) : user?.bannerURL?.({ size: 512 });
}

/**
 * each person changes their own bot's picture and banner.
 * @type {import('../utils/CommandSchema.d.ts').CommandSchema}
 */
const command = {
  name: "profile",
  aliases: ["pfp"],
  description: "Change a linked bot's picture or banner (attach an image)",
  params: "[name] <picture | banner> [reset]",
  access: "admin",
  category: "accounts",
  async run(params, message, discordClient, fluxerClient) {
    const owner = await checkManageServerPerms(message.guildId ?? "", message.author.id, fluxerClient);
    const words = [...params];
    const fieldAt = words.findIndex((w) => /^(picture|pfp|avatar|icon|banner)$/i.test(w));
    if (fieldAt < 0) return void (await message.reply(USAGE));
    const field = /^banner$/i.test(words[fieldAt]) ? "banner" : "picture";
    const named = words.slice(0, fieldAt).join(" ").trim();
    const reset = words.slice(fieldAt + 1).some((w) => /^(reset|remove|clear|none)$/i.test(w));
    const onFluxer = message instanceof FluxerMessage;

    // Whose bot?
    let target = null; // { kind: "fluxer"|"discord", client, label }
    if (named) {
      if (!owner) return void (await message.reply("You can only change your own bot. Leave the name out."));
      const { bot, ambiguous } = findBot(named, fluxerClient, discordClient);
      if (ambiguous) return void (await message.reply(`"${named}" could be ${ambiguous.join(" or ")}. Be more specific.`));
      if (!bot) return void (await message.reply(`No bot called "${named}". \`bb!bot list\` shows them all.`));
      if (!bot.ready) return void (await message.reply(`${bot.label} isn't signed in right now.`));
      target = { kind: bot.kind, client: bot.client, label: bot.main ? (bot.kind === "fluxer" ? "the bridge bot's (Fluxer)" : "the bridge bot's (Discord)") : `${bot.label}'s` };
    } else if (!onFluxer) {
      const m = getMirrorByDiscordId(message.author.id) ?? byName(mirrors, namesOf(message), (x) => [x.name, x.tag?.split("#")[0]]);
      if (!m) return void (await message.reply("You don't have a mirror on Fluxer, so there's nothing to change."));
      if (!m.ready) return void (await message.reply("Your mirror isn't signed in right now. Try again in a bit."));
      target = { kind: "fluxer", client: m.client, label: "your mirror's" };
    } else {
      byName.ambiguous = null;
      const t = getTwinByFluxerId(message.author.id) ?? byName(twins, namesOf(message), (x) => [x.name, x.tag?.split("#")[0], x.client?.user?.username]);
      if (!t && byName.ambiguous) return void (await message.reply(`More than one bot could be yours (${byName.ambiguous.join(", ")}), so I won't guess. Ask an admin to link the right one: \`bb!account <its token> <your Fluxer name>\`.`));
      if (!t) return void (await message.reply("You don't have a linked Discord bot. An admin can link one with `bb!account <Discord bot token> <your name>`."));
      else if (!t.ready) return void (await message.reply("Your Discord bot isn't signed in right now. Try again in a bit."));
      else target = { kind: "discord", client: t.client, label: "your Discord bot's" };
    }

    let img = null;
    if (!reset) {
      img = await getImage(message, words);
      if (img.error) return void (await message.reply(img.error));
    }
    try {
      let link = null;
      if (target.kind === "fluxer") {
        await setFluxerLook(target.client, field, img);
        // the bot's posts on Discord use the bridge bot's picture: refresh it right away.
        if (target.client === fluxerClient && field === "picture") {
          const me = await fluxerClient.rest.get("/users/@me", { auth: true }).catch(() => null);
          if (me?.avatar) setBotAvatar(`https://fluxerusercontent.com/avatars/${me.id}/${me.avatar}.png?size=256`);
          else fluxerClient.user?.avatarURL && setBotAvatar(fluxerClient.user.avatarURL({ size: 256 }));
        }
      } else link = await setDiscordLook(target.client, field, img);
      await message.reply(
        reset
          ? `Done. Removed ${target.label} ${field}.`
          : `Done. ${target.label[0].toUpperCase() + target.label.slice(1)} ${field} is updated. It looks better already.${link ? `\n${link}` : ""}`,
      );
    } catch (e) {
      const why = String(e?.message ?? e);
      const hint = /rate|429|too fast|too many/i.test(why) ? " You're changing it too often. Wait a few minutes." : "";
      await message.reply(`${target.kind === "fluxer" ? "Fluxer" : "Discord"} wouldn't let me change it (${why.slice(0, 150)}).${hint}`);
    }
  },
};

export default command;
