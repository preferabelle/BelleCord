/** @type {import('../utils/CommandSchema.d.ts').CommandSchema} */
const command = {
  name: "create-role",
  aliases: ["makerole"],
  description: "Create a Discord role",
  params: "<name> [#color]",
  access: "admin",
  category: "server",
  async run(params, message, discordClient) {
    const g = discordClient?.guilds?.cache?.first?.();
    if (!g) return void (await message.reply("I'm not even in a Discord server yet. Somebody invite me."));
    const words = [...params];
    const color = /^#?[0-9a-f]{6}$/i.test(words.at(-1) ?? "") ? "#" + words.pop().replace("#", "") : undefined;
    const name = words.join(" ").trim();
    if (!name) return void (await message.reply("Called what, genius? `bb!create-role Cool Kids #ff66aa`"));
    await g.roles.create({ name, color, reason: "Created via the bridge bot" }).then((r) => message.reply(`Made the **${r.name}** role. Give it out with \`bb!role <name> ${r.name}\`.`)).catch((e) => message.reply(`Discord wouldn't let me (${e?.message ?? e}).`));
  },
};
export default command;
