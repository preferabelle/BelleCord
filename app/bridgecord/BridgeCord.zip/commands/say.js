import { forPlatform } from "../utils/Output.js";
import { moodify } from "../utils/Output.js";
import { Message as FluxerMessage, Routes as FluxerRoutes } from "@fluxerjs/core";
import { ChannelMap } from "../db/index.js";
import { botSend } from "../utils/BotOnDiscord.js";

/**
 * make the bot say something, on Fluxer and on Discord. Your command disappears.
 * @type {import('../utils/CommandSchema.d.ts').CommandSchema}
 */
const command = {
  name: "say",
  aliases: ["possess"],
  description: "Have the bot say something on both sides of this channel",
  params: "<message>",
  access: "admin",
  category: "server",
  async run(params, message, discordClient, fluxerClient) {
    let text = (message.content ?? "").replace(/^\s*bb!\s*(say|possess)\s*/i, "").trim();
    if (!text) return void (await message.reply("Say what? `bb!say <message>`"));
    if (!(message instanceof FluxerMessage) || !message.guildId) return void (await message.reply("Use it in a Fluxer channel."));
    await fluxerClient.rest.delete(FluxerRoutes.channelMessage(message.channelId, message.id), { auth: true }).catch(() => {});
    const plain = text;
    text = forPlatform("fluxer", () => moodify(plain)); // (with the right command prefix)
    await fluxerClient.rest.post(FluxerRoutes.channelMessages(message.channelId), { body: { content: text.slice(0, 2000) }, auth: true }).catch(() => {});
    if (!discordClient?.isReady?.()) return;
    const map = await ChannelMap.findOne({ where: { fluxerChannelId: message.channelId }, raw: true }).catch(() => null);
    if (!map) return;
    const ch = await discordClient.channels.fetch(map.discordChannelId).catch(() => null);
    if (ch) await botSend(ch, forPlatform("discord", () => moodify(plain)).slice(0, 2000)).catch(() => {});
  },
};
export default command;
