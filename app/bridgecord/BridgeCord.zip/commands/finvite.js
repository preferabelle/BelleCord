import { Message as FluxerMessage, Routes as FluxerRoutes } from "@fluxerjs/core";
import { ChannelMap } from "../db/index.js";

/**
 * a Fluxer invite link to this community.
 *   bb!finvite            -> lasts a day, unlimited uses
 *   bb!finvite forever    -> never expires
 *   bb!finvite 5          -> only 5 people can use it
 * @type {import('../utils/CommandSchema.d.ts').CommandSchema}
 */
const command = {
  name: "fluxer-invite",
  aliases: ["finvite", "fluxerinvite"],
  description: "Create an invite link to this Fluxer community",
  params: "[forever] [uses]",
  access: "admin",
  category: "bridge",
  async run(params, message, discordClient, fluxerClient) {
    // Which Fluxer channel: where this was typed, or (on Discord) the Fluxer side of this channel.
    let channelId = message instanceof FluxerMessage ? message.channelId : null;
    if (!channelId) {
      const map = await ChannelMap.findOne({ where: { discordChannelId: message.channelId }, raw: true }).catch(() => null);
      channelId = map?.fluxerChannelId ?? null;
    }
    if (!channelId) {
      const any = await ChannelMap.findOne({ raw: true }).catch(() => null);
      channelId = any?.fluxerChannelId ?? null;
    }
    if (!channelId) return void (await message.reply("Use it in a Fluxer channel."));

    const text = params.join(" ").toLowerCase();
    const forever = /\b(forever|permanent|never|always)\b/.test(text);
    const uses = Number.parseInt(text.match(/\b(\d{1,3})\b/)?.[1] ?? "0", 10);
    try {
      const inv = await fluxerClient.rest.post(FluxerRoutes.channelInvites(channelId), {
        body: { max_age: forever ? 0 : 86400, max_uses: uses, unique: true },
        auth: true,
      });
      if (!inv?.code) throw new Error("Fluxer didn't give me a code");
      const base = String(fluxerClient.instance?.endpoints?.invite ?? "https://fluxer.gg").replace(/\/+$/, "");
      const rules = [forever ? "never expires" : "lasts a day", uses ? `${uses} use${uses === 1 ? "" : "s"}` : "unlimited uses"].join(", ");
      await message.reply(`Here, take it: ${base}/${inv.code}\n-# ${rules}.`);
    } catch (e) {
      const why = String(e?.message ?? e);
      const perm = /permission|access|403|50013/i.test(why);
      await message.reply(
        perm
          ? "Fluxer won't let me make invites. Give my role **Create Invite** (Community Settings → Roles → my role), then try again."
          : `Fluxer wouldn't make one (${why.slice(0, 120)}).`,
      );
    }
  },
};

export default command;
