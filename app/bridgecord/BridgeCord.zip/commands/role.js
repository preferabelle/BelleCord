import { onMember } from "../utils/MemberCommand.js";
/** @type {import('../utils/CommandSchema.d.ts').CommandSchema} */
const command = {
  name: "role",
  aliases: [],
  description: "Give or remove a Discord role",
  params: "<name> <role>",
  access: "admin",
  category: "members",
  async run(params, message, discordClient, fluxerClient) {
    // The role is whatever matches a real role at the end; the person is the rest.
    const words = [...params];
    let roleName = null, who = words;
    for (let i = 1; i <= words.length; i++) {
      const tryName = words.slice(i).join(" ").toLowerCase();
      if (!tryName) break;
      const exists = [...discordClient.guilds.cache.values()].some((g) => g.roles.cache.some((r) => r.name.toLowerCase() === tryName));
      if (exists) { roleName = tryName; who = words.slice(0, i); break; }
    }
    if (!roleName) return void (await message.reply("Which role? `bb!role alex VIP` (it has to be a role that exists)."));
    await onMember(message, who, discordClient, fluxerClient, async (m) => {
      const role = m.guild.roles.cache.find((r) => r.name.toLowerCase() === roleName);
      if (!role) return "that server doesn't have the role";
      if (role.managed) throw new Error("that role belongs to a bot or integration, nobody can be given it");
      if (role.comparePositionTo(m.guild.members.me.roles.highest) >= 0) throw new Error(`the role is at or above my own role, so I can't hand it out (drag my role above "${role.name}")`);
      if (m.roles.cache.has(role.id)) { await m.roles.remove(role, "Bridge bot"); return `took away ${role.name}`; }
      await m.roles.add(role, "Bridge bot"); return `gave ${role.name}`;
    }, { verb: "updated roles for", failVerb: "change their roles" });
  },
};
export default command;
