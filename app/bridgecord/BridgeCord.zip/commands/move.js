import { onMember } from "../utils/MemberCommand.js";
import { findVoiceChannel } from "../utils/DiscordControl.js";
/** @type {import('../utils/CommandSchema.d.ts').CommandSchema} */
const command = {
  name: "move",
  aliases: [],
  description: "Move someone to another Discord voice channel",
  params: "<name> <voice channel>",
  access: "admin",
  category: "members",
  async run(params, message, discordClient, fluxerClient) {
    const words = [...params];
    let vc = null, who = words;
    for (let i = 1; i <= words.length && !vc; i++) { const c = findVoiceChannel(discordClient, words.slice(i).join(" ")); if (c && words.slice(i).length) { vc = c; who = words.slice(0, i); } }
    if (!vc) return void (await message.reply("Move them where? `bb!move alex General Voice`"));
    await onMember(message, who, discordClient, fluxerClient, async (m) => { if (!m.voice?.channelId) throw new Error("they're not in a voice channel"); await m.voice.setChannel(vc, "Bridge bot"); return `to ${vc.name}`; }, { verb: "moved", failVerb: "move them", check: false });
  },
};
export default command;
