// bb!pingroles: the roles with the same name on both sides (those pings cross the bridge), and which of them can't be
// pinged by the bridge. "bb!pingroles fix" makes them pingable on both sides.
// (Discord only lets a bridged message ping a role that's set to "Allow anyone to @mention this role".)
import { ChannelMap } from "../db/index.js";

const key = (n) => String(n ?? "").toLowerCase().normalize("NFKC").replace(/[^\p{L}\p{N}]+/gu, "");

/** @type {import('../utils/CommandSchema.d.ts').CommandSchema} */
const command = {
  name: "pingroles",
  description: "Roles with the same name on both sides: pinging one pings the other. 'fix' makes them all pingable",
  params: "[fix]",
  access: "admin",
  category: "server",
  async run(params, message, discordClient, fluxerClient) {
    const fix = /^fix$/i.test(params[0] ?? "");
    const maps = await ChannelMap.findAll({ raw: true }).catch(() => []);
    const pairs = [...new Map(maps.filter((m) => m.discordGuildId && m.fluxerGuildId).map((m) => [`${m.discordGuildId}:${m.fluxerGuildId}`, m])).values()];
    if (!pairs.length) return void (await message.reply("Nothing's bridged yet."));
    const out = [];
    let fixed = 0, failed = 0;
    for (const p of pairs) {
      const dg = await discordClient.guilds.fetch(p.discordGuildId).catch(() => null);
      const fg = await fluxerClient.guilds.fetch(p.fluxerGuildId).catch(() => null);
      if (!dg || !fg) continue;
      const dRoles = [...((await dg.roles.fetch().catch(() => null))?.values() ?? [])].filter((r) => r.name !== "@everyone" && !r.managed);
      const fRoles = [...((await fg.fetchRoles().catch(() => null))?.values?.() ?? [])].filter((r) => r.name !== "@everyone");
      const both = [];
      for (const d of dRoles) {
        const f = fRoles.find((x) => x.name === d.name) ?? fRoles.find((x) => key(x.name) && key(x.name) === key(d.name));
        if (f) both.push([d, f]);
      }
      if (!both.length) { out.push(`**${dg.name}** ↔ **${fg.name}**: no roles with the same name.`); continue; }
      const lines = [];
      for (const [d, f] of both) {
        let dOk = d.mentionable, fOk = !!f.mentionable;
        if (fix && !dOk) { dOk = await d.setMentionable(true, "Bridged role pings").then(() => true).catch(() => false); dOk ? fixed++ : failed++; }
        if (fix && !fOk) { fOk = await fluxerClient.rest.patch(`/guilds/${fg.id}/roles/${f.id}`, { body: { mentionable: true }, auth: true }).then(() => true).catch(() => false); fOk ? fixed++ : failed++; }
        lines.push(`${dOk && fOk ? "✅" : "⚠️"} ${d.name}${!dOk ? " (not pingable on Discord)" : ""}${!fOk ? " (not pingable on Fluxer)" : ""}`);
      }
      out.push(`**${dg.name}** ↔ **${fg.name}**\n${lines.join("\n")}`);
    }
    const tail = fix
      ? (fixed ? `\n-# Made ${fixed} role${fixed === 1 ? "" : "s"} pingable.` : "") + (failed ? `\n-# ${failed} couldn't change: the bot needs Manage Roles, and its role has to be above them.` : "")
      : out.some((x) => x.includes("⚠️")) ? "\n-# ⚠️ ones show up on the other side but don't notify anyone (the bridge isn't allowed to ping roles that aren't pingable). `bb!pingroles fix` makes them pingable on both sides." : "";
    await message.reply((out.join("\n\n") + tail).slice(0, 1990));
  },
};
export default command;
