import { findDiscordChannel } from "../utils/DiscordControl.js";
/** @type {import('../utils/CommandSchema.d.ts').CommandSchema} */
const command = {
  name: "read",
  aliases: ["peek"],
  description: "Read the latest messages from any Discord channel",
  params: "<channel> [count]",
  access: "admin",
  category: "server",
  async run(params, message, discordClient) {
    if (!discordClient?.isReady?.()) return void (await message.reply("I'm not connected to Discord right now."));
    const words = [...params];
    const count = /^\d+$/.test(words.at(-1) ?? "") ? Math.min(15, Math.max(1, Number(words.pop()))) : 8;
    const ch = findDiscordChannel(discordClient, words.join(" "));
    if (!ch) return void (await message.reply(`There's no Discord channel called "${words.join(" ")}". \`bb!channels\` lists them.`));
    const msgs = await ch.messages.fetch({ limit: count }).catch(() => null);
    if (!msgs?.size) return void (await message.reply(`#${ch.name} is empty. Or they won't let me read it.`));
    const lines = [...msgs.values()].reverse().map((m) => {
      const extra = [...m.attachments.values()].map((a) => `<${a.url}>`).join(" ");
      return `**${m.member?.displayName ?? m.author.globalName ?? m.author.username}:** ${(m.content || "").slice(0, 300)}${extra ? " " + extra : ""}`;
    });
    let out = `**#${ch.name}** (latest ${lines.length}):\n`;
    for (const l of lines) { if ((out + l).length > 1900) break; out += l + "\n"; }
    await message.reply({ content: out, allowed_mentions: { parse: [] } });
  },
};
export default command;
