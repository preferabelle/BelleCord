import { blockedWord, filterWords, setFilterWords } from "../utils/WordFilter.js";
/** @type {import('../utils/CommandSchema.d.ts').CommandSchema} */
const command = {
  name: "filter", aliases: ["filters", "wordfilter"], description: "Words that get deleted on both sides (Fluxer and Discord)", access: "admin", category: "server", params: "[add | remove | test] [words]",
  additionalInfo: "`bb!filter` shows the list. `bb!filter add word, another` adds, `bb!filter remove word` takes one off, `bb!filter clear` empties it, `bb!filter test some text` checks if it would be caught. A * on the end catches longer words (bitch* gets bitchy); on both ends it catches the word inside any word.",
  async run(params, message) {
    const what = String(params[0] ?? "").toLowerCase();
    const rest = (message.content ?? "").replace(/^\s*\S+\s*filter\w*\s*\S*\s*/i, "").trim();
    const list = filterWords();
    // (the words are spoilered so the list itself doesn't put them in chat plainly)
    const show = (l) => (l.length ? l.map((w) => `||${w}||`).join(", ") : "nothing yet");
    if (!what) return void (await message.reply(`**Word filter** (both sides): ${show(list)}\n-# \`bb!filter add word\`, \`bb!filter remove word\`, \`bb!filter test some text\``));
    if (what === "add") {
      const add = rest.split(/[,\n]+/).map((w) => w.trim().toLowerCase()).filter(Boolean);
      if (!add.length) return void (await message.reply("Add what? `bb!filter add word, another word`"));
      const now = setFilterWords([...list, ...add]);
      return void (await message.reply(`Added. ${now.length} word${now.length === 1 ? "" : "s"} filtered on both sides.`));
    }
    if (what === "remove" || what === "delete") {
      const gone = rest.split(/[,\n]+/).map((w) => w.trim().toLowerCase()).filter(Boolean);
      const now = setFilterWords(list.filter((w) => !gone.includes(w)));
      return void (await message.reply(now.length < list.length ? `Removed. ${now.length} left.` : "That word wasn't on the list."));
    }
    if (what === "clear" || what === "off") { setFilterWords([]); return void (await message.reply("The word filter is empty now, so it's off.")); }
    if (what === "test") { const hit = blockedWord(rest); return void (await message.reply(hit ? `That would be deleted (it matches ||${hit}||).` : "That's fine, nothing in it is filtered.")); }
    await message.reply("`bb!filter`, `bb!filter add word`, `bb!filter remove word`, `bb!filter clear` or `bb!filter test some text`.");
  },
};
export default command;
