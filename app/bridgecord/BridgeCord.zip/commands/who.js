import Config from "../utils/ConfigHandler.js";
import { getMirrorByDiscordId } from "../utils/Mirrors.js";

const STATUS = { online: "online", idle: "idle", dnd: "dnd", offline: "offline" };

/**
 * find Discord people's IDs (for mirror lines) without Discord.
 * @type {import('../utils/CommandSchema.d.ts').CommandSchema}
 */
const command = {
  name: "who",
  aliases: [],
  description: "Find someone's IDs on Fluxer and Discord",
  params: "<name>",
  access: "admin",
  category: "bridge",
  async run(params, message, discordClient) {
    if (Config.PracticeMode || !discordClient?.isReady?.()) {
      await message.reply(
        "Discord isn't connected yet. Until then, react ℹ️ to one of their bridged messages to see their Discord ID.",
      );
      return;
    }
    const search = params.join(" ").trim().toLowerCase();
    const rows = [];
    for (const guild of discordClient.guilds.cache.values()) {
      let members;
      try {
        members = await guild.members.fetch();
      } catch {
        members = guild.members.cache;
      }
      for (const m of members.values()) {
        if (m.user.bot) continue;
        const names = [m.displayName, m.user.username, m.user.globalName].filter(Boolean);
        if (search && !names.some((n) => n.toLowerCase().includes(search))) continue;
        const mirror = getMirrorByDiscordId(m.id);
        const status = STATUS[m.presence?.status ?? "offline"] ?? "offline";
        rows.push(
          `${m.displayName} (@${m.user.username})  ${m.id}  ${status}${mirror ? `  ← mirror: ${mirror.name}` : ""}`,
        );
      }
    }
    if (rows.length === 0) {
      await message.reply(search ? `Nobody on Discord is called "${search}". Spell it right next time.` : "Nobody's on the Discord side. How sad.");
      return;
    }
    const shown = rows.slice(0, 35);
    await message.reply(
      "```\n" + shown.join("\n") + "\n```" +
        (rows.length > shown.length ? `-# ${rows.length - shown.length} more. Add a name to narrow it: \`${Config.BotPrefix}who max\`\n` : "") +
        "-# The long number is the Discord ID to put on a mirror line in settings.txt.",
    );
  },
};

export default command;
