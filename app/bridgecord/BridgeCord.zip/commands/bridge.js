import { moodify } from "../utils/Output.js";
import { accessLevel } from "../utils/Access.js";
import { Message as FluxerMessage, Routes as FluxerRoutes } from "@fluxerjs/core";
import Config from "../utils/ConfigHandler.js";
import { DISCORD_TOKEN_FIND, FLUXER_TOKEN_FIND, fluxerIdFromToken } from "../utils/Settings.js";
import { replaceSetting } from "../utils/SettingsWriter.js";
import { addMirror, getMirrorByName, linkMirror, mirrors, removeMirror, renameMirror } from "../utils/Mirrors.js";
import { findFluxerPerson } from "../utils/FindFluxerPerson.js";
import { addTwin, checkDiscordToken, getTwinByName, removeTwin, renameTwin, twinInviteLink, twins } from "../utils/Twins.js";

const SNOWFLAKE = /^<?@?!?(\d{15,21})>?$/;

/**
 * Who on Discord is meant? Understands an @mention or a user ID (anywhere in the text), a
 * username, a display name, or "name#1234". If the first word isn't part of the person, it's
 * taken as the name for the mirror: "TTSBOT @someone" = a mirror named TTSBOT for @someone.
 */
export async function resolveDiscordTarget(discordClient, text) {
  const words = String(text ?? "").trim();
  const strip = (x) => x.replace(/#\d{4}$/, "").trim();
  const id = words.match(/<@!?(\d{15,21})>/)?.[1] ?? words.match(/(?:^|\s)@?(\d{15,21})(?=\s|$)/)?.[1];
  if (id) {
    const user = await discordClient.users.fetch(id).catch(() => null);
    const name = words.replace(/<@!?\d{15,21}>/, "").replace(/(?:^|\s)@?\d{15,21}(?=\s|$)/, "").trim() || null;
    return { user, id, name };
  }
  let found = await findDiscordPerson(discordClient, strip(words));
  if (found.user) return { user: found.user, id: found.user.id, name: null };
  const [first, ...more] = words.split(/\s+/);
  if (more.length) {
    const second = await findDiscordPerson(discordClient, strip(more.join(" ")));
    if (second.user) return { user: second.user, id: second.user.id, name: first };
    found = second.maybe?.length ? second : found;
  }
  return { user: null, id: null, name: null, maybe: found.maybe };
}
const wait = (ms) => new Promise((r) => setTimeout(r, ms));

/**
 * Find a Discord person by ID, or by their real username / display name / nickname,
 * across the Discord servers the bot is in. Exact matches win; otherwise one clear
 * partial match. Returns { user } or { maybe: [names] } when it's ambiguous.
 */
export async function findDiscordPerson(discordClient, text) {
  const id = text.match(SNOWFLAKE)?.[1];
  if (id) {
    const user = await discordClient?.users?.fetch(id).catch(() => null);
    return { user };
  }
  const want = text.replace(/^@/, "").toLowerCase();
  const seen = new Map();
  for (const guild of discordClient?.guilds?.cache?.values?.() ?? []) {
    const found = await guild.members.search({ query: want, limit: 20 }).catch(() => null);
    for (const m of [...(found?.values?.() ?? []), ...(guild.members.cache?.values?.() ?? [])]) seen.set(m.user.id, m);
  }
  const names = (m) => [m.user.username, m.user.globalName, m.displayName, m.nickname].filter(Boolean).map((n) => n.toLowerCase());
  const all = [...seen.values()];
  // People first; bots only when no person matches (so a mirror can be made for a Discord bot too).
  for (const members of [all.filter((m) => !m.user.bot), all.filter((m) => m.user.bot)]) {
    const exact = members.find((m) => names(m).includes(want));
    if (exact) return { user: exact.user };
    const partial = members.filter((m) => names(m).some((n) => n.startsWith(want) || n.includes(want)));
    if (partial.length === 1) return { user: partial[0].user };
    if (partial.length > 1) return { user: null, maybe: partial.slice(0, 5).map((m) => m.user.username) };
  }
  return { user: null, maybe: [] };
}

const USAGE = [
  "**How to use bb!bridge.** DM these to me, never in a channel, since tokens are passwords.",
  "`bb!account <Fluxer bot token> <their Discord name>`: make that Fluxer bot someone's mirror. Their name, @mention, or user ID all work. To pick the mirror's name, put it first: `bb!account <token> TTSBOT @someone`.",
  "`bb!account <Discord bot token>`: make that Discord bot yours, so your DMs reach people from it.",
  "`bb!account link <mirror name> <their Discord username>`: point a mirror at the right Discord person.",
  "`bb!account rename <old name> <new name>`: rename a mirror or Discord bot.",
  "`bb!account list`: see every mirror and Discord bot.",
  "`bb!account remove <name>`: unlink one.",
].join("\n");

/**
 * link bots from Fluxer, no settings.txt editing needed.
 * @type {import('../utils/CommandSchema.d.ts').CommandSchema}
 */
const command = {
  name: "account",
  aliases: ["bridge"],
  description: "Set up mirrors and linked bots (DM the bot with a token)",
  params: "<token> [name] | list | remove <name> | rename <old> <new> | relink <mirror> <Discord user>",
  access: "admin",
  category: "accounts",
  async run(params, message, discordClient, fluxerClient) {
    // Bot admins, plus Fluxer community admins (Administrator / Manage Community).
    // Only admins reach this command, so everyone here may manage any account.
    const owner = (await accessLevel(message)) !== "everyone";
    const text = params.join(" ").trim();
    const discordToken = text.match(DISCORD_TOKEN_FIND)?.[0];
    const fluxerToken = discordToken ? null : text.match(FLUXER_TOKEN_FIND)?.[0];

    // A token typed in a channel is already leaked: delete it and refuse it.
    if ((discordToken || fluxerToken) && message.guildId) {
      const warning = moodify("Never post a bot token where people can see it. I deleted it. Reset that token on its bot's page, then DM the new one to this bot.");
      if (message instanceof FluxerMessage) {
        await fluxerClient.rest.delete(FluxerRoutes.channelMessage(message.channelId, message.id), { auth: true }).catch(() => {});
        await fluxerClient.rest.post(FluxerRoutes.channelMessages(message.channelId), { body: { content: warning }, auth: true }).catch(() => {});
      } else {
        await message.delete?.().catch(() => {});
        await message.channel?.send?.({ content: warning }).catch(() => {});
      }
      return;
    }

    const [first, ...rest] = params;
    if (!text) {
      await message.reply(USAGE);
      return;
    }

    if (/^list$/i.test(first)) {
      const m = mirrors.map((x) => `**${x.name}** (Fluxer bot for a Discord person): ${x.ready ? `signed in as ${x.tag}` : x.signInError ? "can't sign in" : "signing in"}, linked to Discord ID ${x.discordId ?? "nobody yet"}`);
      const t = twins.map((x) => {
        const id = x.botId ?? x.client?.user?.id;
        return `**${x.name}** (Discord bot ${x.ready ? x.tag : x.error ? "that can't sign in" : "signing in"}) belongs to Fluxer person <@${x.fluxerId}>${id ? `\n   invite link: <${twinInviteLink(id)}>` : ""}`;
      });
      await message.reply([...m, ...t].join("\n") || "Nothing's linked yet.");
      return;
    }

    if (/^link$/i.test(first)) {
      if (!owner) return void (await message.reply("Only admins can relink mirrors."));
      const [mirrorName, ...personWords] = rest;
      const mirror = getMirrorByName(mirrorName);
      if (!mirror) return void (await message.reply(`There's no mirror called "${mirrorName ?? ""}". Check \`bb!account list\`.`));
      if (!personWords.length) return void (await message.reply(`Who is ${mirror.name} on Discord? \`bb!account link ${mirror.name} <their Discord username>\``));
      if (!discordClient?.isReady?.()) return void (await message.reply("Discord isn't connected, so I can't look anyone up."));
      const { user, maybe } = await resolveDiscordTarget(discordClient, personWords.join(" "));
      if (!user) {
        const hint = maybe?.length ? ` Did you mean: ${maybe.join(", ")}?` : " `bb!who` lists everyone I can see.";
        return void (await message.reply(`I can't find "${personWords.join(" ")}" on Discord.${hint}`));
      }
      linkMirror(mirror, user);
      await message.reply(`Done. **${mirror.name}** is now @${user.username} on Discord. Their status copies over right now, and their DMs route through ${mirror.name}.`);
      return;
    }

    if (/^rename$/i.test(first)) {
      if (!owner) return void (await message.reply("Only admins can rename these."));
      const [oldName, newName] = rest;
      if (!oldName || !newName) return void (await message.reply("Like this: `bb!account rename <old name> <new name>` (one word each)."));
      const mirror = getMirrorByName(oldName);
      if (mirror) {
        renameMirror(mirror, newName);
        return void (await message.reply(`Done. That mirror is called **${newName}** now.`));
      }
      const twin = getTwinByName(oldName);
      if (twin) {
        renameTwin(twin, newName);
        replaceSetting("twin", (p) => p[1] === twin.fluxerId, `twin: ${newName} | ${twin.fluxerId} | ${twin.token}`);
        return void (await message.reply(`Done. That Discord bot is listed as **${newName}** now.`));
      }
      return void (await message.reply(`Nothing's called "${oldName}". Check \`bb!account list\`.`));
    }

    if (/^remove$/i.test(first)) {
      const name = rest.join(" ");
      const mirror = getMirrorByName(name);
      const ownTwin = getTwinByName(name)?.fluxerId === message.author.id;
      if (!owner && !ownTwin) return void (await message.reply("Only admins can unlink these."));
      if (mirror && owner) {
        await removeMirror(mirror);
        replaceSetting("mirror", (p) => fluxerIdFromToken(p[2]) === mirror.fluxerId, null);
        return void (await message.reply(`Done. ${mirror.name}'s mirror is unlinked. `));
      }
      const twin = getTwinByName(name);
      if (twin) {
        removeTwin(twin);
        replaceSetting("twin", (p) => p[1] === twin.fluxerId, null);
        return void (await message.reply(`Done. ${twin.name}'s Discord bot is unlinked. `));
      }
      return void (await message.reply(`Nothing's linked under "${name}". Check \`bb!account list\`.`));
    }

    // ---- A Fluxer bot token: make it a mirror for a Discord person ----
    if (fluxerToken) {
      const fluxerId = fluxerIdFromToken(fluxerToken);
      if (fluxerId === fluxerClient.user?.id) return void (await message.reply("That's MY token. Each mirror needs its own bot."));
      const who = text.replace(fluxerToken, "").trim();
      if (!who) return void (await message.reply("Whose mirror is it? Add their Discord name: `bb!account <token> max`."));
      const online = discordClient?.isReady?.();
      const target = online ? await resolveDiscordTarget(discordClient, who) : { user: null, id: who.match(/(\d{15,21})/)?.[1] ?? null, name: null };
      const person = target.user;
      let discordId = person?.id ?? target.id ?? null;
      if (online && !discordId) {
        const hint = target.maybe?.length ? ` Did you mean: ${target.maybe.join(", ")}?` : "";
        return void (await message.reply(`I can't find "${who}" on Discord.${hint} You can also use their @mention or user ID: \`bb!account <token> <their Discord user ID>\`.`));
      }
      if (!owner) {
        const theirs = discordId ? mirrors.find((m) => m.discordId === discordId) : null;
        if (theirs && theirs.fluxerId !== fluxerId) return void (await message.reply(`${theirs.name} already has a mirror. Remove it first to replace it.`));
        const taken = mirrors.find((m) => m.fluxerId === fluxerId && m.discordId && m.discordId !== discordId);
        if (taken) return void (await message.reply(`That bot is already ${taken.name}'s mirror. Remove it first to move it.`));
      }
      const name = (target.name ?? person?.globalName ?? person?.username ?? (discordId ? `mirror${discordId.slice(-4)}` : who)).replace(/\s+/g, "");
      // Offline: keep the name; the bridge finds that person automatically once Discord connects.
      const discordRef = discordId ?? who.replace(/\s+/g, "");
      const mirror = await addMirror({ name, discordRef, discordId, token: fluxerToken, fluxerId });
      replaceSetting("mirror", (p) => (discordId && p[1] === discordId) || fluxerIdFromToken(p[2]) === fluxerId, `mirror: ${name} | ${discordRef} | ${fluxerToken}`);
      for (let i = 0; i < 20 && !mirror.ready && !mirror.signInError; i++) await wait(500);
      if (mirror.signInError) return void (await message.reply(`Saved, but that Fluxer bot can't sign in (${mirror.signInError}). Check the token.`));
      await message.reply(
        `Done. **${name}** now has a mirror${mirror.ready ? ` (${mirror.tag})` : ""}` +
          (discordId ? `, linked to ${person?.username ?? discordId} on Discord.` : `. I'm not connected to Discord yet, so I'll find "${discordRef}" there by myself once I am.`) +
          `\nIf it isn't in your community yet, invite it: <${mirror.inviteLink()}>`,
      );
      return;
    }

    // ---- A Discord bot token: make it the sender's own Discord bot (a twin) ----
    if (discordToken) {
      let fluxerId = message.author.id;
      let name = message.author.globalName ?? message.author.username ?? "someone";
      // Someone else's bot? Look them up by name/ID (the owner only), and never fall back to the sender.
      const forWhomText = text.replace(discordToken, "").trim();
      if (forWhomText) {
        const { user, maybe } = await findFluxerPerson(fluxerClient, forWhomText);
        if (!owner && user && user.id !== message.author.id) return void (await message.reply("You can only link a Discord bot for yourself. Leave the name off."));
        if (!user) {
          const hint = maybe?.length ? ` Did you mean: ${maybe.join(", ")}?` : " Use their Fluxer username, like `alex_99`.";
          return void (await message.reply(`I can't find "${forWhomText}" on Fluxer, so I didn't link anything.${hint}`));
        }
        fluxerId = user.id;
        name = user.username ?? user.globalName ?? user.id;
      }
      let bot;
      try { bot = await checkDiscordToken(discordToken); } catch (e) {
        return void (await message.reply(`That didn't work: ${e.message}. Reset the token on the bot's page and try again.`));
      }
      addTwin({ name: name.replace(/\s+/g, ""), fluxerId, token: discordToken, botId: bot.id });
      // Replace any old line for this person OR for this same bot (e.g. it was linked to the wrong person).
      replaceSetting("twin", (p) => p[1] === fluxerId || p[2] === discordToken, `twin: ${name.replace(/\s+/g, "")} | ${fluxerId} | ${discordToken}`);
      await message.reply(
        `Linked. ${fluxerId === message.author.id ? "Your" : `**${name}**'s`} DMs to anyone's mirror will now reach them on Discord from **${bot.username}**, with no name tag.\n` +
          `Last step: someone who's an admin on the Discord server opens this link and adds it:\n<${twinInviteLink(bot.id)}>\n` +
          "-# Name the bot the same as you are on Fluxer so people know it's you.",
      );
      return;
    }

    await message.reply(USAGE);
  },
};

export default command;
