import { voiceMute } from "../utils/VoiceMute.js";
/** @type {import('../utils/CommandSchema.d.ts').CommandSchema} */
const command = {
  name: "mute",
  aliases: [],
  description: "Mute someone for everyone in the voice bridge",
  params: "<name>",
  access: "admin",
  category: "voice",
  async run(params, message, discordClient, fluxerClient) { await voiceMute(true, params, message, discordClient, fluxerClient); },
};
export default command;
