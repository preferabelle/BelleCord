import { playerOf, startTrivia, stopTrivia, triviaCategory, triviaChannelFor, triviaRunning } from "../utils/Games.js";

/** @type {import('../utils/CommandSchema.d.ts').CommandSchema} */
const command = {
  name: "trivia",
  aliases: [],
  description: "Start a trivia game for the channel (5 questions)",
  params: "[general | overwatch | minecraft | roblox | online | stop]",
  access: "everyone",
  category: "games",
  async run(params, message) {
    const ch = await triviaChannelFor(message);
    if (!ch) {
      await message.reply("This channel isn't bridged, so I can't run trivia here. Try a bridged one.");
      return;
    }
    if (/^stop$/i.test(params[0] ?? "")) {
      await message.reply(stopTrivia(ch) ? "Trivia's over. You were all losing anyway." : "There's no trivia going on.");
      return;
    }
    const category = triviaCategory(params[0]);
    if (!category) {
      await message.reply("Pick a real one: `overwatch`, `minecraft`, `roblox`, `general`, `online`, or nothing for a mix.");
      return;
    }
    if (triviaRunning(ch)) {
      await message.reply("A game's already going. Pay attention.");
      return;
    }
    await startTrivia(ch, playerOf(message).name, category);
  },
};
export default command;
