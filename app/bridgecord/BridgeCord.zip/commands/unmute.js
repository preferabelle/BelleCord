import { voiceMute } from "../utils/VoiceMute.js";
/** @type {import('../utils/CommandSchema.d.ts').CommandSchema} */
const command = {
  name: "unmute",
  aliases: [],
  description: "Unmute someone in the voice bridge",
  params: "<name>",
  access: "admin",
  category: "voice",
  async run(params, message, discordClient, fluxerClient) { await voiceMute(false, params, message, discordClient, fluxerClient); },
};
export default command;
