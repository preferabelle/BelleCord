import { Message as FluxerMessage, Routes as FluxerRoutes } from "@fluxerjs/core";
import { joinVc } from "../utils/Hangout.js";
import { fluxerGuildFor } from "../utils/DiscordControl.js";
import { ChannelMap } from "../db/index.js";
import Config from "../utils/ConfigHandler.js";

const squash = (s) => String(s ?? "").toLowerCase().replace(/[^a-z0-9]/g, "");

/**
 * "bb!voice-join <channel>" - the bot joins a Fluxer voice channel, muted and deafened.
 * @type {import('../utils/CommandSchema.d.ts').CommandSchema}
 */
const command = {
  name: "voice-join",
  aliases: ["sit"],
  description: "Have the bot join a Fluxer voice channel (muted)",
  params: "[channel]",
  access: "admin",
  category: "voice",
  async run(params, message, discordClient, fluxerClient) {
    const home = await fluxerGuildFor(message, ChannelMap, FluxerMessage);
    if (!home) {
      await message.reply("Nothing's bridged yet.");
      return;
    }
    let channels = [];
    try {
      channels = await fluxerClient.rest.get(FluxerRoutes.guildChannels(home.guildId));
    } catch {}
    const wanted = params.join(" ").trim() || Config.DefaultVoiceChannel;
    if (!wanted) {
      await message.reply("Which voice channel? Like this: `bb!voice-join General`, or set `default voice channel:` in settings.txt.");
      return;
    }
    const target = squash(wanted);
    const voice = (Array.isArray(channels) ? channels : []).filter((c) => c.type === 2);
    const spot = voice.find((c) => squash(c.name) === target) ?? voice.find((c) => squash(c.name).includes(target));
    if (!spot) {
      await message.reply(`There's no voice channel called "${wanted}" here.`);
      return;
    }
    const notify = message instanceof FluxerMessage
      ? (text) => fluxerClient.channels.fetch(message.channelId).then((c) => c?.send({ content: text })).catch(() => {})
      : (text) => message.reply(text).catch(() => {});
    joinVc(home.guildId, spot.id, spot.name, notify);
    await message.reply(`Joining ${spot.name} (muted and deafened).`);
  },
};

export default command;
