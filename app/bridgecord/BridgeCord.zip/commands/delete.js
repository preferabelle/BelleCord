import { Routes as FluxerRoutes } from "@fluxerjs/core";
import { ChannelMap, MessageMap } from "../db/index.js";
import { discordMessageForReply } from "../utils/DiscordControl.js";
/** @type {import('../utils/CommandSchema.d.ts').CommandSchema} */
const command = {
  name: "delete",
  aliases: ["del"],
  description: "Reply to a message to delete it on both sides",
  params: "",
  access: "admin",
  category: "server",
  async run(params, message, discordClient, fluxerClient) {
    const found = await discordMessageForReply(message, discordClient, MessageMap, ChannelMap);
    if (found.error) return void (await message.reply(found.error));
    await found.msg.delete().catch(() => {});
    await fluxerClient.rest.delete(FluxerRoutes.channelMessage(message.channelId, found.fluxerId), { auth: true }).catch(() => {});
    await fluxerClient.rest.delete(FluxerRoutes.channelMessage(message.channelId, message.id), { auth: true }).catch(() => {});
  },
};
export default command;
