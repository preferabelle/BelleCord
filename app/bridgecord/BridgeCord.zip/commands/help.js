import { EmbedBuilder } from "@fluxerjs/core";
import Config from "../utils/ConfigHandler.js";
import { getCommands } from "../utils/CommandHandler.js";
import { accessLevel, accessNeeded } from "../utils/Access.js";

const COLOR = 0x5865f2;
const CATEGORIES = [
  ["info", "ℹ️ Info", "everyone"],
  ["games", "🎮 Games", "everyone"],
  ["bridge", "🌉 Bridging", "admin"],
  ["accounts", "🤖 Mirrors and linked bots", "admin"],
  ["voice", "🔊 Voice", "admin"],
  ["members", "🛡️ Discord members", "admin"],
  ["server", "🏠 Discord server", "admin"],
  ["owner", "👑 Owner", "owner"],
];
const RANK = { everyone: 0, admin: 1, owner: 2 };
const WHO = { everyone: "Everyone", admin: "Admins and the owner", owner: "The owner only" };

/** @type {import('../utils/CommandSchema.d.ts').CommandSchema} */
const command = {
  name: "help",
  aliases: ["commands", "guide"],
  description: "Show commands, a category, or details for one command",
  params: "[category or command]",
  access: "everyone",
  category: "info",
  async run(params, message) {
    const p = Config.BotPrefix;
    const level = await accessLevel(message);
    const all = (await getCommands()).filter((c) => c?.name && !c.hideFromHelp);
    const visible = all.filter((c) => RANK[accessNeeded(c)] <= RANK[level]);
    const want = (params[0] ?? "").toLowerCase().replace(new RegExp(`^${p.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}`), "");
    const embed = new EmbedBuilder().setColor(COLOR);

    // help all: every command you can use, with what it does
    if (want === "all" || want === "everything") {
      const blocks = CATEGORIES.filter(([, , need]) => RANK[need] <= RANK[level]).map(([key, title]) => {
        const list = visible.filter((c) => (c.category ?? "info") === key);
        return list.length ? `**${title}**\n${list.map((c) => `\`${p}${c.name}\` ${c.description}`).join("\n")}` : null;
      }).filter(Boolean);
      const pages = [];
      let cur = "";
      for (const b of blocks) {
        if (cur && cur.length + b.length + 2 > 3900) { pages.push(cur); cur = ""; }
        cur = (cur ? cur + "\n\n" : "") + b.slice(0, 3900);
      }
      if (cur) pages.push(cur);
      for (const page of pages) {
        //@ts-expect-error both apps accept this embed
        await message.reply({ embeds: [new EmbedBuilder().setColor(COLOR).setDescription(page)] });
      }
      return;
    }

    // help <command>
    const one = want && all.find((c) => c.name === want || c.aliases?.includes(want));
    if (one && !CATEGORIES.some(([k]) => k === want)) {
      const need = accessNeeded(one);
      embed
        .setTitle(`${p}${one.name}`)
        .setDescription(
          [
            one.description,
            "",
            `**Usage:** \`${p}${one.name}${one.params ? ` ${one.params}` : ""}\``,
            `**Who can use it:** ${WHO[need]}`,
            one.aliases?.length ? `**Also works as:** ${one.aliases.map((a) => `\`${p}${a}\``).join(", ")}` : "",
            one.additionalInfo ? `\n${one.additionalInfo}` : "",
          ].filter(Boolean).join("\n"),
        );
      //@ts-expect-error both apps accept this embed
      return void (await message.reply({ embeds: [embed] }));
    }

    // help <category>
    const cat = CATEGORIES.find(([k, title]) => k === want || title.toLowerCase().includes(want) && want);
    if (cat) {
      const list = visible.filter((c) => (c.category ?? "info") === cat[0]);
      if (!list.length) return void (await message.reply(RANK[cat[2]] > RANK[level] ? `Those commands are for ${WHO[cat[2]].toLowerCase()}.` : "Nothing here yet."));
      embed
        .setTitle(cat[1])
        .setDescription(list.map((c) => `**\`${p}${c.name}${c.params ? ` ${c.params}` : ""}\`**\n${c.description}`).join("\n\n").slice(0, 4000));
      //@ts-expect-error both apps accept this embed
      return void (await message.reply({ embeds: [embed] }));
    }

    // help (overview)
    const rows = CATEGORIES.filter(([, , need]) => RANK[need] <= RANK[level])
      .map(([key, title]) => {
        const names = visible.filter((c) => (c.category ?? "info") === key).map((c) => `\`${c.name}\``);
        return names.length ? `**${title}** · \`${p}help ${key}\`\n${names.join("  ")}` : null;
      })
      .filter(Boolean);
    embed
      .setTitle(`${Config.BotName} commands`)
      .setDescription(
        `Every command starts with \`${p}\`. Use \`${p}help <category>\` for details, \`${p}help <command>\` for one command, or \`${p}help all\` for everything with what it does.\n\n${rows.join("\n\n")}`,
      )
      .setFooter({ text: level === "everyone" ? "Admins have more commands for managing the bridge." : `You're ${level === "owner" ? "the owner" : "an admin"}, so you can see everything you can use.` });
    //@ts-expect-error both apps accept this embed
    await message.reply({ embeds: [embed] });
  },
};

export default command;
