import { ChannelMap } from "../db/index.js";
/** @type {import('../utils/CommandSchema.d.ts').CommandSchema} */
const command = {
  name: "leave-server",
  aliases: ["leave"],
  description: "Make the bot leave a Discord server",
  params: "<server name>",
  access: "owner",
  category: "bridge",
  async run(params, message, discordClient) {
    if (!discordClient?.isReady?.()) return void (await message.reply("I'm not connected to Discord right now."));
    const squash = (x) => String(x ?? "").toLowerCase().replace(/[^a-z0-9]/g, "");
    const want = params.join(" ").trim();
    const servers = [...discordClient.guilds.cache.values()];
    const g = servers.find((x) => squash(x.name) === squash(want) || x.id === want) ?? servers.find((x) => want && squash(x.name).includes(squash(want)));
    if (!g) return void (await message.reply(`Which one? \`bb!leave-server <server name>\`\n${servers.map((x) => `• ${x.name}`).join("\n")}`));
    const still = (await ChannelMap.findAll({ raw: true })).filter((m) => m.discordGuildId === g.id).length;
    if (still) return void (await message.reply(`${still} channel${still === 1 ? " is" : "s are"} still bridged to **${g.name}**. \`bb!unlink all\` first, so nothing breaks.`));
    await g.leave().then(() => message.reply(`Left **${g.name}**.`)).catch((e) => message.reply(`Discord wouldn't let me leave (${e?.message ?? e}).`));
  },
};
export default command;
