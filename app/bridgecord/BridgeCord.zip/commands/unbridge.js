import fs from "node:fs";
import path from "node:path";
import Config from "../utils/ConfigHandler.js";
import { ChannelMap, MessageMap, sequelize } from "../db/index.js";
import { Op } from "sequelize";
import { BridgeMap } from "../utils/CommandHandler.js";

/**
 * @type {import('../utils/CommandSchema.d.ts').CommandSchema}
 */
/** Where bb!unbridge all remembers the pairs, for bb!link all. */
export const REMEMBER = path.join(Config.DataFolderPath, "last-bridges.json");

const command = {
  name: "unlink",
  aliases: ["unbridge"],
  description: "Unbridge this channel, or every channel at once",
  params: "[all]",
  access: "admin",
  category: "bridge",
  async run(params, message, discordClient, fluxerClient) {
    // bb!unbridge all: unlink every channel at once, and remember the pairs for bb!link all.
    if (/^all$/i.test(params[0] ?? "")) {
      const maps = await ChannelMap.findAll();
      if (!maps.length) return void (await message.reply("Nothing's bridged right now."));
      const remembered = [];
      for (const m of maps) {
        const f = await fluxerClient.channels.fetch(m.fluxerChannelId).catch(() => null);
        const d = await discordClient?.channels?.fetch(m.discordChannelId).catch(() => null);
        remembered.push({ fluxerChannelId: m.fluxerChannelId, fluxerName: f?.name ?? null, discordName: d?.name ?? null, discordServer: d?.guild?.name ?? null, bridgeType: m.bridgeType });
        await unbridgeOne(m, discordClient, fluxerClient);
      }
      try { fs.writeFileSync(REMEMBER, JSON.stringify({ at: new Date().toISOString(), pairs: remembered }, null, 1)); } catch {}
      const list = remembered.map((r) => `#${r.fluxerName ?? r.fluxerChannelId} ↔ #${r.discordName ?? "?"}`).join("\n");
      return void (await message.reply(
        `Unbridged all ${remembered.length}. I remembered every pair:\n${list}\n\n` +
          "Once I'm in the new Discord server, type `bb!link all <new server name>` and I'll link each Fluxer channel to the channel with the same name as before.",
      ));
    }

    const channelMap = await ChannelMap.findOne({
      where: {
        [Op.or]: [
          {
            fluxerChannelId: message.channelId,
          },
          {
            discordChannelId: message.channelId,
          },
        ],
      },
    });

    if (!channelMap) {
      if (BridgeMap.has(message.channelId)) {
        BridgeMap.delete(message.channelId);

        await message.reply("Cancelled.");
        return;
      }

      await message.reply("This channel is already unbridged.");
      return;
    }

    await unbridgeOne(channelMap, discordClient, fluxerClient);
    await message.reply("Unbridged.");
  },
};

/** Remove one link: its webhooks on both sides, its message history, and the link itself. */
export async function unbridgeOne(channelMap, discordClient, fluxerClient) {
  try {
    await discordClient?.deleteWebhook(channelMap.discordWebhookId, { token: channelMap.discordWebhookToken });
  } catch {}
  try {
    const channel = /** @type {TextChannel} */ (await fluxerClient.channels.fetch(channelMap.fluxerChannelId));
    const webhooks = await channel.fetchWebhooks();
    const webhook = webhooks.find((x) => x.id === channelMap.fluxerWebhookId);
    await webhook?.delete();
  } catch {}
  await MessageMap.destroy({ where: { channelMapId: channelMap.id } });
  await channelMap.destroy();
}

export default command;
