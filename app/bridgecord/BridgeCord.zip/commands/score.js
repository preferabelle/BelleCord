import { leaderboard, playerOf, recordOf, recordText } from "../utils/Games.js";

/** @type {import('../utils/CommandSchema.d.ts').CommandSchema} */
const command = {
  name: "stats",
  aliases: ["score", "scores", "leaderboard", "lb"],
  description: "Your game stats, or the leaderboard",
  params: "[top]",
  access: "everyone",
  category: "games",
  async run(params, message) {
    const wantsTop = /^(top|board|all)$/i.test(params[0] ?? "") || /leaderboard|lb/.test(message.content ?? "");
    if (wantsTop) {
      const { rps, trivia } = leaderboard();
      const r = rps.map((x, i) => `${i + 1}. ${x.name}: ${x.w}W ${x.l}L`).join("\n") || "Nobody's played. Cowards.";
      const t = trivia.map((x, i) => `${i + 1}. ${x.name}: ${x.pts} pts`).join("\n") || "Nobody's played.";
      await message.reply(`**Rock paper scissors**\n${r}\n\n**Trivia**\n${t}`);
      return;
    }
    const { rps, trivia } = recordOf(playerOf(message));
    if (!rps && !trivia) {
      await message.reply("You haven't even played. Try `bb!rps rock` or `bb!trivia`.");
      return;
    }
    const parts = [];
    if (rps) parts.push(`Rock paper scissors: ${recordText(rps)}`);
    if (trivia) parts.push(`Trivia: ${trivia.pts} points, ${trivia.wins} game${trivia.wins === 1 ? "" : "s"} won`);
    await message.reply(parts.join("\n") + "\n-# Still not better than me.");
  },
};
export default command;
