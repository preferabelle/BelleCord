import { ChannelMap } from "../db/index.js";
import { discordChannelFor } from "../utils/DiscordControl.js";
/** @type {import('../utils/CommandSchema.d.ts').CommandSchema} */
const command = {
  name: "topic",
  aliases: [],
  description: "Set this channel's topic on Discord",
  params: "<topic>",
  access: "admin",
  category: "server",
  async run(params, message, discordClient) {
    const text = params.join(" ").trim();
    if (!text) return void (await message.reply("To what? `bb!topic no spam allowed`"));
    const ch = await discordChannelFor(message, discordClient, [], ChannelMap);
    if (!ch?.setTopic) return void (await message.reply("Use it in a bridged channel."));
    await ch.setTopic(text.slice(0, 1024), "Bridge bot").then(() => message.reply(`Topic of #${ch.name} is now: ${text}`)).catch((e) => message.reply(`Discord wouldn't let me (${e?.message ?? e}).`));
  },
};
export default command;
