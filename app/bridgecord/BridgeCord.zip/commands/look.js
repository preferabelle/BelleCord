import { EmbedBuilder as FluxerEmbed } from "@fluxerjs/core";
import { findBot } from "../utils/FindBot.js";
import { botCards } from "./bot.js";

const RED = 0xe0301e;

/** Find any Discord member (people AND bots) by name or ID across the bot's servers. */
async function findAnyone(discordClient, text) {
  const id = text.match(/^<?@?!?(\d{15,21})>?$/)?.[1];
  if (id) return discordClient.users.fetch(id).catch(() => null);
  const want = text.replace(/^@/, "").toLowerCase();
  for (const g of discordClient.guilds.cache.values()) {
    const found = await g.members.search({ query: want, limit: 20 }).catch(() => null);
    const all = [...(found?.values?.() ?? []), ...(g.members.cache?.values?.() ?? [])];
    const hit =
      all.find((m) => [m.user.username, m.user.globalName, m.displayName, m.nickname].some((n) => n?.toLowerCase() === want)) ??
      all.find((m) => [m.user.username, m.user.globalName, m.displayName, m.nickname].some((n) => n?.toLowerCase().includes(want)));
    if (hit) return hit.user;
  }
  return null;
}

/**
 * see how any Discord bot (or person) looks on Discord: picture, banner, name, roles.
 * @type {import('../utils/CommandSchema.d.ts').CommandSchema}
 */
const command = {
  name: "look",
  aliases: ["preview"],
  description: "See how a bot or a Discord member looks",
  params: "[name]",
  access: "admin",
  category: "accounts",
  async run(params, message, discordClient, fluxerClient) {
    if (!discordClient?.isReady?.()) return void (await message.reply("Discord isn't connected, so there's nothing to show you."));
    const named = params.join(" ").trim();
    // The bridge's own bots come first, then Discord members.
    if (named && !/^(me|bridge|discord)$/i.test(named)) {
      const { bot, ambiguous } = findBot(named, fluxerClient, discordClient);
      if (bot?.ready && bot.client) {
        bot.short = named.toLowerCase().split(/\s+/)[0];
        //@ts-expect-error both apps accept embeds
        return void (await message.reply({ embeds: await botCards(bot), allowed_mentions: { parse: [] } }));
      }
      if (ambiguous) return void (await message.reply(`"${named}" could be ${ambiguous.join(" or ")}. Be more specific.`));
    }
    let user = discordClient.user;
    if (named && !/^(me|bridge|discord)$/i.test(named)) {
      user = await findAnyone(discordClient, named);
      if (!user) return void (await message.reply(`I can't find "${named}" anywhere. \`bb!bot\` lists the bots, \`bb!who ${named}\` lists Discord people.`));
    }
    user = await discordClient.users.fetch(user.id, { force: true }).catch(() => user);
    const avatar = user.displayAvatarURL({ size: 512, extension: "png" });
    const banner = user.bannerURL?.({ size: 1024, extension: "png" }) ?? null;

    let where = "Not in any Discord server with me.";
    for (const g of discordClient.guilds.cache.values()) {
      const m = await g.members.fetch(user.id).catch(() => null);
      if (!m) continue;
      const roles = m.roles.cache.filter((r) => r.id !== g.id).map((r) => r.name);
      where = `**In ${g.name}:** ${m.nickname ? `nickname "${m.nickname}" · ` : ""}${roles.length ? "roles: " + roles.join(", ") : "no roles"}`;
      break;
    }

    // Two cards, so both pictures show (one card can only show one big picture).
    const card = new FluxerEmbed()
      .setColor(RED)
      .setTitle(`${user.globalName ?? user.username}${user.bot ? " (bot)" : ""} on Discord`)
      .setDescription(`**Username:** ${user.username}\n${where}\n\n**Profile picture:**`)
      .setImage(avatar);
    const embeds = [card];
    if (banner) embeds.push(new FluxerEmbed().setColor(RED).setTitle("Banner").setImage(banner));
    else card.setFooter({ text: "No banner set." });
    //@ts-expect-error both apps accept these embeds
    await message.reply({ embeds });
  },
};

export default command;
