/**
 * @type {import('../utils/CommandSchema.d.ts').CommandSchema}
 */
const command = {
  name: "restart",
  aliases: ["r"],
  description: "Restart the bot (after editing settings.txt)",
  params: "",
  access: "owner",
  category: "owner",
  async run(params, message, _, _2) {
    await message.reply("Restarting.");

    process.exit(67);
  },
};

export default command;
