import { onMember } from "../utils/MemberCommand.js";
/** @type {import('../utils/CommandSchema.d.ts').CommandSchema} */
const command = {
  name: "ban",
  aliases: [],
  description: "Ban someone from Discord",
  params: "<name> [reason]",
  access: "admin",
  category: "members",
  async run(params, message, discordClient, fluxerClient) {
    const [first, ...rest] = params;
    const reason = rest.join(" ") || "Banned via the bridge bot";
    await onMember(message, first ? [first] : [], discordClient, fluxerClient, async (m) => { await m.ban({ reason }); }, { verb: "banned", failVerb: "ban them" });
  },
};
export default command;
