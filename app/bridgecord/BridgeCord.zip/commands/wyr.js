import { playerOf, triviaChannelFor, triviaRunning } from "../utils/Games.js";
import { startWyr } from "../utils/ChatGames.js";
/** @type {import('../utils/CommandSchema.d.ts').CommandSchema} */
const command = {
  name: "wouldyourather",
  aliases: ["wyr"],
  description: "A would-you-rather question; type A or B to vote",
  params: "",
  access: "everyone",
  category: "games",
  async run(params, message) {
    const ch = await triviaChannelFor(message);
    if (!ch) return void (await message.reply("Play in a bridged channel."));
    if (triviaRunning(ch)) return void (await message.reply("A game's already going here. Pay attention."));
    startWyr(ch, playerOf(message).name);
  },
};
export default command;
