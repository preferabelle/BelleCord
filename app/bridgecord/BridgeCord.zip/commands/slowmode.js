import { ChannelMap } from "../db/index.js";
import { discordChannelFor } from "../utils/DiscordControl.js";
/** @type {import('../utils/CommandSchema.d.ts').CommandSchema} */
const command = {
  name: "slowmode",
  aliases: [],
  description: "Set slowmode on a Discord channel (seconds; 0 turns it off)",
  params: "<seconds> [channel]",
  access: "admin",
  category: "server",
  async run(params, message, discordClient) {
    const [secs, ...rest] = params;
    const n = Math.min(21600, Math.max(0, Number.parseInt(secs ?? "", 10)));
    if (!Number.isFinite(n)) return void (await message.reply("How many seconds? `bb!slowmode 10` (0 turns it off)"));
    const ch = await discordChannelFor(message, discordClient, rest, ChannelMap);
    if (!ch?.setRateLimitPerUser) return void (await message.reply("Which Discord channel? `bb!slowmode 10 general`"));
    await ch.setRateLimitPerUser(n, "Bridge bot").then(() => message.reply(n ? `Slowmode on #${ch.name}: ${n}s between messages.` : `Slowmode off on #${ch.name}.`)).catch((e) => message.reply(`Discord wouldn't let me (${e?.message ?? e}).`));
  },
};
export default command;
