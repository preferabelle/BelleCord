import { ChannelMap } from "../db/index.js";
/** @type {import('../utils/CommandSchema.d.ts').CommandSchema} */
const command = {
  name: "servers",
  aliases: [],
  description: "Which Discord servers the bot is in",
  params: "",
  access: "admin",
  category: "bridge",
  async run(params, message, discordClient) {
    if (!discordClient?.isReady?.()) return void (await message.reply("I'm not connected to Discord right now."));
    const maps = await ChannelMap.findAll({ raw: true });
    const lines = [...discordClient.guilds.cache.values()].map((g) => {
      const n = maps.filter((m) => m.discordGuildId === g.id).length;
      return `• **${g.name}** · ${g.memberCount} members · ${n ? `${n} channel${n === 1 ? "" : "s"} bridged` : "nothing bridged"}`;
    });
    await message.reply(lines.length
      ? `I'm in ${lines.length} Discord server${lines.length === 1 ? "" : "s"}:\n${lines.join("\n")}\n-# Moving? \`bb!unlink all\`, then \`bb!link all <new server>\`, then \`bb!leave-server <old server>\`.`
      : "I'm not in any Discord server yet.");
  },
};
export default command;
