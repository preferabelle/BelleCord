import { EmbedBuilder as FluxerEmbed, Routes as FluxerRoutes } from "@fluxerjs/core";
import { ActivityType, PermissionFlagsBits } from "discord.js";
import { ChannelMap } from "../db/index.js";
import { findBot } from "../utils/FindBot.js";
import { mirrors } from "../utils/Mirrors.js";
import { twins } from "../utils/Twins.js";
import { getImage, setDiscordLook, setFluxerLook } from "./profile.js";

const RED = 0xe0301e;
const CDN = "https://fluxerusercontent.com";
const ACTION = {
  pic: "picture", pfp: "picture", picture: "picture", avatar: "picture", icon: "picture",
  banner: "banner",
  nick: "nick", nickname: "nick",
  name: "name", username: "name", rename: "name",
  status: "status",
  look: "show", show: "show", info: "show", see: "show", check: "show",
};
const STATUS = { online: "online", idle: "idle", away: "idle", dnd: "dnd", busy: "dnd", invisible: "invisible", offline: "invisible" };

/** Everything about one bot, as cards with its picture and banner (so you can check your changes). */
export async function botCards(bot, note = "") {
  const c = bot.client;
  let username = "?", avatar = null, banner = null, nickLine = "";
  if (bot.kind === "discord") {
    const u = await c.users.fetch(c.user.id, { force: true }).catch(() => c.user);
    username = u.username;
    avatar = u.displayAvatarURL?.({ size: 512, extension: "png" }) ?? null;
    banner = u.bannerURL?.({ size: 1024, extension: "png" }) ?? null;
    const nicks = [];
    for (const g of c.guilds?.cache?.values?.() ?? []) {
      const me = g.members?.me ?? (await g.members?.fetchMe?.().catch(() => null));
      if (me?.nickname) nicks.push(`"${me.nickname}" in ${g.name}`);
    }
    nickLine = nicks.length ? nicks.join(", ") : "none";
  } else {
    const u = await c.rest.get(FluxerRoutes.currentUser(), { auth: true }).catch(() => null);
    username = u?.username ?? "?";
    if (u?.avatar) avatar = `${CDN}/avatars/${u.id}/${u.avatar}.png?size=512`;
    if (u?.banner) banner = `${CDN}/banners/${u.id}/${u.banner}.png?size=1024`;
    nickLine = "set per community";
  }
  const short = bot.short;
  const owner = bot.twin ? `<@${bot.twin.fluxerId}>` : bot.mirror ? `Discord person ${bot.mirror.name}` : bot.main ? "the bridge" : "?";
  const lines = [
    note ? `${note}\n` : "",
    `**Lives on:** ${bot.kind === "discord" ? "Discord" : "Fluxer"} · **Username:** ${username}`,
    `**Belongs to:** ${owner} · **Nickname:** ${nickLine}`,
    "",
    "**Change it:**",
    `\`bb!bot ${short} pic\` + attach an image · \`bb!bot ${short} banner\` + image (add \`reset\` to remove)`,
    `\`bb!bot ${short} nick New Nickname\` · \`bb!bot ${short} name newusername\``,
    `\`bb!bot ${short} status dnd playing games\``,
  ].join("\n");
  const card = new FluxerEmbed().setColor(RED).setTitle(bot.label).setDescription(lines);
  if (avatar) card.setImage(avatar);
  const cards = [card];
  if (banner) cards.push(new FluxerEmbed().setColor(RED).setTitle("Banner").setImage(banner));
  else card.setFooter({ text: "No banner yet." });
  return cards;
}

/** In how many bridged Discord channels can this personal bot talk for its person? */
export async function speaksIn(twin) {
  const maps = await ChannelMap.findAll({ raw: true }).catch(() => []);
  let can = 0;
  const total = maps.length;
  for (const m of maps) {
    const ch = await twin.client?.channels?.fetch(m.discordChannelId).catch(() => null);
    const perms = ch?.permissionsFor?.(twin.client.user);
    if (perms?.has?.(PermissionFlagsBits.ViewChannel) && perms.has(PermissionFlagsBits.SendMessages)) can++;
  }
  return { can, total };
}

async function listCard(fluxerClient, discordClient) {
  const row = (name, where, belongs, ok, extra = "") => `**${name}** · ${where} · ${belongs}${ok ? "" : " · *offline*"}${extra}`;
  const twinRows = [];
  for (const t of twins) {
    let extra = "";
    if (t.ready) {
      const { can, total } = await speaksIn(t);
      extra = total ? ` · talks for them in ${can}/${total} channels${can < total ? " ⚠️" : ""}` : "";
    }
    twinRows.push(row(t.name, "Discord", `<@${t.fluxerId}>'s`, t.ready, extra));
  }
  const lines = [
    row("fluxer", "Fluxer", "the bridge", true),
    row("discord", "Discord", "the bridge", !!discordClient?.isReady?.()),
    ...twinRows,
    ...mirrors.map((m) => row(m.name, "Fluxer", `mirror of ${m.name} on Discord`, m.ready)),
  ];
  if (twinRows.some((r) => r.includes("⚠️"))) lines.push("\n⚠️ = that bot can't post in some bridged channels, so those messages go the usual way (name + picture). Give it a role that can post there, or re-invite it with the link from `bb!account list`.");
  return new FluxerEmbed()
    .setColor(RED)
    .setTitle("All the bots")
    .setDescription(
      lines.join("\n") +
        "\n\n**See one:** `bb!bot alex` · **Change one:** `bb!bot alex picture` + attach an image\n-# Names are loose: \"alex\" finds a bot named alex_bot.",
    );
}

/**
 * one place to see and change any of the bridge's bots (admins).
 * @type {import('../utils/CommandSchema.d.ts').CommandSchema}
 */
const command = {
  name: "bot",
  aliases: ["bots"],
  description: "See or change any of the bridge's bots: picture, banner, nickname, name, status",
  params: "[name] [picture | banner | nick | name | status]",
  access: "admin",
  category: "accounts",
  async run(params, message, discordClient, fluxerClient) {
    const words = [...params];
    //@ts-expect-error both apps accept embeds
    if (!words.length || /^list$/i.test(words[0])) return void (await message.reply({ embeds: [await listCard(fluxerClient, discordClient)], allowed_mentions: { parse: [] } }));
    let at = words.findIndex((w) => ACTION[w.toLowerCase()]);
    if (at === 0) return void (await message.reply("Which bot? Put its name first: `bb!bot alex picture`. `bb!bot` lists them."));
    const name = (at < 0 ? words : words.slice(0, at)).join(" ");
    const action = at < 0 ? "show" : ACTION[words[at].toLowerCase()];
    const rest = at < 0 ? [] : words.slice(at + 1);
    const { bot, ambiguous } = findBot(name, fluxerClient, discordClient);
    if (ambiguous) return void (await message.reply(`"${name}" could be ${ambiguous.join(" or ")}. Be more specific.`));
    if (!bot) return void (await message.reply(`No bot called "${name}". \`bb!bot\` shows them all.`));
    if (!bot.ready || !bot.client) return void (await message.reply(`${bot.label} isn't signed in right now. Try again later.`));
    bot.short = name.toLowerCase().split(/\s+/)[0];
    const show = async (note) => {
      //@ts-expect-error both apps accept embeds
      await message.reply({ embeds: await botCards(bot, note), allowed_mentions: { parse: [] } });
    };
    const c = bot.client;
    try {
      if (action === "show") return void (await show());
      if (action === "picture" || action === "banner") {
        const reset = rest.some((w) => /^(reset|remove|clear|none)$/i.test(w));
        let img = null;
        if (!reset) {
          img = await getImage(message, rest);
          if (img.error) return void (await message.reply(`${img.error} Like this: \`bb!bot ${bot.short} ${action === "banner" ? "banner" : "pic"}\` with an image attached.`));
        }
        if (bot.kind === "fluxer") await setFluxerLook(c, action, img);
        else await setDiscordLook(c, action, img);
        return void (await show(`✓ ${action === "banner" ? "Banner" : "Picture"} ${reset ? "removed" : "changed"}. Here's how it looks now:`));
      }
      if (action === "nick") {
        const nick = rest.join(" ").trim();
        if (!nick) return void (await message.reply(`To what? \`bb!bot ${bot.short} nick New Nickname\` (or \`reset\`).`));
        const value = /^(reset|none|clear)$/i.test(nick) ? null : nick.slice(0, 32);
        let done = 0;
        if (bot.kind === "discord") {
          for (const g of c.guilds.cache.values()) {
            const me = g.members.me ?? (await g.members.fetchMe().catch(() => null));
            if (me) await me.setNickname(value, "Bridge admins").then(() => done++).catch(() => {});
          }
        } else {
          for (const g of c.guilds?.values?.() ?? []) await c.rest.patch(`/guilds/${g.id}/members/@me`, { body: { nick: value }, auth: true }).then(() => done++).catch(() => {});
        }
        if (!done) return void (await message.reply("Couldn't change its nickname anywhere. It might not be allowed to."));
        return void (await show(`✓ Nickname ${value ? `set to "${value}"` : "removed"}.`));
      }
      if (action === "name") {
        const newName = rest.join(" ").trim();
        if (!newName) return void (await message.reply(`To what? \`bb!bot ${bot.short} name newusername\``));
        if (bot.kind === "discord") await c.user.setUsername(newName);
        else await c.rest.patch(FluxerRoutes.currentUser(), { body: { username: newName }, auth: true });
        return void (await show(`✓ Username changed to **${newName}**.${bot.kind === "discord" ? " (Discord only allows a couple of these an hour.)" : ""}`));
      }
      if (action === "status") {
        const status = STATUS[(rest[0] ?? "").toLowerCase()];
        if (!status) return void (await message.reply(`Like this: \`bb!bot ${bot.short} status dnd playing games\` (online, idle, dnd, or invisible).`));
        const text = rest.slice(1).join(" ").trim();
        if (bot.kind === "discord") c.user.setPresence({ status, activities: text ? [{ name: text, state: text, type: ActivityType.Custom }] : [] });
        else if (bot.mirror) bot.mirror.setPresence({ status, text: text || null, emoji: null });
        else return void (await message.reply("My own status isn't something you get to pick."));
        return void (await message.reply(`✓ ${bot.label} is ${status === "dnd" ? "on do not disturb" : status}${text ? ` with "${text}"` : ""}.${bot.mirror ? "\n-# Mirrors copy their Discord person's status, so this lasts until theirs changes." : ""}`));
      }
    } catch (e) {
      const why = String(e?.message ?? e);
      return void (await message.reply(`${bot.kind === "discord" ? "Discord" : "Fluxer"} wouldn't let me (${why.slice(0, 140)}).${/rate|429|too (fast|many)/i.test(why) ? " Slow down and try again later." : ""}`));
    }
  },
};

export default command;
