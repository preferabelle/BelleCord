import { playRps, playerOf } from "../utils/Games.js";

/** @type {import('../utils/CommandSchema.d.ts').CommandSchema} */
const command = {
  name: "rps",
  aliases: [],
  description: "Rock, paper, scissors against the bot",
  params: "<rock | paper | scissors>",
  access: "everyone",
  category: "games",
  async run(params, message) {
    const out = playRps(playerOf(message), params[0]);
    await message.reply(out ?? "Rock, paper, or scissors. Like `bb!rps rock`.");
  },
};
export default command;
