import { ChannelType } from "discord.js";
import { ChannelMap } from "../db/index.js";
import Config from "../utils/ConfigHandler.js";

/**
 * list Discord channels by name, so you never need Discord to find IDs.
 * @type {import('../utils/CommandSchema.d.ts').CommandSchema}
 */
const command = {
  name: "channels",
  aliases: [],
  description: "List the Discord channels you can link to",
  params: "",
  access: "admin",
  category: "bridge",
  async run(params, message, discordClient) {
    if (Config.PracticeMode || !discordClient?.isReady?.()) {
      await message.reply("I'm not connected to Discord yet. Put the Discord token in settings.txt and restart me.");
      return;
    }
    const bridged = new Set((await ChannelMap.findAll({ raw: true })).map((m) => m.discordChannelId));
    const blocks = [];
    for (const guild of discordClient.guilds.cache.values()) {
      const me = guild.members.me;
      const visible = [...guild.channels.cache.values()]
        .filter((c) => !me || c.permissionsFor(me)?.has("ViewChannel"))
        .sort((a, b) => a.rawPosition - b.rawPosition);
      const text = visible
        .filter((c) => c.type === ChannelType.GuildText || c.type === ChannelType.GuildAnnouncement)
        .map((c) => `#${c.name}${bridged.has(c.id) ? "  (bridged)" : ""}`);
      const voice = visible
        .filter((c) => c.type === ChannelType.GuildVoice || c.type === ChannelType.GuildStageVoice)
        .map((c) => `🔊 ${c.name}`);
      blocks.push(
        `${guild.name}\nText:\n${text.join("\n") || "(none the bot can see)"}` +
          `\n\nVoice:\n${voice.join("\n") || "(none the bot can see)"}`,
      );
    }
    const text = blocks.join("\n\n") || "The bot isn't in any Discord servers yet.";
    await message.reply(
      "```\n" + text.slice(0, 1800) + "\n```\n" +
        `Link one to this channel with \`${Config.BotPrefix}link <name>\`, for example \`${Config.BotPrefix}link general\`.`,
    );
  },
};

export default command;
