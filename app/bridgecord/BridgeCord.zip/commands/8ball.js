import { randomInt } from "node:crypto";

const ANSWERS = [
  "It is certain.", "Without a doubt.", "Yes, definitely.", "You may rely on it.", "Most likely.",
  "Outlook good.", "Signs point to yes.", "Reply hazy, try again.", "Ask again later.",
  "Cannot predict now.", "Don't count on it.", "My reply is no.", "Outlook not so good.", "Very doubtful.",
];

/** @type {import('../utils/CommandSchema.d.ts').CommandSchema} */
const command = {
  name: "8ball",
  aliases: ["ask"],
  description: "Ask the magic 8-ball a question",
  params: "<question>",
  access: "everyone",
  category: "games",
  async run(params, message) {
    if (!params.length) return void (await message.reply("Ask a question, like `bb!8ball will it rain tomorrow?`"));
    await message.reply(`🎱 ${ANSWERS[randomInt(ANSWERS.length)]}`);
  },
};
export default command;
