import { EmbedBuilder } from "@fluxerjs/core";
import Config from "../utils/ConfigHandler.js";
import { getDuration } from "../utils/GetDuration.js";
import { botStartingTime } from "../index.js";

/** @type {import('../utils/CommandSchema.d.ts').CommandSchema} */
const command = {
  name: "about",
  aliases: ["info"],
  description: "About this bot",
  params: "",
  access: "everyone",
  category: "info",
  async run(params, message) {
    const embed = new EmbedBuilder()
      .setColor(0x5865f2)
      .setTitle(Config.BotName)
      .setDescription(
        [
          "Connects this Fluxer community with Discord: messages, replies, edits, reactions, pictures, DMs, and voice.",
          "",
          `**Uptime:** ${getDuration(botStartingTime, new Date())}`,
          `**Commands:** \`${Config.BotPrefix}help\``,
          "",
          "-# Built on Fluxcord by Jb Carreon (MIT License).",
        ].join("\n"),
      );
    //@ts-expect-error both apps accept this embed
    await message.reply({ embeds: [embed] });
  },
};

export default command;
