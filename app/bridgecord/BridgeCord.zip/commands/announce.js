import { findDiscordChannel } from "../utils/DiscordControl.js";
/** @type {import('../utils/CommandSchema.d.ts').CommandSchema} */
const command = {
  name: "announce",
  aliases: [],
  description: "Post an @everyone announcement in a Discord channel",
  params: "<channel> <message>",
  access: "admin",
  category: "server",
  async run(params, message, discordClient) {
    const [where, ...rest] = params;
    const text = rest.join(" ").trim();
    const ch = where ? findDiscordChannel(discordClient, where) : null;
    if (!ch || !text) return void (await message.reply("Like this: `bb!announce general game night at 8!`"));
    await ch.send({ content: `@everyone ${text}`, allowedMentions: { parse: ["everyone"] } }).then(() => message.reply(`Announced in #${ch.name}.`)).catch((e) => message.reply(`Discord wouldn't let me (${e?.message ?? e}).`));
  },
};
export default command;
