import { resolvePerson } from "../utils/WhoIs.js";
/** @type {import('../utils/CommandSchema.d.ts').CommandSchema} */
const command = {
  name: "dm",
  aliases: [],
  description: "Send someone a DM on Discord from the bot",
  params: "<name> <message>",
  access: "admin",
  category: "members",
  async run(params, message, discordClient, fluxerClient) {
    if (!discordClient?.isReady?.()) return void (await message.reply("I'm not connected to Discord right now."));
    const replying = !!(message.messageReference?.messageId ?? message.referencedMessage);
    const [first, ...rest] = params;
    const who = await resolvePerson(message, replying ? [] : first ? [first] : [], discordClient, fluxerClient);
    const text = (replying ? params : rest).join(" ").trim();
    if (!who || who.side !== "discord") return void (await message.reply("Who on Discord? `bb!dm alex hey`"));
    if (!text) return void (await message.reply("Say what, exactly? `bb!dm alex hey`"));
    const user = await discordClient.users.fetch(who.id).catch(() => null);
    await user?.send({ content: text }).then(() => message.reply(`Sent to ${who.name}.`)).catch((e) => message.reply(`Couldn't DM them (${e?.message ?? e}). They probably have DMs turned off.`));
  },
};
export default command;
