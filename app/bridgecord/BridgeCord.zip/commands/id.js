import { Message as FluxerMessage } from "@fluxerjs/core";

/**
 * shows the numbers you need for settings.txt.
 * @type {import('../utils/CommandSchema.d.ts').CommandSchema}
 */
const command = {
  name: "id",
  aliases: ["ids"],
  description: "Show the IDs of this server, channel, and you",
  params: "",
  access: "admin",
  category: "bridge",
  async run(params, message) {
    const where = message instanceof FluxerMessage ? "community" : "server";
    await message.reply(
      "fine. Copy what you need into settings.txt yourself, I'm not your secretary.\n" +
        "```\n" +
        `This ${where}: ${message.guildId}\n` +
        `This channel: ${message.channelId}\n` +
        `You:          ${message.author.id}\n` +
        "```",
    );
  },
};

export default command;
