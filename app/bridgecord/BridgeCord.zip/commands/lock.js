import { ChannelMap } from "../db/index.js";
import { discordChannelFor } from "../utils/DiscordControl.js";
/** @type {import('../utils/CommandSchema.d.ts').CommandSchema} */
const command = {
  name: "lock",
  aliases: [],
  description: "Stop regular members from talking in a Discord channel",
  params: "[channel]",
  access: "admin",
  category: "server",
  async run(params, message, discordClient) {
    const ch = await discordChannelFor(message, discordClient, params, ChannelMap);
    if (!ch?.permissionOverwrites) return void (await message.reply("Which Discord channel? Use it in a bridged channel or name one: `bb!lock general`"));
    await ch.permissionOverwrites.edit(ch.guild.roles.everyone, { SendMessages: false }, { reason: "Locked via the bridge bot" })
      .then(() => message.reply(`Locked #${ch.name} on Discord.`)).catch((e) => message.reply(`Discord wouldn't let me (${e?.message ?? e}).`));
  },
};
export default command;
