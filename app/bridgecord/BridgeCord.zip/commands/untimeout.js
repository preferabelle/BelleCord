import { onMember } from "../utils/MemberCommand.js";
/** @type {import('../utils/CommandSchema.d.ts').CommandSchema} */
const command = {
  name: "untimeout",
  aliases: [],
  description: "End someone's Discord timeout",
  params: "<name>",
  access: "admin",
  category: "members",
  async run(params, message, discordClient, fluxerClient) {
    await onMember(message, params, discordClient, fluxerClient, async (m) => { await m.timeout(null, "Timeout ended via the bridge bot"); }, { verb: "freed", failVerb: "end their timeout" });
  },
};
export default command;
