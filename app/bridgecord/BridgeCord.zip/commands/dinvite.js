import { ChannelMap } from "../db/index.js";
import { discordChannelFor } from "../utils/DiscordControl.js";
/** @type {import('../utils/CommandSchema.d.ts').CommandSchema} */
const command = {
  name: "discord-invite",
  aliases: ["dinvite"],
  description: "Create an invite link to the Discord server",
  params: "[Discord channel]",
  access: "admin",
  category: "bridge",
  async run(params, message, discordClient) {
    const ch = await discordChannelFor(message, discordClient, params, ChannelMap) ?? discordClient?.guilds?.cache?.first?.()?.systemChannel;
    if (!ch?.createInvite) return void (await message.reply("Which Discord channel? `bb!discord-invite general`"));
    await ch.createInvite({ maxAge: 86400, unique: true, reason: "Bridge bot" }).then((inv) => message.reply(`Here, take it: ${inv.url}\n-# Works for a day.`)).catch((e) => message.reply(`Discord wouldn't let me (${e?.message ?? e}).`));
  },
};
export default command;
