import { Message as FluxerMessage } from "@fluxerjs/core";
import Config from "../utils/ConfigHandler.js";
import { getMirrorByName, mirrors } from "../utils/Mirrors.js";

const STATUSES = { online: "online", idle: "idle", dnd: "dnd", offline: "invisible", invisible: "invisible" };

/**
 * try mirrors without anyone on Discord.
 * @type {import('../utils/CommandSchema.d.ts').CommandSchema}
 */
const command = {
  name: "practice",
  aliases: ["test"],
  description: "Test mode without Discord",
  params: "[on | off]",
  access: "admin",
  category: "bridge",
  async run(params, message) {
    const p = Config.BotPrefix;
    if (!(message instanceof FluxerMessage)) {
      await message.reply("Practice happens on Fluxer.");
      return;
    }
    const names = mirrors.map((m) => m.name).join(", ") || "none yet";
    const usage =
      `Wrong. Like this: \`${p}practice Max hello\` or \`${p}practice status Max dnd drawing\`.\n` +
      `-# Mirrors in settings.txt: ${names}`;

    if (params[0]?.toLowerCase() === "status") {
      const mirror = getMirrorByName(params[1]);
      const status = STATUSES[params[2]?.toLowerCase() ?? ""];
      if (!mirror || !status) {
        await message.reply(usage);
        return;
      }
      const text = params.slice(3).join(" ").trim() || null;
      mirror.setPresence({ status: /** @type {any} */ (status), text, emoji: null });
      await message.reply(
        `${mirror.name} will show as **${params[2].toLowerCase()}**${text ? ` with "${text}"` : ""} in a few seconds. Go look at the member list if you don't believe me.`,
      );
      return;
    }

    const mirror = getMirrorByName(params[0]);
    const text = params.slice(1).join(" ").trim();
    if (!mirror || !text) {
      await message.reply(usage);
      return;
    }
    if (!mirror.ready) {
      await message.reply(`${mirror.name} isn't even signed in. Check \`${p}mirrors\`.`);
      return;
    }
    try {
      await mirror.send(message.channelId, {
        content: `${text}\n-# practice message`,
        allowed_mentions: { parse: [] },
      });
    } catch (e) {
      await message.reply(
        `${mirror.name} couldn't post here (${e?.code ?? e?.status ?? ""} ${e?.message ?? e}). ` +
          `Make sure it's in this community and can see and send messages in this channel.`,
      );
    }
  },
};

export default command;
