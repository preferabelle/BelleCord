import { Message as FluxerMessage } from "@fluxerjs/core";
import Config from "../utils/ConfigHandler.js";
import { dropFriendKey, friendLink, newFriendKey, streamsOn } from "../utils/StreamServer.js";

/**
 * streams with BelleCord, for people in the bridged call on Discord.
 *   b!stream        DMs you your BelleCord link (click it in BelleCord once)
 *   b!stream new    a new link (the old one stops working)
 *   b!stream off    your link stops working
 * @type {import('../utils/CommandSchema.d.ts').CommandSchema}
 */
const command = {
  name: "stream",
  aliases: ["streams"],
  description: "Get your BelleCord link for streams in the bridged call (Discord)",
  params: "[new | off]",
  access: "everyone",
  category: "info",
  async run(params, message) {
    const p = Config.BotPrefix;
    if (!streamsOn()) return void (await message.reply("Streams with BelleCord are switched off on this bridge (`streams: no` in settings.txt)."));
    if (message instanceof FluxerMessage) {
      return void (await message.reply("Type it on Discord. It's for people in the bridged call on Discord who use BelleCord: Fluxer already shows their streams once they're shared."));
    }
    const word = String(params[0] ?? "").toLowerCase();
    if (word === "off" || word === "stop") {
      const had = dropFriendKey(message.author.id);
      return void (await message.reply(had ? "Done. Your link doesn't work any more." : "You didn't have a link."));
    }
    if (!Config.StreamAddress) {
      return void (await message.reply(
        "This bridge only does streams for BelleCord on the computer it runs on (that one finds it by itself). " +
        "For people on other computers, whoever runs it needs to give it a `stream address` in settings.txt (HOW TO USE.txt, Streams).",
      ));
    }
    const link = friendLink(newFriendKey(message.author.id));
    const text = [
      `Your BelleCord link for streams in ${Config.BotName}'s bridged call:`,
      link,
      "",
      "Click it in Discord inside BelleCord and it's added by itself. Then, in the bridged call, going live on Discord can show on Fluxer too, and Fluxer streams get a Watch button.",
      `Keep it to yourself: it works for your Discord account. \`${p}stream new\` makes a new one, \`${p}stream off\` stops it.`,
    ].join("\n");
    const sent = await message.author.send({ content: text }).then(() => true).catch(() => false);
    if (!sent) {
      dropFriendKey(message.author.id);
      return void (await message.reply("I couldn't DM you. Let DMs from server members through (Privacy Settings for this server) and try again."));
    }
    if (word === "new") await message.reply("Sent you a new link. The old one doesn't work any more.");
    else await message.reply("Sent you a DM with your link.");
  },
};

export default command;
