import { EmbedBuilder } from "@fluxerjs/core";
import { ChannelType } from "discord.js";
const RED = 0xe0301e;
/** @type {import('../utils/CommandSchema.d.ts').CommandSchema} */
const command = {
  name: "server-info",
  aliases: ["serverinfo"],
  description: "Details about the Discord server",
  params: "",
  access: "admin",
  category: "server",
  async run(params, message, discordClient) {
    const g = discordClient?.guilds?.cache?.first?.();
    if (!g) return void (await message.reply("I'm not even in a Discord server yet. Somebody invite me."));
    const owner = await g.fetchOwner().catch(() => null);
    const text = g.channels.cache.filter((c) => c.type === ChannelType.GuildText).size;
    const voice = g.channels.cache.filter((c) => c.type === ChannelType.GuildVoice).size;
    const lines = [
      `**Owner:** ${owner?.user?.username ?? "unknown"}`,
      `**Members:** ${g.memberCount}`,
      `**Channels:** ${text} text, ${voice} voice`,
      `**Roles:** ${g.roles.cache.size - 1}`,
      `**Boosts:** ${g.premiumSubscriptionCount ?? 0} (level ${g.premiumTier ?? 0})`,
      `**Made:** <t:${Math.floor(g.createdAt.getTime() / 1000)}:D>`,
      `**My highest role:** ${g.members.me?.roles?.highest?.name ?? "?"} (I can only manage people below it)`,
    ];
    //@ts-expect-error both apps accept this embed
    await message.reply({ embeds: [new EmbedBuilder().setColor(RED).setTitle(g.name).setDescription(lines.join("\n")).setImage(g.iconURL?.({ size: 256, extension: "png" }) ?? null)] });
  },
};
export default command;
