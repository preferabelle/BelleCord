import { Message as FluxerMessage } from "@fluxerjs/core";
import Config from "../utils/ConfigHandler.js";
import { mirrors } from "../utils/Mirrors.js";

const STATUS_WORDS = {
  online: "online",
  idle: "idle",
  dnd: "do not disturb",
  invisible: "offline",
};

/**
 * a health check for every mirror bot.
 * @type {import('../utils/CommandSchema.d.ts').CommandSchema}
 */
const command = {
  name: "mirrors",
  aliases: ["mirror"],
  description: "Status of every mirror bot",
  params: "",
  access: "admin",
  category: "accounts",
  async run(params, message) {
    if (mirrors.length === 0) {
      await message.reply(
        "There are no mirrors. Add a `mirror:` line to settings.txt and restart me.",
      );
      return;
    }
    const isFluxer = message instanceof FluxerMessage;
    const lines = mirrors.map((m) => {
      const parts = [];
      parts.push(m.ready ? `signed in as ${m.tag}` : m.signInError ? "can't sign in (check its token)" : "signing in…");
      if (isFluxer && m.ready) {
        const here = m.inCommunity(message.guildId);
        if (here === false) parts.push(`not in this community yet, invite it: ${m.inviteLink()}`);
        else if (here === true) parts.push("in this community");
      }
      parts.push(
        m.discordId
          ? `linked to Discord ID ${m.discordId}`
          : m.discordRef
            ? `looking for Discord user "${m.discordRef}"`
            : "not linked to anyone on Discord yet",
      );
      if (m.presence) {
        const st = STATUS_WORDS[m.presence.status] ?? m.presence.status;
        parts.push(`showing ${st}${m.presence.text ? ` · "${m.presence.text}"` : ""}`);
      }
      return `**${m.name}**: ${parts.join(" · ")}`;
    });
    const mode = Config.PracticeMode
      ? "\n-# Practice mode. Discord isn't connected yet, so I'm not bridging anything. Yet."
      : "";
    await message.reply("Mirror status:\n" + lines.join("\n") + mode);
  },
};

export default command;
