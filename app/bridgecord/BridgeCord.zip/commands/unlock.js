import { ChannelMap } from "../db/index.js";
import { discordChannelFor } from "../utils/DiscordControl.js";
/** @type {import('../utils/CommandSchema.d.ts').CommandSchema} */
const command = {
  name: "unlock",
  aliases: [],
  description: "Undo a lock",
  params: "[channel]",
  access: "admin",
  category: "server",
  async run(params, message, discordClient) {
    const ch = await discordChannelFor(message, discordClient, params, ChannelMap);
    if (!ch?.permissionOverwrites) return void (await message.reply("Which Discord channel? `bb!unlock general`"));
    await ch.permissionOverwrites.edit(ch.guild.roles.everyone, { SendMessages: null }, { reason: "Unlocked via the bridge bot" })
      .then(() => message.reply(`Unlocked #${ch.name}.`)).catch((e) => message.reply(`Discord wouldn't let me (${e?.message ?? e}).`));
  },
};
export default command;
