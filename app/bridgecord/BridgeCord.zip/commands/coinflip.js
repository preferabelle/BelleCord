import { playerOf } from "../utils/Games.js";
import { reaction } from "../utils/Output.js";
import { randomInt } from "node:crypto";
/** @type {import('../utils/CommandSchema.d.ts').CommandSchema} */
const command = {
  name: "flip",
  aliases: ["coinflip", "coin"],
  description: "Flip a coin",
  params: "[heads | tails]",
  access: "everyone",
  category: "games",
  async run(params, message) {
    const side = randomInt(2) ? "heads" : "tails";
    const call = (params[0] ?? "").toLowerCase().replace(/^h.*/, "heads").replace(/^t.*/, "tails");
    if (call !== "heads" && call !== "tails") return void (await message.reply(`🪙 **${side.toUpperCase()}.** There. Happy?`));
    await message.reply(`🪙 **${side.toUpperCase()}.** ${call === side ? reaction("win", playerOf(message).name) ?? "You called it. Lucky guess." : reaction("fail") ?? "Wrong. "}`);
  },
};
export default command;
