import fs from "node:fs";
import path from "node:path";
import { randomInt } from "node:crypto";
import Config from "../utils/ConfigHandler.js";
import { playerOf } from "../utils/Games.js";

const FILE = path.join(Config.DataFolderPath, "blackjack.json");
let records = {};
try { records = JSON.parse(fs.readFileSync(FILE, "utf-8")); } catch {}
const saveRecords = () => { try { fs.writeFileSync(FILE, JSON.stringify(records)); } catch {} };
/** @type {Map<string, {deck: string[], you: string[], me: string[]}>} */
const tables = new Map();
/** Swappable for tests. */
export const deckMaker = { make: null };

const RANKS = ["A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"];
const SUITS = ["♠", "♥", "♦", "♣"];
function newDeck() {
  if (deckMaker.make) return deckMaker.make();
  const d = SUITS.flatMap((s) => RANKS.map((r) => r + s));
  for (let i = d.length - 1; i > 0; i--) { const j = randomInt(i + 1); [d[i], d[j]] = [d[j], d[i]]; }
  return d;
}
export function total(hand) {
  let sum = 0, aces = 0;
  for (const c of hand) {
    const r = c.slice(0, -1);
    if (r === "A") { aces++; sum += 11; } else sum += ["J", "Q", "K"].includes(r) ? 10 : Number(r);
  }
  while (sum > 21 && aces--) sum -= 10;
  return sum;
}
const show = (hand) => `${hand.join(" ")} (${total(hand)})`;

function finish(key, name, t, result) {
  tables.delete(key);
  const rec = (records[key] ??= { name, w: 0, l: 0, t: 0 });
  rec.name = name;
  rec[result]++;
  saveRecords();
  const line = { w: pickLine(["Fine. You win. Don't get used to it.", "Tch. Lucky.", "...I let you win. Obviously."]), l: pickLine(["I win. As expected.", "Too bad. I'm just better.", "Hmph. Easy."]), t: "A tie. Boring." }[result];
  return `**You:** ${show(t.you)}\n**Me:** ${show(t.me)}\n${line}\n-# Your record: ${rec.w}W ${rec.l}L ${rec.t}T`;
}
const pickLine = (a) => a[randomInt(a.length)];

/** @type {import('../utils/CommandSchema.d.ts').CommandSchema} */
const command = {
  name: "blackjack", aliases: ["bj", "21"], description: "Blackjack against me. Then `bb!bj hit` or `bb!bj stand`", requireElevated: false, access: "everyone", category: "games", params: "[hit | stand | record]",
  async run(params, message) {
    const me = playerOf(message);
    const move = (params[0] ?? "").toLowerCase();
    if (move === "record") {
      const r = records[me.key];
      const n = (x, one, many) => `${x} ${x === 1 ? one : many}`;
      return void (await message.reply(r ? `Your blackjack record: ${n(r.w, "win", "wins")}, ${n(r.l, "loss", "losses")}, ${n(r.t, "tie", "ties")}.` : "You've never played me. Scared?"));
    }
    let t = tables.get(me.key);
    if (!t) {
      if (move === "hit" || move === "stand") return void (await message.reply("You're not even playing, baka. `bb!bj` to start."));
      const deck = newDeck();
      t = { deck, you: [deck.pop(), deck.pop()], me: [deck.pop(), deck.pop()] };
      tables.set(me.key, t);
      if (total(t.you) === 21) return void (await message.reply(`Blackjack!\n${finish(me.key, me.name, t, total(t.me) === 21 ? "t" : "w")}`));
      return void (await message.reply(`**You:** ${show(t.you)}\n**Me:** ${t.me[0]} ??\n\`bb!bj hit\` or \`bb!bj stand\`. Choose wisely. You won't.`));
    }
    if (move === "hit") {
      t.you.push(t.deck.pop());
      const y = total(t.you);
      if (y > 21) return void (await message.reply(`Bust! ${finish(me.key, me.name, t, "l")}`));
      if (y < 21) return void (await message.reply(`**You:** ${show(t.you)}\n**Me:** ${t.me[0]} ??\nAgain? \`bb!bj hit\` or \`bb!bj stand\`.`));
    } else if (move !== "stand") {
      return void (await message.reply(`**You:** ${show(t.you)}\n**Me:** ${t.me[0]} ??\nWell? \`bb!bj hit\` or \`bb!bj stand\`.`));
    }
    // Stand (or 21): I draw to 17.
    while (total(t.me) < 17) t.me.push(t.deck.pop());
    const y = total(t.you), m = total(t.me);
    await message.reply(finish(me.key, me.name, t, m > 21 || y > m ? "w" : y < m ? "l" : "t"));
  },
};
export default command;
