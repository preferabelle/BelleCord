import { resolvePerson, discordMembers } from "../utils/WhoIs.js";
import { hierarchyProblem } from "../utils/DiscordControl.js";

/** @type {import('../utils/CommandSchema.d.ts').CommandSchema} */
const command = {
  name: "kick",
  aliases: [],
  description: "Kick someone from Discord",
  params: "<name> [reason]",
  access: "admin",
  category: "members",
  async run(params, message, discordClient, fluxerClient) {
    if (!discordClient?.isReady?.()) return void (await message.reply("I'm not connected to Discord right now."));
    const [first, ...reasonWords] = params;
    const who = await resolvePerson(message, first ? [first] : [], discordClient, fluxerClient);
    if (!who || who.side !== "discord") return void (await message.reply("Who on Discord? `bb!kick <their Discord name>`, a mirror's name, or reply to their message."));
    if (who.id === discordClient.user.id) return void (await message.reply("Kick myself? Absolutely not."));
    const reason = reasonWords.join(" ") || "Kicked via the bridge bot";
    const members = await discordMembers(discordClient, who.id);
    if (!members.length) return void (await message.reply(`${who.name} isn't in any Discord server with me. `));
    const done = [], failed = [];
    for (const m of members) {
      if (!m.kickable) { failed.push(`${m.guild.name}: ${hierarchyProblem(m) ?? "Discord says I'm not allowed (I need Kick Members)."}`); continue; }
      try { await m.kick(reason); done.push(m.guild.name); } catch (e) { failed.push(`${m.guild.name} (${e?.message ?? e})`); }
    }
    const lines = [];
    if (done.length) lines.push(`Kicked **${who.name}** from ${done.join(", ")}.`);
    if (failed.length) lines.push(`Couldn't kick them. ${failed.join("\n")}`);
    await message.reply(lines.join("\n"));
  },
};
export default command;
