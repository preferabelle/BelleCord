import fs from "node:fs";
import { REMEMBER } from "./unbridge.js";
import { Routes as FluxerRoutes } from "@fluxerjs/core";
import { botSend } from "../utils/BotOnDiscord.js";
import { ChannelType } from "discord.js";
import { Message as FluxerMessage } from "@fluxerjs/core";
import { Op } from "sequelize";
import { ChannelMap, GuildMap } from "../db/index.js";
import Config from "../utils/ConfigHandler.js";
import { checkBotPermissions } from "../utils/CheckBotPerms.js";
import { resolveDiscordParentChannel } from "../utils/DiscordThreadResolver.js";
import changeBotBio from "../utils/ChangeBotBio.js";

const TYPES = {
  both: "both",
  discord2fluxer: "discord2fluxer",
  fluxer2discord: "fluxer2discord",
};

/**
 * link a Discord channel to this Fluxer channel in one step.
 * Upstream Fluxcord needs someone to type a confirm command on Discord too;
 * here the Discord side agreed when its admin invited the bot.
 * @type {import('../utils/CommandSchema.d.ts').CommandSchema}
 */
const command = {
  name: "link",
  aliases: [],
  description: "Bridge this Fluxer channel with a Discord channel, or link every channel at once",
  params: "<Discord channel> | all <Discord server>",
  access: "admin",
  category: "bridge",
  additionalInfo: "Run it in the Fluxer channel you want to bridge. Use bb!channels to see Discord channel names.",
  async run(params, message, discordClient, fluxerClient) {
    const p = Config.BotPrefix;
    if (!params.length || /^(help|\?)$/i.test(params[0] ?? "")) {
      await message.reply("Go to the Fluxer channel you want bridged and type `bb!link <Discord channel name>`, like `bb!link general`. `bb!channels` lists the Discord ones.");
      return;
    }
    if (!(message instanceof FluxerMessage) || !message.guildId) {
      await message.reply(/^all$/i.test(params[0] ?? "")
        ? "Type `bb!link all` in any channel of your Fluxer community."
        : "Not here. Type it *inside* the Fluxer channel you want bridged.");
      return;
    }
    if (/^all$/i.test(params[0])) return void (await linkAll(params.slice(1), message, discordClient, fluxerClient, command));
    if (Config.PracticeMode || !discordClient?.isReady?.()) {
      await message.reply("I'm not connected to Discord yet. Put the Discord token in settings.txt and restart me.");
      return;
    }

    const [target, typeWord] = params;
    const type = TYPES[(typeWord ?? "both").toLowerCase()];
    if (!target || !type) {
      await message.reply(`Usage: \`${p}link general\` (or a Discord channel ID). \`${p}channels\` lists the names.`);
      return;
    }

    // Find the Discord channel by ID or by name.
    let dChannel = null;
    if (/^\d{15,21}$/.test(target)) {
      dChannel = await discordClient.channels.fetch(target).catch(() => null);
    } else {
      const name = target.replace(/^#/, "").toLowerCase();
      const hits = [];
      for (const guild of discordClient.guilds.cache.values()) {
        for (const c of guild.channels.cache.values()) {
          if (
            (c.type === ChannelType.GuildText || c.type === ChannelType.GuildAnnouncement) &&
            c.name.toLowerCase() === name
          ) {
            hits.push(c);
          }
        }
      }
      if (hits.length > 1) {
        await message.reply(
          "More than one Discord channel has that name. Use the ID instead:\n```\n" +
            hits.map((c) => `${c.guild.name}  #${c.name}  ${c.id}`).join("\n") +
            "\n```",
        );
        return;
      }
      dChannel = hits[0] ?? null;
    }
    if (!dChannel || !dChannel.isTextBased?.() || dChannel.isDMBased?.()) {
      await message.reply(`That channel doesn't exist. \`${p}channels\` lists the real ones.`);
      return;
    }

    const existing = await ChannelMap.findOne({
      where: {
        [Op.or]: [{ fluxerChannelId: message.channelId }, { discordChannelId: dChannel.id }],
      },
    });
    if (existing) {
      await message.reply(
        `One of these channels is already bridged. Run \`${p}unbridge\` in it first, then link again.`,
      );
      return;
    }

    const fChannel = await fluxerClient.channels.fetch(message.channelId).catch(() => null);
    const dParent = await resolveDiscordParentChannel(discordClient, dChannel);
    if (!fChannel || !dParent) {
      await message.reply("I couldn't open one of those channels. Make sure I can see both.");
      return;
    }
    if (Boolean(fChannel.nsfw) !== Boolean(dParent.nsfw)) {
      await message.reply("Both channels need the same age-restricted (NSFW) setting. Fix that first.");
      return;
    }

    const fPerms = checkBotPermissions(message.guild.members.me, fChannel);
    if (!fPerms.hasAllCritical) {
      await message.reply(
        `On Fluxer, the bridge bot is missing: ${[...fPerms.missingCritical, ...fPerms.missingGuildCritical].join(", ")}. Give its role those, then try again.`,
      );
      return;
    }
    const dMe = dParent.guild.members.me ?? (await dParent.guild.members.fetchMe().catch(() => null));
    const dPerms = dMe ? checkBotPermissions(dMe, dParent) : null;
    if (!dPerms?.hasAllCritical) {
      await message.reply(
        `On Discord, the bridge bot is missing: ${dPerms ? [...dPerms.missingCritical, ...dPerms.missingGuildCritical].join(", ") : "access to that channel"}. ` +
          `Give the bot's role those permissions in #${dParent.name} (Discord: Edit Channel > Permissions).`,
      );
      return;
    }

    let fluxerWebhookId = "";
    let fluxerWebhookToken = "";
    let discordWebhookId = "";
    let discordWebhookToken = "";
    if (type !== "fluxer2discord") {
      const wh = await fChannel.createWebhook({ name: `Bridge (#${dParent.name})` });
      fluxerWebhookId = wh.id;
      fluxerWebhookToken = wh.token ?? "";
    }
    if (type !== "discord2fluxer") {
      const wh = await dParent.createWebhook({ name: "Bridge" });
      discordWebhookId = wh.id;
      discordWebhookToken = wh.token ?? "";
    }

    const [fluxerGuildMap] = await GuildMap.findOrCreate({
      where: { guildId: message.guildId, guildType: "fluxer" },
    });
    const [discordGuildMap] = await GuildMap.findOrCreate({
      where: { guildId: dChannel.guildId, guildType: "discord" },
    });

    await ChannelMap.create({
      fluxerChannelId: message.channelId,
      discordChannelId: dChannel.id,
      fluxerGuildId: message.guildId,
      discordGuildId: dChannel.guildId,
      fluxerWebhookId,
      discordWebhookId,
      fluxerWebhookToken,
      discordWebhookToken,
      fluxerGuildMapId: fluxerGuildMap.id,
      discordGuildMapId: discordGuildMap.id,
      bridgeType: type,
    });

    await botSend(dChannel, "This channel is now bridged to Fluxer.").catch(() => {});
    await message.reply(
      `Linked with #${dChannel.name} on ${dChannel.guild.name}. Say something on either side and watch me work.`,
    );

    try {
      await changeBotBio(message.guild);
      await changeBotBio(dChannel.guild);
    } catch {}
  },
};

/**
 * bb!link all [Discord server]: link every Fluxer channel to its Discord partner in one go.
 * Partners come from what bb!unbridge all remembered (same Discord channel name as before),
 * otherwise a Discord channel with the same name as the Fluxer one. Uses bb!link itself for
 * each pair, so every check it does still happens.
 */
async function linkAll(words, message, discordClient, fluxerClient, self) {
  const squash = (x) => String(x ?? "").toLowerCase().replace(/[^a-z0-9]/g, "");
  if (!discordClient?.isReady?.()) return void (await message.reply("I'm not connected to Discord yet."));
  const servers = [...discordClient.guilds.cache.values()];
  const wanted = words.join(" ").trim();
  let server = wanted ? servers.find((g) => squash(g.name) === squash(wanted) || g.id === wanted) ?? servers.find((g) => squash(g.name).includes(squash(wanted))) : null;
  if (!server && !wanted && servers.length === 1) server = servers[0];
  if (!server) {
    const list = servers.map((g) => `• ${g.name}`).join("\n");
    return void (await message.reply(servers.length
      ? `${wanted ? `I'm not in a server called "${wanted}". ` : `I'm in ${servers.length} Discord servers. `}Which one? \`bb!link all <server name>\`\n${list}`
      : "The bot isn't in any Discord server yet. Invite it first (`bb!invite`)."));
  }

  let remembered = [];
  try { remembered = JSON.parse(fs.readFileSync(REMEMBER, "utf-8")).pairs ?? []; } catch {}
  const rememberedFor = new Map(remembered.map((r) => [r.fluxerChannelId, r]));

  const fChannels = (await fluxerClient.rest.get(FluxerRoutes.guildChannels(message.guildId)).catch(() => [])) ?? [];
  const textish = (c) => c.type === ChannelType.GuildText || c.type === ChannelType.GuildAnnouncement;
  const dChannels = [...server.channels.cache.values()].filter(textish);
  const findD = (name) => dChannels.find((c) => c.name.toLowerCase() === String(name).toLowerCase()) ?? dChannels.find((c) => squash(c.name) === squash(name));

  const linked = [], failed = [], noMatch = [];
  for (const f of fChannels.filter((c) => c.type === 0 || c.type === 5)) {
    if (await ChannelMap.findOne({ where: { fluxerChannelId: f.id }, raw: true })) continue; // already linked
    const before = rememberedFor.get(f.id);
    const d = findD(before?.discordName ?? f.name);
    if (!d) { if (before) noMatch.push(`#${f.name} (was #${before.discordName})`); continue; }
    if (await ChannelMap.findOne({ where: { discordChannelId: d.id }, raw: true })) continue;
    // Run the normal bb!link for this pair, as if typed in that Fluxer channel.
    let answer = "";
    const asIfThere = Object.create(message, {
      channelId: { value: f.id },
      reply: { value: async (t) => { answer = typeof t === "string" ? t : t?.content ?? ""; } },
    });
    await self.run([d.id, before?.bridgeType ?? "both"], asIfThere, discordClient, fluxerClient).catch((e) => { answer = String(e?.message ?? e); });
    if (/^Linked with/.test(answer)) linked.push(`#${f.name} ↔ #${d.name}`);
    else failed.push(`#${f.name}: ${answer.slice(0, 120)}`);
  }

  const out = [`**${server.name}:** linked ${linked.length}.`];
  if (linked.length) out.push(linked.join("\n"));
  if (noMatch.length) out.push(`\nNo channel with the old name in ${server.name}:\n${noMatch.join("\n")}\n-# Link those by hand: go to the Fluxer channel and type \`bb!link <Discord channel name>\`.`);
  if (failed.length) out.push(`\nCouldn't link:\n${failed.join("\n")}`);
  if (!linked.length && !noMatch.length && !failed.length) out.push("Everything that could be matched is already linked.");
  await message.reply(out.join("\n").slice(0, 1990));
}

export default command;
