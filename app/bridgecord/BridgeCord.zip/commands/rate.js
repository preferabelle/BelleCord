import { randomInt } from "node:crypto";

const VERDICTS = [[0, "Not great."], [3, "Could be better."], [5, "Not bad."], [7, "Pretty good."], [9, "Excellent."]];

/** @type {import('../utils/CommandSchema.d.ts').CommandSchema} */
const command = {
  name: "rate",
  aliases: [],
  description: "Rate anything out of 10",
  params: "<thing>",
  access: "everyone",
  category: "games",
  async run(params, message) {
    const thing = params.join(" ").trim().slice(0, 100);
    if (!thing) return void (await message.reply("What should I rate? Like this: `bb!rate pizza`"));
    // The same thing always gets the same score (so asking twice doesn't change it).
    let h = 0;
    for (const ch of thing.toLowerCase()) h = (h * 31 + ch.charCodeAt(0)) >>> 0;
    const score = h % 11;
    const verdict = [...VERDICTS].reverse().find(([min]) => score >= min)[1];
    await message.reply(`**${thing}**: ${score}/10. ${verdict}`);
  },
};

export default command;
