import { Message as FluxerMessage } from "@fluxerjs/core";
import { ChannelMap } from "../db/index.js";
/** @type {import('../utils/CommandSchema.d.ts').CommandSchema} */
const command = {
  name: "purge",
  aliases: ["clear"],
  description: "Delete the latest messages on this channel's Discord side",
  params: "<count>",
  access: "admin",
  category: "server",
  async run(params, message, discordClient) {
    const n = Math.min(100, Math.max(1, Number.parseInt(params[0] ?? "", 10) || 0));
    if (!n) return void (await message.reply("How many? `bb!purge 10`"));
    if (!(message instanceof FluxerMessage)) return void (await message.reply("Use it in the Fluxer channel that's bridged to the one you want cleaned."));
    const map = await ChannelMap.findOne({ where: { fluxerChannelId: message.channelId }, raw: true });
    if (!map) return void (await message.reply("This channel isn't bridged to Discord."));
    const ch = await discordClient.channels.fetch(map.discordChannelId).catch(() => null);
    if (!ch?.bulkDelete) return void (await message.reply("I can't reach that Discord channel."));
    const gone = await ch.bulkDelete(n, true).catch((e) => ({ error: e?.message ?? e }));
    if (gone?.error) return void (await message.reply(`Discord wouldn't let me (${gone.error}).`));
    await message.reply(`Gone. Deleted ${gone.size} message${gone.size === 1 ? "" : "s"} on Discord.${gone.size < n ? " (Discord won't bulk-delete messages older than two weeks.)" : ""}`);
  },
};
export default command;
