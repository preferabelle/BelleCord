/** @type {import('../utils/CommandSchema.d.ts').CommandSchema} */
const command = {
  name: "unban",
  aliases: [],
  description: "Unban someone on Discord",
  params: "<username or ID>",
  access: "admin",
  category: "members",
  async run(params, message, discordClient) {
    if (!discordClient?.isReady?.()) return void (await message.reply("I'm not connected to Discord right now."));
    const want = params.join(" ").replace(/^@/, "").trim().toLowerCase();
    if (!want) return void (await message.reply("Who? `bb!unban <their Discord username>`"));
    const done = [];
    for (const g of discordClient.guilds.cache.values()) {
      const bans = await g.bans.fetch().catch(() => null);
      const hit = [...(bans?.values?.() ?? [])].find((b) => b.user.id === want || b.user.username.toLowerCase() === want || b.user.globalName?.toLowerCase() === want);
      if (hit) { await g.members.unban(hit.user.id, "Unbanned via the bridge bot").then(() => done.push(`${hit.user.username} in ${g.name}`)).catch(() => {}); }
    }
    await message.reply(done.length ? `Unbanned ${done.join(", ")}.` : `Nobody called "${want}" is banned anywhere I can see.`);
  },
};
export default command;
