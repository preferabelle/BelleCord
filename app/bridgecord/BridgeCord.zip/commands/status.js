import { ActivityType } from "discord.js";
const KINDS = { online: "online", idle: "idle", away: "idle", dnd: "dnd", busy: "dnd", invisible: "invisible", offline: "invisible" };
/** @type {import('../utils/CommandSchema.d.ts').CommandSchema} */
const command = {
  name: "presence",
  aliases: ["status"],
  description: "Set the Discord bot's status",
  params: "<online | idle | dnd | invisible> [text]",
  access: "admin",
  category: "accounts",
  async run(params, message, discordClient) {
    if (!discordClient?.isReady?.()) return void (await message.reply("I'm not connected to Discord right now."));
    const [kindWord, ...rest] = params;
    const status = KINDS[(kindWord ?? "").toLowerCase()];
    if (!status) return void (await message.reply("Like this: `bb!presence dnd drawing` (online, idle, dnd, or invisible)"));
    const text = rest.join(" ").trim();
    discordClient.user.setPresence({ status, activities: text ? [{ name: text, state: text, type: ActivityType.Custom }] : [] });
    await message.reply(`Your bot is ${status === "dnd" ? "on do not disturb" : status} on Discord${text ? ` with "${text}"` : ""}.`);
  },
};
export default command;
