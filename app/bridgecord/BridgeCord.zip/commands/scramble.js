import { playerOf, triviaChannelFor, triviaRunning } from "../utils/Games.js";
import { START, stopChatGame, WORD_CATEGORIES } from "../utils/ChatGames.js";
const GAME = "scramble";
/** @type {import('../utils/CommandSchema.d.ts').CommandSchema} */
const command = {
  name: "scramble",
  aliases: [],
  description: "Unscramble-the-word race for the channel (5 rounds)",
  params: "[general | overwatch | minecraft | pokemon | stop]",
  access: "everyone",
  category: "games",
  async run(params, message) {
    const ch = await triviaChannelFor(message);
    if (!ch) return void (await message.reply("Play in a bridged channel."));
    const w = (params[0] ?? "").toLowerCase();
    if (w === "stop") return void (await message.reply(stopChatGame(ch) ? "Game over. Nobody wins." : "There's no game going."));
    if (triviaRunning(ch)) return void (await message.reply("A game's already going here. Finish it first, or stop it with `bb!" + GAME + " stop`."));
    const category = WORD_CATEGORIES.includes(w) ? w : null;
    START[GAME](ch, playerOf(message).name, category);
  },
};
export default command;
