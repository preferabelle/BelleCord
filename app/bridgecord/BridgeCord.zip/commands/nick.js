import { onMember } from "../utils/MemberCommand.js";
/** @type {import('../utils/CommandSchema.d.ts').CommandSchema} */
const command = {
  name: "nick",
  aliases: [],
  description: "Change someone's Discord nickname",
  params: "<name> <nickname | reset>",
  access: "admin",
  category: "members",
  async run(params, message, discordClient, fluxerClient) {
    const [first, ...rest] = params;
    const nick = rest.join(" ").trim();
    if (!first || !nick) return void (await message.reply("Like this: `bb!nick alex Alex the Great` or `bb!nick alex reset`."));
    const value = /^(reset|none|clear)$/i.test(nick) ? null : nick.slice(0, 32);
    await onMember(message, [first], discordClient, fluxerClient, (m) => m.setNickname(value, "Bridge bot").then(() => (value ? `now "${value}"` : "nickname removed")), { verb: "renamed", failVerb: "rename them" });
  },
};
export default command;
