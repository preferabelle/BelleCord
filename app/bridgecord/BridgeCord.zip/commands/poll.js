// bb!poll: a poll on both sides. A real Discord poll, and a card on Fluxer that people vote on with reactions.
import { Message as FluxerMessage } from "@fluxerjs/core";
import { nameOn } from "../utils/AddonTools.js";
import { makePoll } from "../utils/extras/Polls.js";

/** @type {import('../utils/CommandSchema.d.ts').CommandSchema} */
const command = {
  name: "poll",
  aliases: ["vote"],
  description: "Make a poll everyone can vote on, on Discord and Fluxer",
  params: "<question> | <answer> | <answer> [| 3h] [| multi]",
  access: "everyone",
  category: "games",
  additionalInfo: "Like `bb!poll Pizza or tacos? | Pizza | Tacos`. Up to 10 answers. Add `| 3h` or `| 2d` for how long it lasts (a day if you don't), and `| multi` to let people pick more than one. On Discord it's a real poll; on Fluxer people vote by reacting with the number, and both sides' votes are counted together. A poll someone makes on Discord the normal way shows up on Fluxer too.",
  async run(params, message) {
    const parts = params.join(" ").split("|").map((x) => x.trim()).filter(Boolean);
    let hours = 24, multi = false;
    const keep = [];
    for (const p of parts) {
      const t = p.match(/^(\d+(?:\.\d+)?)\s*(h|hr|hrs|hours?|d|days?|m|mins?|minutes?)$/i);
      if (t && keep.length) { const n = Number(t[1]); const u = t[2][0].toLowerCase(); hours = u === "d" ? n * 24 : u === "m" ? n / 60 : n; continue; }
      if (/^(multi|multiple|many|pick many|more than one)$/i.test(p) && keep.length) { multi = true; continue; }
      keep.push(p);
    }
    const [question, ...answers] = keep;
    if (!question || answers.length < 2) {
      return void (await message.reply("Like this: `bb!poll Pizza or tacos? | Pizza | Tacos`\n-# Up to 10 answers. Add `| 3h` or `| 2d` for how long it lasts (a day if you don't), and `| multi` to let people pick more than one."));
    }
    if (answers.length > 10) return void (await message.reply("Discord polls can have up to 10 answers."));
    try {
      await makePoll({ side: message instanceof FluxerMessage ? "fluxer" : "discord", channelId: message.channelId, by: nameOn(message), question, answers, hours: Math.max(1, hours), multi });
    } catch (e) {
      await message.reply(String(e?.message ?? e));
    }
  },
};
export default command;
