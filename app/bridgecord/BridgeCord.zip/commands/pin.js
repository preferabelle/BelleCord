import { ChannelMap, MessageMap } from "../db/index.js";
import { discordMessageForReply } from "../utils/DiscordControl.js";
/** @type {import('../utils/CommandSchema.d.ts').CommandSchema} */
const command = {
  name: "pin",
  aliases: [],
  description: "Reply to a message to pin it on Discord",
  params: "",
  access: "admin",
  category: "server",
  async run(params, message, discordClient) {
    const found = await discordMessageForReply(message, discordClient, MessageMap, ChannelMap);
    if (found.error) return void (await message.reply(found.error));
    await found.msg.pin("Bridge bot").then(() => message.reply("Pinned. ")).catch((e) => message.reply(`Discord wouldn't let me (${e?.message ?? e}).`));
  },
};
export default command;
