#!/usr/bin/env bash
# Start the BridgeCord on Linux. Run it from a terminal:  ./"START (Linux).sh"
cd "$(dirname "$0")" || exit 1

if ! command -v node >/dev/null 2>&1; then
  echo "Node.js isn't installed yet (version 20.10 or newer is needed)."
  echo "Install it, then run this file again. For example:"
  echo "  Ubuntu/Debian:  curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash - && sudo apt-get install -y nodejs"
  echo "  Fedora:         sudo dnf install nodejs"
  echo "  Arch:           sudo pacman -S nodejs npm"
  echo "  Any distro:     https://nodejs.org/en/download (or nvm)"
  exit 1
fi

major=$(node -p "process.versions.node.split('.')[0]")
if [ "$major" -lt 20 ]; then
  echo "Node.js $(node -v) is too old. Version 20.10 or newer is needed."
  exit 1
fi

if [ ! -d node_modules ]; then
  echo "First start: downloading the bridge's parts. This takes a minute or two..."
  if ! npm install --omit=dev --no-audit --no-fund; then
    echo "The download didn't finish. Check your internet connection and try again."
    exit 1
  fi
fi

# The database part has to fit this system. If it doesn't, build it here (needs build tools).
if ! node -e "require('sqlite3')" >/dev/null 2>&1; then
  echo "Fitting the database part to this system (one time only)..."
  if ! npm rebuild sqlite3 --build-from-source; then
    echo "That needs build tools. Install them, then run this file again:"
    echo "  Ubuntu/Debian:  sudo apt-get install -y python3 make g++"
    echo "  Fedora:         sudo dnf install python3 make gcc-c++"
    echo "  Arch:           sudo pacman -S python make gcc"
    exit 1
  fi
fi

exec node launcher.js
