# BridgeCord

**One community, two apps.** Your Fluxer community and your Discord server, joined so completely that people forget they're on different apps.

Someone on Discord says hello. On Fluxer, it appears instantly, with their name and their picture. A Fluxer friend replies, and on Discord it lands as a real reply, under the right message. Someone edits a typo, deletes a message, or adds a reaction: it happens on both sides. Pictures, files, stickers, custom emoji: all of it crosses over.

Then it goes further than a normal bridge:

- **One voice call across both apps.** Fluxer people and Discord people talk in the same call, and hear each other live. Every person can be turned up, down, or muted individually.
- **People, not webhooks.** Give a Discord friend a *mirror*: their own Fluxer bot that posts as them, shows their online status, and even joins voice calls alongside them. It works the other way too, with *linked bots* that carry Fluxer people onto Discord.
- **Streams too, with BelleCord.** In the bridged call, going live on Discord can show the same screen on Fluxer, and Fluxer streams get a Watch button on Discord, for everyone in the call who uses [BelleCord](https://github.com/preferabelle/BelleCord). The video goes straight between BelleCord and Fluxer, never through the bridge.
- **DMs across apps.** Message someone's mirror on Fluxer and it reaches them on Discord. Their reply comes right back.
- **Nothing gets lost.** If the bridge goes offline, messages sent in the meantime are carried over when it returns.
- **Run Discord from Fluxer.** Kick, ban, timeout, roles, nicknames, purge, lock, slowmode, pins, announcements, all without opening Discord.
- **Copy a whole server, either way.** `b!syncserver to fluxer` builds your Discord server's channels, categories, roles and permissions on Fluxer (or `to discord` the other way round), reuses the channels that are already there, and bridges everything. It shows you the plan before it touches anything.
- **Stays in sync by itself.** Turn on `b!keepsync` and a channel made, renamed, moved or deleted on one side happens on the other too, along with the server's name and icon.
- **Polls everyone can vote on.** A real Discord poll, a live card on Fluxer, and one combined count.
- **Games for both sides at once.** Trivia, scramble, hangman, would-you-rather, blackjack, rock paper scissors, dice, an 8-ball, and a leaderboard.
- **One word filter for both apps.** Catches the spelled-around versions too (f.u.c.k, sh1t, fuuuck).
- **Auto replies.** Pick a phrase, attach pictures or GIFs, and the bot answers with one at random on both sides.
- **Move servers in two commands.** `b!unlink all`, then `b!link all <new server>`. Every channel finds its partner again.

## Setup in five steps

You'll need your own Fluxer bot and Discord bot (free, about 5 minutes; `INSTALL.txt` shows how), and a computer or server that stays on: Windows, Mac, Linux, or anything with Docker.

1. **Paste your two bot tokens** into `settings.txt`. That's the only required setting.
2. **Start it.** Windows: `START (Windows).bat` · Mac: `START (Mac).command` · Linux: `./"START (Linux).sh"` · Docker: `docker compose up -d --build`. It installs everything it needs by itself.
3. **Invite the bots.** The start window shows both invite links.
4. **Claim it.** The start window also shows a code like `b!claim 482913`. Type it in Fluxer and you're the owner. Nothing to look up.
5. **Bridge.** Type `b!link all <your Discord server>` and every channel with a matching name is connected. (Or `b!link <channel>` one at a time.)

Stuck? `b!health` checks everything and tells you exactly what to fix.

**More detail:** `INSTALL.txt` (setup for every system) · `HOW TO USE.txt` (everyday use, with examples)

## Who can do what

| | Who | Can use |
|---|---|---|
| **Owner** | Whoever claimed the bot | Everything |
| **Admins** | People the owner adds (`b!admins add <name>`), plus server managers if you leave that on | Everything except owner commands |
| **Everyone** | All other members | Help, info, and games |

`b!help` only ever shows people the commands they're allowed to use.

## All commands

Every command starts with `b!` (changeable in settings.txt). `b!help <command>` explains any of them in chat.

### Info

| Command | What it does | Who |
|---|---|---|
| `b!about` | About this bot | Everyone |
| `b!help [category or command]` | Show commands, a category, or details for one command | Everyone |
| `b!ping` | Check that the bot is online and how fast it responds | Everyone |
| `b!stream [new \| off]` | Get your BelleCord link for streams in the bridged call (on Discord) | Everyone |

### Games

| Command | What it does | Who |
|---|---|---|
| `b!8ball <question>` | Ask the magic 8-ball a question | Everyone |
| `b!blackjack [hit \| stand \| record]` | Blackjack against the bot | Everyone |
| `b!flip [heads \| tails]` | Flip a coin | Everyone |
| `b!hangman [general \| overwatch \| minecraft \| pokemon \| stop]` | Hangman for the channel: type letters to guess | Everyone |
| `b!poll <question> \| <answer> \| <answer> [\| 3h] [\| multi]` | A poll on both sides, with the votes counted together | Everyone |
| `b!rate <thing>` | Rate anything out of 10 | Everyone |
| `b!roll [dice]` | Roll dice, like 1d20 or 2d6+3 | Everyone |
| `b!rps <rock \| paper \| scissors>` | Rock, paper, scissors against the bot | Everyone |
| `b!scramble [general \| overwatch \| minecraft \| pokemon \| stop]` | Unscramble-the-word race for the channel (5 rounds) | Everyone |
| `b!stats [top]` | Your game stats, or the leaderboard | Everyone |
| `b!trivia [general \| overwatch \| minecraft \| roblox \| online \| stop]` | Start a trivia game for the channel (5 questions) | Everyone |
| `b!wouldyourather` | A would-you-rather question; type A or B to vote | Everyone |

### Bridging

| Command | What it does | Who |
|---|---|---|
| `b!bridgelist` | Every bridged channel in this server | Admins |
| `b!channels` | List the Discord channels you can link to | Admins |
| `b!discord-invite [Discord channel]` | Create an invite link to the Discord server | Admins |
| `b!fluxer-invite [forever] [uses]` | Create an invite link to this Fluxer community | Admins |
| `b!health` | Full health check of the bridge | Admins |
| `b!id` | Show the IDs of this server, channel, and you | Admins |
| `b!invite` | Invite links for the bot itself | Admins |
| `b!leave-server <server name>` | Make the bot leave a Discord server | Owner |
| `b!link <Discord channel> \| all <Discord server>` | Bridge this Fluxer channel with a Discord channel, or link every channel at once | Admins |
| `b!practice [on \| off]` | Test mode without Discord | Admins |
| `b!servers` | Which Discord servers the bot is in | Admins |
| `b!typing [on \| off]` | Show (or stop showing) "is typing" across the bridge | Admins |
| `b!unlink [all]` | Unbridge this channel, or every channel at once | Admins |
| `b!who <name>` | Find someone's IDs on Fluxer and Discord | Admins |

### Mirrors and linked bots

| Command | What it does | Who |
|---|---|---|
| `b!account <token> [name] \| list \| remove <name> \| rename <old> <new> \| relink <mirror> <Discord user>` | Set up mirrors and linked bots (DM the bot with a token) | Admins |
| `b!bot [name] [picture \| banner \| nick \| name \| status]` | See or change any of the bridge's bots: picture, banner, nickname, name, status | Admins |
| `b!look [name]` | See how a bot or a Discord member looks | Admins |
| `b!mirrors` | Status of every mirror bot | Admins |
| `b!presence <online \| idle \| dnd \| invisible> [text]` | Set the Discord bot's status | Admins |
| `b!profile [name] <picture \| banner> [reset]` | Change a linked bot's picture or banner (attach an image) | Admins |

### Voice

| Command | What it does | Who |
|---|---|---|
| `b!mute <name>` | Mute someone for everyone in the voice bridge | Admins |
| `b!unmute <name>` | Unmute someone in the voice bridge | Admins |
| `b!voice <on [channel] \| off \| status \| test>` | Bridge a voice channel between Fluxer and Discord | Admins |
| `b!voice-join [channel]` | Have the bot join a Fluxer voice channel (muted) | Admins |
| `b!voice-leave` | Have the bot leave the Fluxer voice channel | Admins |
| `b!volume <name> [0-200]` | Set someone's volume in the voice bridge (0 to 200) | Admins |

### Discord members

| Command | What it does | Who |
|---|---|---|
| `b!ban <name> [reason]` | Ban someone from Discord | Admins |
| `b!disconnect <name>` | Disconnect someone from Discord voice | Admins |
| `b!dm <name> <message>` | Send someone a DM on Discord from the bot | Admins |
| `b!kick <name> [reason]` | Kick someone from Discord | Admins |
| `b!kick-cancel [name]` | Cancel a pending Discord kick | Admins |
| `b!move <name> <voice channel>` | Move someone to another Discord voice channel | Admins |
| `b!nick <name> <nickname \| reset>` | Change someone's Discord nickname | Admins |
| `b!role <name> <role>` | Give or remove a Discord role | Admins |
| `b!timeout <name> <10m \| 2h \| 1d> [reason]` | Time someone out on Discord | Admins |
| `b!unban <username or ID>` | Unban someone on Discord | Admins |
| `b!untimeout <name>` | End someone's Discord timeout | Admins |
| `b!user-info <name>` | Details about a Discord member | Admins |

### Discord server

| Command | What it does | Who |
|---|---|---|
| `b!announce <channel> <message>` | Post an @everyone announcement in a Discord channel | Admins |
| `b!autoreply [add <phrase> \| remove <phrase> \| on/off <phrase>]` | Phrases the bot answers with a picture or GIF (attach them) | Admins |
| `b!create-role <name> [#color]` | Create a Discord role | Admins |
| `b!delete` | Reply to a message to delete it on both sides | Admins |
| `b!filter [add \| remove \| test \| clear] [words]` | Words that get deleted on both sides | Admins |
| `b!lock [channel]` | Stop regular members from talking in a Discord channel | Admins |
| `b!pin` | Reply to a message to pin it on Discord | Admins |
| `b!pingroles [fix]` | Roles with the same name on both sides: pinging one pings the other. `fix` makes them pingable | Admins |
| `b!post <channel> <message>` | Post a message in any Discord channel | Admins |
| `b!purge <count>` | Delete the latest messages on this channel's Discord side | Admins |
| `b!read <channel> [count]` | Read the latest messages from any Discord channel | Admins |
| `b!roles` | List the Discord server's roles | Admins |
| `b!say <message>` | Have the bot say something on both sides of this channel | Admins |
| `b!server-info` | Details about the Discord server | Admins |
| `b!slowmode <seconds> [channel]` | Set slowmode on a Discord channel (seconds; 0 turns it off) | Admins |
| `b!topic <topic>` | Set this channel's topic on Discord | Admins |
| `b!unlock [channel]` | Undo a lock | Admins |
| `b!unpin` | Reply to a message to unpin it on Discord | Admins |

### Server copy and sync

| Command | What it does | Who |
|---|---|---|
| `b!syncserver [to fluxer \| to discord] [clean] [go]` | Make one server copy the other: channels, categories, roles, permissions, name and icon, all bridged. Shows the plan first; `go` does it | Owner |
| `b!syncserver layout` | Both servers' channels, the way the bot sees them | Owner |
| `b!keepsync [on \| off]` | Keep both servers the same as channels change | Owner |

### Owner

| Command | What it does | Who |
|---|---|---|
| `b!admins add <name> \| remove <name> \| list` | Add or remove admins | Owner |
| `b!claim [code]` | Become the bot's owner with the code from the start window (or, as the owner, get a code for Discord) | Everyone |
| `b!restart` | Restart the bot (after editing settings.txt) | Owner |

## Copying a server

Works from either app. Type it in the Fluxer community or in the Discord server it's bridged to.

1. `b!syncserver to fluxer` (Fluxer copies Discord) or `b!syncserver to discord` (Discord copies Fluxer). Nothing changes yet: you get a list of what would happen.
2. `b!syncserver to fluxer go` does it. Channels that already exist are matched up (by bridge, by name, or by what they're for, like "memes" and "shitposts") and renamed instead of duplicated. Channels the other side doesn't have are moved to the bottom, never deleted.
3. Add `clean` (`b!syncserver to fluxer clean go`) to also delete the roles and channels the other side doesn't have. Bridged channels, link channels, and the channel you typed it in are never deleted.

Not bridged yet? Add the other app's server ID: in Fluxer type the Discord server's ID, in Discord the Fluxer community's ID (`b!syncserver to fluxer 123456789012345678`).

## Mirrors and linked bots

Always DM tokens to the bot. If one is posted in a channel, the bot deletes it and warns you to reset it.

- **Mirror** (a Discord member, shown on Fluxer): make a Fluxer bot, then DM `b!account <Fluxer bot token> <their Discord username>`.
- **Linked bot** (a Fluxer member, shown on Discord): make a Discord bot, then DM `b!account <Discord bot token> <their Fluxer username>`, and open the invite link it sends back.
- `b!account list` shows every mirror and linked bot, with invite links.

## Streams with BelleCord

A Discord bot can't watch or send a Discord stream, so [BelleCord](https://github.com/preferabelle/BelleCord) does that part, for anyone in the bridged call who uses it:

- **Going live on Discord:** the box where you pick your screen asks "Also show it on Fluxer". It shows as your mirror on Fluxer, or as the bridge bot if you don't have one.
- **Someone streams on Fluxer:** a Watch button shows up under Discord's call buttons, and the stream plays in a small window you can move and resize.

The bridge only sets it up: it opens one more Fluxer voice connection for that person and hands it to their BelleCord. The video never goes through the bridge.

- **On the computer that runs the bridge**, BelleCord finds it by itself (Dashboard > Your bridge bot).
- **Friends on other computers** need an address that reaches the bridge: run a tunnel (ngrok, Cloudflare Tunnel) or forward a port to `stream port` (8790), put the address after `stream address:` in settings.txt, and restart. Each friend then types `b!stream` on Discord and gets their own link in a DM. Clicking it in BelleCord adds it. A link only works for that person's Discord account, and only while they're in the bridged call.
- The bridge bot (and each mirror) needs the **Stream** permission in the Fluxer voice channel. `streams: no` in settings.txt turns all of it off.

## Files

- `INSTALL.txt`: setup for Windows, Mac, Linux, and Docker.
- `HOW TO USE.txt`: everyday use, with examples.
- `settings.txt`: your settings. Only the two tokens are required.
- `START (Windows).bat`, `START (Mac).command`, `START (Linux).sh`: start the bridge.
- `Dockerfile`, `docker-compose.yml`: run it in Docker.
- `data/`: created on first start; the bot's saved state. Back it up.

## License and credits

Built on **Fluxcord** by Jb Carreon, used under the MIT License (see `LICENSE`). The MIT License allows commercial use, including selling, as long as the original copyright notice and license text stay included.
